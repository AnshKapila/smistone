---
name: cloudinary-image-transformation
description: "Use this skill whenever you write or transform a Cloudinary URL — embedding an image, resizing, cropping, trimming, or changing format on any `static.kite.ai` or `res.cloudinary.com` URL."
mode: both
---

Apply transforms as `/`-separated segments between `/upload/` and the rest of the path: `https://static.kite.ai/image/upload/<transforms>/<rest>.<ext>`. Combine compatible transforms with commas inside one segment.

- **Every Cloudinary URL must include `f_auto,q_auto`** — logos and content images alike. This negotiates modern formats (WebP/AVIF) and optimises quality, cutting bytes ~6× with no visual regression (alpha preserved). The pipeline injects these deterministically, so even if the LLM omits them, they'll be added.
- **Logos carry `e_trim` in its own `/`-segment, before sizing and format.** `…/upload/e_trim/f_auto,q_auto,h_80/<file>.png`. If a logo URL doesn't already have `e_trim` as its own `/`-segment, insert it after `/upload/` (or split it out from a comma-joined segment like `e_trim,h_80`).
- **`e_trim` is logo-only. Never apply `e_trim` to content or product images.** `e_trim` strips whitespace and transparent edges — on a product photo with an intentional white background, it removes the surrounding space and makes the product fill the frame, appearing dramatically more zoomed than intended. For content/product images that need zoom adjustments, use CSS (`transform: scale()`, or adjust `object-fit`/container sizing) instead of Cloudinary trim transforms.
- **Content images use `f_auto,q_auto` plus `w_<int>` when width is known.** Example: `…/upload/f_auto,q_auto,w_1600/<file>.png`.
- **Face gravity (`g_face`) pairs with a crop that anchors:** `c_fill`, `c_thumb`, `c_crop`, `c_lfill`, `c_fill_pad`, `c_auto`, or `c_auto_pad`.
