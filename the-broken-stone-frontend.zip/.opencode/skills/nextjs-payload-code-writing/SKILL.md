---
name: nextjs-payload-code-writing
description: >
  Use this skill when authoring or editing the code of a generated Next.js
  website iteration that embeds a headless CMS (content lives in the database,
  sections are block components) — restyling block components, adding sections,
  imagery, contact forms, mobile navigation, or product visuals, and when
  deciding between a server component vs a client component, `<Image>` vs
  `<img>`, or HTML/CSS/SVG vs raster imagery. Triggers any time work touches
  files under the iteration's `src/`, including fresh iteration generation,
  "add a new section", "swap the hero", or "fix the mobile menu". For Next.js
  iterations WITHOUT an embedded CMS (classic file-based content), use the
  `nextjs-code-writing` skill instead; for static-HTML build iterations
  (single-file SPA with `route.render()`), use `website-code-writing`.
mode: both
---

# Coding Rules — Next.js (embedded Payload CMS)

These rules apply to every file you author or edit inside a Next.js iteration. They are framework-agnostic where possible (workflow discipline, component patterns) and Next.js-specific where they need to be (App Router conventions, `<Image>` rules, Cloudinary transforms).

## Workflow discipline

1. Define success from the user request, the iteration's current source, and the host prompt's required response shape, available tools, and validation steps before writing code.
2. Use the smallest implementation that satisfies the request. Do not add speculative sections, styles, abstractions, files, or rewrites.
3. Read the relevant current structure before changing it: existing copy modules, components, routes, metadata exports, Tailwind class patterns, and nearby files.
4. Use deterministic tools for deterministic work: search, exact replacement, parsing, routing, validation, retries, and file checks.
5. Match the iteration's existing conventions even when another style seems preferable. Preserve routing, metadata, Tailwind patterns, data architecture, indentation, and naming.
6. Validate using the checks required by the host prompt. If a required check is unavailable or skipped, report that instead of implying it passed.
7. When a safe target is unclear, required input is missing, validation fails, an image cannot be referenced, or an edit cannot be uniquely located, report the specific missing input, failed check, or ambiguous visible target and stop.

## Content lives in Payload — author block components, not routes or data files

This site embeds Payload CMS. Content does NOT live in `src/data/content.ts` or in route files — it lives in the Payload database, authored as a **seed manifest** (`seed.json`). The **content contract** — the seed shape, field grammar, image-URL/richText conventions, the block-authoring triple, the admin-ergonomics standards, and the fit validator — is owned by the **`cms-management`** skill; follow it for anything touching `seed.json` or `src/payload/`.

This skill covers only the Next.js side: you author **block components** under `src/components/blocks/<Name>.tsx` (the visual implementation), restyling the template defaults with JSX + Tailwind to match the design while keeping each component's **prop names identical** to its Payload field schema — the renderer spreads the stored block onto the component, so renamed/added props break rendering.

Do NOT author the data fetch, route `page.tsx` files, `src/data/*`, `sitemap.ts`, `robots.ts`, or the Payload config — they are baked into the template. Tailwind classes are the styling system; touch `globals.css` only when a rule cannot be expressed in `className`.

Analytics stamps (`data-kite-*`) apply to classic-template sites only — Payload sites have baked block components with no authored stamps. Do not add `data-kite-*` attributes here (the authoring grammar in `nextjs-code-writing` does not apply to this template).

## Template invariants — do NOT modify or re-emit

These files ship with the iteration template. Treat them as read-only during edits, and do not list them in any generation plan:

- `package.json`, `pnpm-lock.yaml`, `tsconfig.json`, `next.config.mjs`, `next-env.d.ts`, `postcss.config.mjs`, `middleware.ts`, `vercel.ts`, `redirects.csv`, `.npmrc`, `.nvmrc`
- `src/payload.config.ts`, `src/payload/**` (collections, globals, block field schemas), `src/payload-types.ts`, `scripts/seed-payload.ts` — the Payload CMS scaffold
- `src/app/(payload)/**` — the baked Payload admin + REST routes
- `src/app/(frontend)/layout.tsx` (provides `<html><body>` and brand metadata) and `src/app/(frontend)/[[...slug]]/page.tsx` (the baked server component that fetches a Payload page and renders its blocks)
- `src/components/blocks/RenderBlocks.tsx` (the block-type → component map)
- `src/app/sitemap.ts`, `src/app/robots.ts` (read Pages from Payload's Local API)
- `src/app/globals.css` (Tailwind layer entry; add styles via `className` first)
- `src/app/api/v1/kite-platform/**` (platform-provided routes — health, website-contact-form-management submit)
- `public/favicon.svg`, `public/robots.txt`

Add new block types only by adding both a field schema under `src/payload/blocks/` AND a component under `src/components/blocks/` AND registering it in `RenderBlocks.tsx` — but prefer the fixed block library. Never overwrite the baked page renderer or layouts.

## Planner-authored — do NOT modify or re-emit

These files are written by the generation pipeline (not the template). Treat them as read-only: import from them, but do not author or rewrite them.

- `src/app/fonts.ts` — emitted by `plan_files.py` after the planning LLM picks one Google Font per typography role. Components import named exports from it (see Typography below).

## Typography

The planning step writes `src/app/fonts.ts` with one `next/font/google` instance per brand typography role: `heroFont`, `headingFont`, `subHeadingFont`, `bodyFont`. Apply them by importing the role you need and putting `${roleFont.className}` on the JSX element:

```tsx
import { bodyFont, headingFont, heroFont } from '@/app/fonts';

<h1 className={`${heroFont.className} text-7xl tracking-tight`}>...</h1>
<h2 className={`${headingFont.className} text-3xl`}>...</h2>
<p className={`${bodyFont.className} text-base leading-relaxed`}>...</p>
```

Use the role that matches the visual specification's typography hierarchy. Apply `bodyFont.className` to body copy and form elements; reuse it on the `<body>` element in route-level layouts only when the visual spec calls for a single default font. Reach for `fontFamily` styles, `<link>` tags for fonts, or `next/font` imports in components only when the visual specification calls for a font outside the four role exports — and only after confirming the font is in `google-font-map.json`.

## Next.js App Router conventions

- Server components by default. Add `'use client'` as the FIRST line of any file that uses `useState`, `useEffect`, `useRef`, `useReducer`, `useContext`, browser globals (`window`, `document`, `localStorage`), or DOM event handlers (`onClick`, `onChange`, `onSubmit`, etc.). Missing this directive is a build error, not a warning — treat it as non-negotiable.
- Use `next/link` for in-app navigation.
- Per-route SEO uses `export const metadata = { title, description, openGraph, twitter, ... }` (or `generateMetadata` when values are dynamic) from each route's `page.tsx` or `layout.tsx`. Do not update `<title>`/`<meta>` via JS at runtime — Next.js writes the head from the metadata export at render time.
- `title` should be ~50–65 characters; `description` should be ~120–160 characters.
- Compute the current year at runtime (`new Date().getFullYear()`). Never hardcode the year.
- Imports must resolve against the installed dependencies listed in the user prompt's installed-packages section. Do NOT add icon libraries (`lucide-react`, `react-icons`, etc.), animation libraries, or any package the template doesn't ship with — use inline SVG instead.

## Images

### `<Image>` vs `<img>`

Use `<Image>` from `next/image` for content imagery. Use `<img>` only for purely decorative imagery without sizing constraints, or for a user-uploaded logo URL whose dimensions are unknown.

`<Image>` requires explicit `width` and `height`. Derive them from the manifest entry's `aspect_ratio`:

| aspect_ratio | width × height |
|---|---|
| `16:9` | `1600 × 900` |
| `4:3` | `1600 × 1200` |
| `1:1` | `1200 × 1200` |
| `3:4` | `1200 × 1600` |
| `21:9` | `2100 × 900` |

### LCP image

Set `priority` on the page's largest-contentful-paint image (typically the hero on the home route). `priority` triggers eager loading, emits a `<link rel="preload">`, and sets `fetchPriority="high"`. Without it the LCP `<Image>` lazy-loads like every other image and appears late. Every other `<Image>` keeps its default lazy behaviour — that is the optimisation.

### Image URL sources

- Manifest URLs: each iteration ships a final image manifest (`plan.json`'s `images` array, with `slug`, `prompt`, `aspect_ratio`, `is_logo`, `url`). Each file's `images` list names the slugs that file embeds — resolve every slug to its `url` from the manifest and embed it verbatim.
- Never invent a slug. Never construct a URL from a base URL and a slug yourself.
- Never add image entries the plan didn't include. If the spec calls for an image the plan missed, surface it via a warning and use the closest available manifest entry.
- The user-uploaded brand logo (the `logo_url` field in the user prompt's `Logo` block, when present) is NOT in the manifest — embed it directly when the visual spec calls for the user-supplied brand mark. Apply the same `e_trim` transform documented below.

## Cloudinary URL transformations

All image URLs (manifest URLs and the user-uploaded `logo_url`) are served by Cloudinary (`static.kite.ai`). Apply transforms by inserting a `/`-separated segment between `/upload/` and the rest of the path.

URL anatomy: `https://static.kite.ai/image/upload/<transforms>/<rest-of-path>.<ext>`

- Logo URLs (manifest entries with `is_logo: true` AND the user-uploaded `logo_url`): always include `e_trim` to strip transparent padding. If the URL already contains `e_trim`, embed as-is; otherwise rewrite `/upload/` → `/upload/e_trim/`. Separate `e_trim` from sizing with `/` (e.g. `e_trim/h_80/...`), not comma.
- Content images (non-logo): apply `f_auto,q_auto`. Add `w_<int>` matching the `<Image>` width. Add `c_fill,g_auto` only when the image is cropped to a fixed aspect ratio. Combine in one segment, e.g. `…/upload/f_auto,q_auto,w_1600/…`.
- **Never apply `e_trim` to content or product images.** `e_trim` strips whitespace edges — on product photos with white backgrounds, it removes the intentional padding and makes the product appear aggressively zoomed.

### Zoom / resize adjustments

When the user asks to zoom in or out on a content or product image ("zoom in a bit", "make it bigger", "zoom out"):

1. **Use CSS, not Cloudinary transforms.** Apply `transform: scale(<factor>)` on the image's container or adjust `object-fit`/`object-position` on the `<img>`/`<Image>` element. This preserves the original image framing the user uploaded.
2. **Keep increments small.** "A bit" or "a little" means ~5–10% (`scale(1.05)` to `scale(1.1)`). Never exceed 15% in a single step.
3. **Never use `e_trim`, `c_fit`, or `c_pad` pipelines for zoom.** These strip whitespace, re-fit, and re-pad the image, which changes the framing far more than the user expects.
4. To zoom in, wrap the image in an `overflow-hidden` container and apply `scale(>1)`. To zoom out, reduce the container width or apply `scale(<1)`.

## Section spacing

Drive section height from content, not from `min-height`. Let padding set the breathing room.

**Don't set `min-h-*` on a section that vertically centers its children.** When a section's minimum height exceeds its content height, vertical centering — `flex items-center`, `grid place-items-center`, `place-content-center`, `content-center` — distributes the surplus as blank space above and below, producing a large empty band. This constraint applies to the section wrapper only; centering within a bounded sub-container (card, badge, icon) is fine. Instead:
- Remove `min-h-*` from the section and let content determine the height.
- Use explicit `pt-*` / `pb-*` to control breathing room.
- Hero sections needing clearance below a fixed nav: use `pt-28 pb-20` (raise `pt` if the nav is taller, but keep it below `pt-32`).

**Scroll reveal animations must not rely on `min-h-*` for scroll distance.** A common pattern is adding `min-h-screen` so there is enough scroll travel for the animation to complete — this creates the same empty band. Instead:
- Trigger animations via `IntersectionObserver` on the content element itself (enter the viewport → start the animation).
- Keep section height content-driven; use viewport entry as the animation threshold, not section height.

**Symmetric vertical padding caps — apply to every section:**

| Section type | Max `py-*` |
|---|---|
| Standard feature / content section | `py-20` |
| Major feature section needing more air | `py-24` |
| Transitional / quote / callout section | `py-16` |
| Pre-footer CTA | `py-24` |

Cap symmetric `py-*` at the values above. `py-32` and larger create empty-looking spans of background color, especially on sections with sparse content or no imagery. Asymmetric pairs like `pt-28 pb-20` are fine when nav clearance or visual balance requires different top and bottom values.

## Component patterns

1. Add search & filters when displaying multiple products or many services.
2. Implement custom date picker and dropdown components consistent with the design of the website instead of system components.
3. Embed a Google Map only when a location is provided in the requirements. Do not guess a location. Do not use an API key.

    ```tsx
    <iframe
      src="https://www.google.com/maps?q=Lavelle+Road,+Bangalore&output=embed"
      allowFullScreen
    />
    ```

    In section copy near the map, use neutral language ("Find us on the map") unless the exact address is confirmed.

4. The navbar and footer are baked `src/components/Header.tsx` and `src/components/Footer.tsx`, rendered once by `src/app/(frontend)/layout.tsx` and fed from the `SiteSettings` global (brand, nav items, footer links, socials). Restyle Header/Footer's JSX + Tailwind to match the design; supply their content through `seed.json`'s `siteSettings`. Do not duplicate navbar/footer markup in blocks or pages, and do not render them per page.
   - Keep the baked import and prop-type signature exactly: `import type { SiteSetting } from '@/payload-types'` and `function Header({ settings }: { settings: SiteSetting })` (same for `Footer`). Payload generates **singular** PascalCase interface names from a slug (`site-settings` → `SiteSetting`, not `SiteSettings`), so importing `SiteSettings` fails typecheck and leaves `settings` untyped — which then turns every `.map((item) => …)` over it into an implicit-`any` error. Change only the JSX and Tailwind; read `navItems`/`footer`/etc. off the typed `settings` prop so list callbacks stay correctly inferred.
   - Navbar links that point to homepage sections must use absolute paths with the hash (e.g. `href="/#features"`, `href="/#pricing"`) — never hash-only anchors (e.g. `href="#features"`). Hash-only anchors resolve relative to the current route, so they do nothing when clicked from a subpage. This applies to desktop nav, mobile nav, and footer nav links.
5. Mobile navigation drawer stacking:
   1. Z-index stack (highest to lowest): navbar with hamburger/close button (`z-50`) → drawer panel (`z-40`) → backdrop overlay (`z-30`).
   2. The hamburger button toggles the drawer open and closed.
   3. The backdrop overlay closes the drawer on click/tap.
   4. Modals and tooltips that must appear above the navbar use `z-[60]` or higher.
6. Contact forms POST `application/json` to `/api/v1/kite-platform/website-contact-form-management/submit`. The route is platform-provided in every Next.js iteration — never create or edit any file under `src/app/api/v1/kite-platform/`.
   - Form inputs must have `name` attributes (used as field labels in the email).
   - Form must have an email field (`type="email"` or `name="email"`).
   - All fields must have validation.
   - Request body shape: `{ email, subject?, text_body?, html_body?, json_body? }` — at least one of `text_body`, `html_body`, `json_body` is required. Map the form's `name`-attributed fields into `json_body` for arbitrary structured submissions.
7. When rendering product visuals (product previews, app screens, dashboard sections, integration/data-flow sections, workflow/automation sections, security diagrams, architecture diagrams, charts, metrics, admin/product UI), default to HTML/CSS/SVG instead of generated raster images.
   1. For SaaS/software sites, generated raster images are a secondary tool. Use them only for editorial hero backdrops, brand mood/supporting imagery, and portraits/testimonials when explicitly needed.
   2. Do not use generated raster images to depict product UI concepts such as dashboards, analytics panels, workflow builders, admin surfaces, integrations maps, architecture/security diagrams, charts, or metrics cards unless the user explicitly asks for an illustrative poster-style treatment.
   3. For integration/data-flow sections, a mixed approach is preferred: keep product logos as images when needed, and render nodes/connectors/status states using HTML/CSS/SVG.
   4. Use CSS connectors/arrows for simple linear flows; use inline SVG connectors for branched or curved flows where SVG gives clearer structure.
   5. Treat these examples as references, not templates. Adapt composition, spacing, and color to the current design tokens:
      - Dashboard preview: render cards/charts/table as HTML/CSS instead of using generated screenshots.
      - Analytics section: render charts, KPI chips, legends, and tables in HTML/CSS/SVG.
      - Integrations section: show SaaS logos as image assets, while rendering data pipeline blocks/connectors in HTML/CSS/SVG.
      - Workflow section: render trigger/action pipeline states as HTML/CSS.
      - Security or architecture section: render layered diagrams, trust boundaries, and callouts in HTML/CSS/SVG rather than as soft-focus raster art.
      - Annotated demo: combine a base dashboard panel with floating callout cards to explain capabilities.
      - Backgroundless product crop: render a clean isolated UI block without decorative backdrop.
      - Branded hero demo: render UI over a full-bleed gradient/mesh/wave background.
   6. For the realism rules that govern populated content vs skeleton-bar placeholders inside rendered product visuals — including the worked wrong-vs-right example — follow the `website-saas-ui-design` skill.
8. Trust strips ("Trusted by", "Our customers", "Our partners", "As featured in", logo strip, customer marquee):
   1. **If `user_uploaded_assets` includes specific brand logos** for the named companies (real customer logos provided by the user), embed those URLs as `<img>` elements with the `e_trim` Cloudinary transform. Layout as a flex/grid row with consistent gap.
   2. **Otherwise — render as wordmark-only chips.** Each company is a styled `<span>` with the company name in a consistent typographic treatment. No icons, no `<Image>`, no inline SVG glyph. Companies differ only by their name text. Example:

      ```tsx
      <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-6">
        {companies.map((name) => (
          <span
            key={name}
            className={`${bodyFont.className} font-semibold text-gray-500 tracking-wide uppercase text-sm`}
          >
            {name}
          </span>
        ))}
      </div>
      ```

      Adjust `text-gray-500` to a contrast-safe muted tone for the section's surface (`text-gray-400` on light, `text-gray-500` on light-gray, `text-white/60` on dark). Keep the same treatment across every chip — never vary weight, casing, or color per company.
   3. **Hard prohibitions:**
      - NEVER generate raster logos for fictional or placeholder companies (the image model produces low-detail abstract marks — dots, dashes, triangles — when asked to invent a brand identity it has no reference for). This is the dominant "company logos = dashes and dots" failure mode.
      - NEVER use the same inline SVG icon for multiple distinct companies, varying only the wordmark text beside it. That yields the "Acme / Globex / Initech all have the same layered-rectangle icon" failure — identical-looking entries that read as obviously fake.
      - NEVER plan an image slug for a fictional company logo in a trust strip. (The planner's image-manifest rule mirrors this prohibition — they must agree.)
      - NEVER author a unique inline SVG per company to fake variety. If you don't have a real brand mark, the chip pattern above is the only acceptable output.
