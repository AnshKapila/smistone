---
name: extracted-assets
description: >
  Use this skill whenever you are about to add, generate, or replace an image
  while building or editing a site — check first for curated images extracted
  from the user's reference website (products, team, work, customer logos,
  visual identity) and reuse a matching one instead of generating or fetching
  a new image. Applies even when the user does not mention the reference site.
mode: both
---

## On-disk source

When `docs/extracted_media.json` exists at the app root, treat it as the source of curated images for this site. It is the persisted output of the orchestrator's `extract_assets` tool — real images observed on a reference URL the user asked to reuse.

## Schema

```
{
  "url": "https://reference-site.example",
  "extracted_at": "ISO-8601 timestamp",
  "images": [
    { "url": "https://...", "role": "hero|product|team|customer-logo|...", "context": "one-sentence description" }
  ]
}
```

## How to use

- Prefer images from `docs/extracted_media.json` over newly-generated images when the role and context match the section being built or edited.
- Embed each chosen image by its `url` directly. Never fabricate URLs and never modify the URL string.
- If the file is missing, empty, or unreadable, fall back to the normal image flow (uploads, generation).
