---
name: website-carousel-building
description: "Build and edit carousels, sliders, marquees, image galleries, testimonial sliders, logo strips, and hero rotators using the Embla Carousel library via CDN. Use when generating or editing any horizontally-scrolling content section, when adding/removing slides, when changing autoplay/loop/dots/arrows behavior, or when fixing slider layout-shift, infinite-loop seam, or partial-edit drift issues. For Next.js iterations with an embedded CMS (block components), prefer the nextjs-website-carousel-building skill — this one keeps its own Next.js variant for classic iterations."
mode: both
---

# Carousel Rules

Use Embla Carousel for every horizontally-scrolling section: testimonials, product galleries, logo strips, hero rotators, screenshot carousels, "what we do" cards, image marquees.

## When to apply

Load this skill before writing or editing any of:

- Testimonial / quote sliders
- Product, portfolio, case-study, or screenshot carousels
- Image galleries with prev/next or dots
- Logo / partner / award strips (continuous autoplay marquees)
- Hero rotators (slide-in/slide-out hero variants)
- "Features", "Services", "Team" carousels on mobile
- Any user request that says "carousel", "slider", "swipe", "marquee", "ticker", "auto-scroll"

Never hand-roll a slider with manual `setInterval` + `transform: translateX(...)` — use Embla.

## Library setup (CDN, single-file prototype)

Add these scripts to `<head>` once per HTML file, alongside Tailwind and Lucide. Pin the version.

```html
<script src="https://unpkg.com/embla-carousel@8.3.0/embla-carousel.umd.js"></script>
<!-- Add plugins only when needed: -->
<script src="https://unpkg.com/embla-carousel-autoplay@8.3.0/embla-carousel-autoplay.umd.js"></script>
<script src="https://unpkg.com/embla-carousel-class-names@8.3.0/embla-carousel-class-names.umd.js"></script>
<script src="https://unpkg.com/embla-carousel-fade@8.3.0/embla-carousel-fade.umd.js"></script>
```

Globals exposed by these UMD builds: `EmblaCarousel`, `EmblaCarouselAutoplay`, `EmblaCarouselClassNames`, `EmblaCarouselFade`.

The prototype CDN allowlist already includes `unpkg`, so no config change is needed.

## Required DOM structure

```html
<div class="embla overflow-hidden" data-carousel>
  <div class="embla__container flex">
    <!-- slide width controls how many show at once: 100% = 1, 50% = 2, 33.333% = 3 -->
    <div class="embla__slide flex-[0_0_100%] min-w-0 px-3">...</div>
    <div class="embla__slide flex-[0_0_100%] min-w-0 px-3">...</div>
    <div class="embla__slide flex-[0_0_100%] min-w-0 px-3">...</div>
  </div>

  <!-- Optional controls -->
  <button class="embla__prev" aria-label="Previous slide">
    <i data-lucide="chevron-left"></i>
  </button>
  <button class="embla__next" aria-label="Next slide">
    <i data-lucide="chevron-right"></i>
  </button>
  <div class="embla__dots flex gap-2 justify-center mt-6"></div>
</div>
```

Required:

- **Infinite navigation loop is the default; autoplay is opt-in.** Every Kite carousel uses Embla's `loop: true` so prev/next wraps around at the ends — rely on the init code default and do not set `data-loop="false"` unless the user explicitly asks for a non-wrapping slider. Do **not** add `data-autoplay="…"` unless the user asks for auto-advance, or the recipe is intrinsically motion-driven (logo strip marquee, hero rotator). Default carousels move on user action only, so the user controls dwell time on each slide.
- `overflow-hidden` lives on the **embla viewport** (the outer `.embla`). Do **not** apply `overflow-hidden` to any ancestor that contains a `position: sticky` element — use `overflow-clip` on those instead.
- Slides use `flex-[0_0_X%]` (or `basis-X`) plus `min-w-0` so they keep their fixed width inside the flex container.
- Use responsive widths for breakpoints: `flex-[0_0_100%] md:flex-[0_0_50%] lg:flex-[0_0_33.333%]`.
- Do **not** set a fixed pixel height on the container that animates between slides — use natural height or `items-stretch` + matching slide content heights.
- `.embla__prev`, `.embla__next`, and `.embla__dots` may live either **inside** `.embla` or in a **sibling block under the same direct parent** (e.g. a header bar above the viewport or a centered footer row). The init code searches `root` first, then `root.parentElement` if that parent holds exactly one `[data-carousel]`. When two or more carousels share a parent, every carousel's controls MUST live inside its own `.embla`, otherwise the wrong carousel's buttons get wired.

## Initialization in the single-file prototype

The prototype renders routes via `app.innerHTML = \`...\`` inside `<script id="main_script">`. Carousels must be **re-initialized after every route render**, mirroring how `lucide.createIcons()` is re-run.

Add an `initCarousels()` function and call it from inside `render()` right after `lucide?.createIcons()`. Track active instances so they can be destroyed before re-init to avoid leaks across navigations.

```js
let _emblaInstances = [];

function initCarousels() {
  // Tear down old instances from the previous route render
  _emblaInstances.forEach(api => api.destroy());
  _emblaInstances = [];

  document.querySelectorAll('[data-carousel]').forEach(root => {
    const opts = {
      loop: root.dataset.loop !== 'false',
      align: root.dataset.align || 'start',
      dragFree: root.dataset.dragFree === 'true',
      slidesToScroll: Number(root.dataset.slidesToScroll || 1),
    };

    const plugins = [];
    if (root.dataset.autoplay && typeof EmblaCarouselAutoplay !== 'undefined') {
      plugins.push(
        EmblaCarouselAutoplay({
          delay: Number(root.dataset.autoplay) || 4000,
          stopOnInteraction: false,
          stopOnMouseEnter: true,
        })
      );
    }
    if (root.dataset.fade === 'true' && typeof EmblaCarouselFade !== 'undefined') {
      plugins.push(EmblaCarouselFade());
    }

    const api = EmblaCarousel(root, opts, plugins);
    _emblaInstances.push(api);

    // Controls usually live inside `.embla`, but layouts that center the
    // arrows in a header bar above/below put them in a sibling block. Allow
    // either by searching the immediate parent only when it owns exactly
    // one carousel — otherwise controls of a neighbouring carousel could
    // be hijacked.
    const parent = root.parentElement;
    const controlsScope =
      parent && parent.querySelectorAll('[data-carousel]').length === 1 ? parent : root;
    const prevBtn = controlsScope.querySelector('.embla__prev');
    const nextBtn = controlsScope.querySelector('.embla__next');
    const dotsContainer = controlsScope.querySelector('.embla__dots');

    prevBtn?.addEventListener('click', () => api.scrollPrev());
    nextBtn?.addEventListener('click', () => api.scrollNext());

    // Dots (optional — only build if container present).
    // Dot colors live in inline styles, not Tailwind classes, because the
    // Tailwind CDN's JIT can miss utilities that are only toggled at runtime
    // (the active class is never present at page-load, so it does not always
    // make it into the generated stylesheet). Inline styles always win the
    // cascade and never depend on JIT detection.
    if (dotsContainer) {
      const DOT_IDLE_BG = 'rgb(209, 213, 219)'; // gray-300
      const DOT_ACTIVE_BG = 'rgb(17, 24, 39)'; // gray-900
      const dots = api.scrollSnapList().map((_, i) => {
        const b = document.createElement('button');
        b.className = 'embla__dot w-2 h-2 rounded-full transition-colors';
        b.style.backgroundColor = DOT_IDLE_BG;
        b.setAttribute('aria-label', `Go to slide ${i + 1}`);
        b.addEventListener('click', () => api.scrollTo(i));
        return b;
      });
      dotsContainer.replaceChildren(...dots);
      const sync = () => {
        const selected = api.selectedScrollSnap();
        dots.forEach((d, i) => {
          d.style.backgroundColor = i === selected ? DOT_ACTIVE_BG : DOT_IDLE_BG;
        });
      };
      api.on('select', sync);
      api.on('reInit', sync);
      sync();
    }

    // Hide controls when the carousel has nothing to scroll to.
    // With `loop: true`, Embla disables containScroll, so scrollSnapList()
    // returns one snap per slide even when all slides fit the viewport.
    // Use canScrollPrev/Next, which respect actual reachable extent.
    // Dots also hide on multi-card layouts (≥2 cards visible) because a
    // single-active-dot indicator is ambiguous when several slides share
    // the viewport — arrows still work.
    const syncControls = () => {
      const hasOverflow = api.canScrollPrev() || api.canScrollNext();
      const firstSlide = root.querySelector('.embla__slide');
      const viewportW = root.clientWidth || 1;
      const slideRatio = firstSlide
        ? firstSlide.getBoundingClientRect().width / viewportW
        : 1;
      const isSingleCardView = slideRatio >= 0.8;
      prevBtn?.classList.toggle('hidden', !hasOverflow);
      nextBtn?.classList.toggle('hidden', !hasOverflow);
      dotsContainer?.classList.toggle('hidden', !hasOverflow || !isSingleCardView);
    };
    api.on('reInit', syncControls);
    api.on('resize', syncControls);
    syncControls();

    // Loop self-check: if `loop: true` was requested but Embla silently
    // disabled it (slide count below the loop minimum for the chosen
    // slides-per-view), the carousel renders as a static row or a non-
    // wrapping slider. Log once so the failure surfaces during development
    // instead of looking like a "broken" carousel. End users see nothing.
    if (opts.loop) {
      const totalSlides = api.slideNodes().length;
      const visibleSlides = api.slidesInView().length || 1;
      const loopMin = visibleSlides * 2 + 1;
      if (totalSlides < loopMin) {
        // eslint-disable-next-line no-console
        console.warn(
          `[carousel] loop: true requested but ${totalSlides} slide(s) ` +
            `is below the loop minimum of ${loopMin} for ${visibleSlides}-per-view. ` +
            `Add ${loopMin - totalSlides} more slide(s) or reduce slides-per-view. ` +
            `Embla disables loop silently in this state.`
        );
      }
    }
  });
}
```

`initCarousels()` hides `.embla__prev` / `.embla__next` whenever the carousel has nothing to scroll to (e.g. responsive slide widths make all slides fit at a given breakpoint), and additionally hides `.embla__dots` on multi-card layouts (slide width < ~80% of the viewport — i.e. 2-per-view, 3-per-view, logo strips). Dots are only useful when one slide owns the viewport; once 2+ cards are visible at once, a single-active-dot indicator does not map to anything the user can point at. Keep both behaviors — `scrollSnapList().length` alone is misleading because `loop: true` disables Embla's `containScroll`, so it returns one snap per slide even when the viewport already holds them all. The 80% threshold lets the "85% mobile peek" pattern still show dots while every 50%/33%/logo-strip layout hides them.

## Verify the carousel can actually scroll

Because controls auto-hide when nothing scrolls and `loop: true` cannot wrap a too-short slide list cleanly, a carousel built with too few slides renders as a static row — even with manual prev/next, the wrap-around either flickers or refuses to scroll. Every Kite carousel uses `loop: true`, so the loop-minimum column below always applies. Check the slide budget against the desktop breakpoint (the breakpoint with the most slides per view, i.e. the smallest slide width):

| Slide width on desktop | Slides per view | Min items for clean loop |
| --- | --- | --- |
| `flex-[0_0_100%]` | 1 | 3 |
| `flex-[0_0_50%]` | 2 | 5 |
| `flex-[0_0_33.333%]` | 3 | 7 |

Apply the slides-per-view requested by the user prompt:

- `slides per view: 1` → `flex-[0_0_100%]`
- `slides per view: 2` → `flex-[0_0_100%] md:flex-[0_0_50%]`
- `slides per view: 3` → `flex-[0_0_100%] md:flex-[0_0_50%] lg:flex-[0_0_33.333%]`

Count the entries in the data array that drives `.embla__container`. When the count is below the desktop minimum above, the carousel will not loop cleanly at the most common viewport — Embla silently disables `loop` when the slide budget is too thin, and the carousel either renders as a static row (slides fit the viewport exactly) or behaves as a non-wrapping slider with dead ends. Two paths:

- **Existing section being converted (orchestrator gating active).** Do **not** invent placeholder slides, duplicate existing slides, or silently degrade. Stop the edit and report back with: how many items the section has now, how many are needed for the requested slides-per-view, and one suggested resolution. The orchestrator has already pre-queried the count and will ask the user before retrying.
- **Brand-new carousel section being authored from scratch.** Generate at least the loop-minimum number of slides for the requested slides-per-view from the user's brand, content, and conversation context — same authoring quality as the rest of the page. If the user explicitly capped the item count below the minimum ("a carousel of my 2 products"), drop down to 1-slide-per-view AND set `data-loop="false"` on the root so the carousel becomes a non-wrapping slider with working prev/next ends instead of a broken loop.

Inside `render()`:

```js
route.render(params);
lucide?.createIcons();
initCarousels();        // <-- add this
announcePageChange(route.title);
```

## Recipes

### 1. Testimonial / product slider (manual, infinite wrap)

```html
<div class="embla overflow-hidden" data-carousel>
  <div class="embla__container flex">
    <!-- Slides driven by data.testimonials -->
  </div>
  <div class="flex items-center justify-between mt-6">
    <div class="embla__dots flex gap-2"></div>
    <div class="flex gap-2">
      <button class="embla__prev p-2 rounded-full border" aria-label="Previous">
        <i data-lucide="chevron-left" class="w-4 h-4"></i>
      </button>
      <button class="embla__next p-2 rounded-full border" aria-label="Next">
        <i data-lucide="chevron-right" class="w-4 h-4"></i>
      </button>
    </div>
  </div>
</div>
```

Generate slides from JSON data, never hard-code them in markup:

```js
const slides = data.testimonials.map(t => `
  <div class="embla__slide flex-[0_0_100%] md:flex-[0_0_50%] min-w-0 px-3">
    <blockquote class="...">${t.quote}</blockquote>
    <cite class="...">${t.author}</cite>
  </div>
`).join('');
```

### 2. Logo strip — continuous infinite marquee

Use `loop: true` + Autoplay with a small delay and `playOnInit: true`. Set `slidesToScroll: 1` and `align: 'start'`. Embla handles the seamless wrap internally — **do not duplicate the first slide** like a hand-rolled marquee would.

```html
<div
  class="embla overflow-hidden"
  data-carousel
  data-loop="true"
  data-autoplay="1500"
  data-slides-to-scroll="1"
>
  <div class="embla__container flex items-center">
    <!-- one slide per logo, no duplicates -->
  </div>
</div>
```

Pair with `dragFree: true` (set `data-drag-free="true"`) for a wheel-like continuous feel.

### 3. Hero rotator with fade

```html
<script src="https://unpkg.com/embla-carousel-fade@8.3.0/embla-carousel-fade.umd.js"></script>

<div class="embla relative" data-carousel data-autoplay="6000" data-loop="true" data-fade="true">
  <div class="embla__container flex">
    <div class="embla__slide flex-[0_0_100%] min-w-0">
      <img src="..." class="w-full h-[70vh] object-cover" />
    </div>
    <!-- more slides -->
  </div>
</div>
```

Fade slides keep stacking-context; the viewport does **not** need `overflow-hidden` when fade is used. The base `initCarousels()` above already pushes `EmblaCarouselFade()` into `plugins` whenever `data-fade="true"` is set and the plugin script is loaded.

### 4. Cards that swipe on mobile, sit static on desktop

Apply `flex-[0_0_85%] md:flex-[0_0_33.333%]` on `.embla__slide` and leave the carousel root as `data-carousel` only (no `data-autoplay`). On mobile the section behaves as a swipeable list with infinite wrap when the user drags or taps the arrows; on desktop the slides fit a single row, `canScrollPrev/Next` return false, and `syncControls` hides the arrows so Embla becomes an inert layout. No viewport gating or `resize` listener needed. This pattern still has to satisfy the loop-minimum table — at `slides per view: 3` you need 7+ items, otherwise drop to 2 per view (5+ items) or 1 per view (3+ items).

## Editing rules

When the user asks to change a carousel:

1. **Adding or removing slides** → edit the **data array** in `<script id="content">`, not the markup template. The renderer regenerates DOM; the carousel reinitializes on next render. Embla recomputes its scroll snaps automatically.
2. **Change autoplay speed** → edit `data-autoplay="<ms>"` on the carousel root, not the script. One value, one source of truth.
3. **Toggle loop / dots / arrows** → flip the `data-*` attribute or remove/add the `.embla__dots` / `.embla__prev` / `.embla__next` element. The init script reads the DOM each time.
4. **Change slides-per-view** → edit the `flex-[0_0_X%]` utility class on `.embla__slide`. Use responsive variants for breakpoints — do not duplicate slides.
5. **Change dot or arrow styling** → edit the Tailwind classes on the dot template inside `initCarousels()` for size/shape/transition, and edit the `DOT_IDLE_BG` / `DOT_ACTIVE_BG` constants for active vs idle color (inline styles — Tailwind JIT can miss runtime-toggled utilities). Arrows still use Tailwind classes in markup on `.embla__prev` / `.embla__next`.
6. **Add a brand-new carousel section** → add the DOM structure + the data entries; you do not need to extend `initCarousels()` unless you introduce a new plugin variant (fade, class-names, autoplay).
7. **Fix a "stuck" carousel after route change** → confirm `initCarousels()` is called from `render()` after `lucide?.createIcons()`, and that the old instances are destroyed before re-init.

## Never do

- Apply scroll-reveal, fade-in, or any class that sets `transform` or `transition: transform …` to `.embla__container` (e.g. a `.reveal` / `.animate-in` / `data-aos` class on the same element). Embla owns the `transform` of that element and writes `translate3d(...)` on every tick — a transform `transition` makes every drag and snap animate over the reveal duration (carousel looks stuck), and the pre-active `translateY(...)` makes Embla measure a translated container. Put reveal classes on the outer `.embla` viewport or a wrapping section instead.
- Animate the container `height` between slides — causes layout shift. Let the container size to the tallest slide, or set a fixed height with `items-stretch` on equal-height content.
- Apply `overflow-hidden` to a section that contains `position: sticky` descendants. Use `overflow-clip` on those ancestors.
- Duplicate the first slide manually for a "seamless loop". Embla's `loop: true` handles wrap-around. Duplicates create double-render artifacts on resize.
- Render carousel slides directly into HTML markup when the data lives in the JSON `<script id="content">` block — keep one source of truth.
- Wire prev/next/dots before `EmblaCarousel(...)` is constructed — `api.scrollSnapList()` returns empty until init.
- Drive a carousel with `setInterval` + manual transforms when Embla is already loaded on the page.
- Add a global `.embla__slide { flex: 0 0 X% }` rule (or any other global `.embla__slide` width / `flex-basis` selector) in a `<style>` block or external stylesheet. Slide widths belong on the per-slide Tailwind class (`flex-[0_0_X%]`, `md:flex-[0_0_50%]`, etc.) so every carousel on the page can pick its own slides-per-view. A global rule loaded after the Tailwind CDN wins the cascade and silently overrides every carousel's intended width — including the one you just authored.

## Next.js variant (when editing a Next.js project)

If the project uses the App Router stack (`frontend/src/app/**`) AND
`embla-carousel-react` is already in the installed dependencies, use the React
wrapper instead of the UMD build. Do NOT add the package yourself —
`package.json` is platform-managed and cannot be edited here (no `pnpm add`).
When the package is not installed, build the carousel from React + Tailwind
(the patterns above), or report that `embla-carousel-react` is needed so the
platform can add it before you continue.

```tsx
'use client';
import useEmblaCarousel from 'embla-carousel-react';

export function Carousel({ slides }: { slides: Slide[] }) {
  // Default: infinite wrap, manual navigation only. Add Autoplay({ delay: … }) as
  // a second arg to useEmblaCarousel ONLY when the user asked for auto-advance.
  const [emblaRef] = useEmblaCarousel({ loop: true });
  return (
    <div className="overflow-hidden" ref={emblaRef}>
      <div className="flex">
        {slides.map(s => (
          <div key={s.id} className="flex-[0_0_100%] min-w-0 px-3">{s.content}</div>
        ))}
      </div>
    </div>
  );
}
```

Same composition rules apply: slide width is `flex-[0_0_X%]`, viewport is `overflow-hidden`, never animate container height, never hand-duplicate slides for loop.
