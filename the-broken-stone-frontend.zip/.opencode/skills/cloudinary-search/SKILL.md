---
name: cloudinary-search
description: "Use this skill when you need to find an image already uploaded for this website — the user mentions a photo or logo they shared earlier ('the team photo I shared', 'the logo I attached'), you need the URL of an asset generated earlier in the conversation before embedding it, or you want to check what assets already exist before fetching anything external. Prefer this over generating or downloading a new image when something usable may already be there, even when the user does not explicitly say 'search' or 'find'."
mode: sandbox
---

# cloudinary-search

Lists files under the current website's Cloudinary folder (`$CLOUDINARY_PREFIX = app/$APPLICATION_ID`). Use this before reaching for an external asset — an asset already on the website's CDN is always preferable.

## When to reach for this

- The user mentions an image they uploaded ("the team photo I shared", "the logo I attached").
- You generated an image earlier in the conversation and need its URL to embed.
- You need to know what assets already exist for this website.

## Call it

Cloudinary's resource-search uses basic auth:

```bash
curl -sS -u "$CLOUDINARY_API_KEY:$CLOUDINARY_API_SECRET" \
  -G "https://api.cloudinary.com/v1_1/$CLOUDINARY_CLOUD_NAME/resources/search" \
  --data-urlencode "expression=folder:$CLOUDINARY_PREFIX/*" \
  --data-urlencode "max_results=30" \
  --data-urlencode "with_field=context" \
  --data-urlencode "with_field=tags"
```

To filter by content type, append ` AND resource_type:image` (or `video`, `raw`) to the `expression`.

## Read the response

Each entry in `resources[]` has:

- `secure_url` — the CDN URL you embed in HTML
- `filename`, `format`, `bytes`, `width`, `height`
- `tags` — AI-generated content tags
- `context.custom.alt`, `context.custom.caption` — human-set metadata

Cloudinary's search expression has limited text-matching, so for keyword filtering (e.g. "team photo") pull the folder and filter client-side on filename, tags, alt, and caption — matching any of those fields is a hit.

## Env vars

- `$CLOUDINARY_CLOUD_NAME`, `$CLOUDINARY_API_KEY`, `$CLOUDINARY_API_SECRET` (never echo)
- `$CLOUDINARY_PREFIX` — the website's folder, always `app/$APPLICATION_ID`
