"""Orchestrator tools for managing website workflows."""

from __future__ import annotations

from uuid import UUID

from app.config import get_settings
from app.database import website_db
from app.llm.infra.types import ToolError, ToolResult
from app.llm.orchestrator_agent.tools._base import get_run_context, register_tool
from app.services import workflow_service
from app.utils.db_session import get_async_session_maker


def _error(code: str, message: str) -> ToolResult:
    return ToolResult(
        status="error",
        error=ToolError(
            code=code,
            message=message,
            retryable=False,
            handled_by="service",
        ),
    )


def _serialize_workflow(workflow) -> dict:
    return {
        "id": str(workflow.id),
        "team_id": str(workflow.team_id),
        "application_id": str(workflow.application_id) if workflow.application_id else None,
        "cron_expression": workflow.cron_expression,
        "prompt": workflow.prompt,
        "title": workflow.title,
        "enabled": workflow.enabled,
        "created_at": workflow.created_at.isoformat() if workflow.created_at else None,
        "updated_at": workflow.updated_at.isoformat() if workflow.updated_at else None,
    }


async def _require_context() -> tuple[UUID, str, str, UUID, UUID | None] | ToolResult:
    """Resolve the workflow's owning team from the website the user is editing.

    Workflows are team-owned, but the conversational surface is a website chat,
    so the team is derived from the active website. Returns
    ``(team_id, creator_id, creator_email, application_id, source_thread_id)``.
    """
    run_context = get_run_context()
    if run_context.get("source_channel") == "scheduler":
        return _error(
            "scheduler_recursion_blocked",
            "Scheduled runs cannot create, update, list, or delete workflows.",
        )

    application_id = run_context.get("application_id")
    creator_id = run_context.get("creator_id")
    creator_email = run_context.get("creator_email")
    if not application_id or not creator_id or not creator_email:
        return _error("missing_context", "Missing website or user context for workflow tool.")

    app_uuid = UUID(str(application_id))
    source_thread_id = run_context.get("thread_id")
    session_maker = get_async_session_maker(get_settings())
    async with session_maker() as db_session:
        team_id = await website_db.get_team_id_for_website(db_session, app_uuid)
    if team_id is None:
        return _error("team_not_found", "Could not resolve the team for the current website.")

    return (
        team_id,
        str(creator_id),
        str(creator_email),
        app_uuid,
        UUID(str(source_thread_id)) if source_thread_id else None,
    )


@register_tool
async def create_workflow(cron_expression: str, prompt: str, title: str) -> ToolResult:
    """Create a UTC cron workflow for recurring team work.

    Args:
        cron_expression: Five-field UTC cron expression.
        prompt: The exact instruction sent to the team CMO at trigger time.
        title: Short display name (at most 6 words) shown in the workflows UI.
    """
    context = await _require_context()
    if not isinstance(context, tuple):
        return context
    team_id, creator_id, creator_email, application_id, source_thread_id = context
    session_maker = get_async_session_maker(get_settings())
    async with session_maker() as db_session:
        try:
            workflow = await workflow_service.create_workflow(
                db_session,
                team_id=team_id,
                creator_id=creator_id,
                creator_email=creator_email,
                application_id=application_id,
                source_thread_id=source_thread_id,
                cron_expression=cron_expression,
                prompt=prompt,
                title=title,
            )
            await db_session.refresh(workflow)
            serialized = _serialize_workflow(workflow)
            await db_session.commit()
        except ValueError as e:
            await db_session.rollback()
            return _error("invalid_workflow", str(e))

        return ToolResult(status="success", result={"workflow": serialized})


@register_tool
async def list_workflows(include_disabled: bool = False) -> ToolResult:
    """List recurring workflows for the current team.

    Args:
        include_disabled: Include disabled workflows when true.
    """
    context = await _require_context()
    if not isinstance(context, tuple):
        return context
    team_id, _creator_id, _creator_email, _application_id, _source_thread_id = context
    session_maker = get_async_session_maker(get_settings())
    async with session_maker() as db_session:
        workflows = await workflow_service.list_workflows(
            db_session,
            team_id=team_id,
            include_disabled=include_disabled,
        )
        return ToolResult(
            status="success",
            result={"workflows": [_serialize_workflow(workflow) for workflow in workflows]},
        )


@register_tool
async def update_workflow(
    workflow_id: str,
    cron_expression: str | None = None,
    prompt: str | None = None,
    enabled: bool | None = None,
) -> ToolResult:
    """Update a recurring workflow for the current team.

    Args:
        workflow_id: Workflow UUID to update.
        cron_expression: Optional replacement five-field UTC cron expression.
        prompt: Optional replacement prompt.
        enabled: Optional enabled/disabled state.
    """
    context = await _require_context()
    if not isinstance(context, tuple):
        return context
    team_id, _creator_id, _creator_email, _application_id, _source_thread_id = context
    try:
        workflow_uuid = UUID(workflow_id)
    except ValueError:
        return _error("invalid_workflow_id", "workflow_id must be a UUID.")

    session_maker = get_async_session_maker(get_settings())
    async with session_maker() as db_session:
        try:
            workflow = await workflow_service.update_workflow(
                db_session,
                workflow_id=workflow_uuid,
                team_id=team_id,
                cron_expression=cron_expression,
                prompt=prompt,
                enabled=enabled,
            )
            await db_session.refresh(workflow)
            serialized = _serialize_workflow(workflow)
            await db_session.commit()
        except ValueError as e:
            await db_session.rollback()
            return _error("invalid_workflow", str(e))

        return ToolResult(status="success", result={"workflow": serialized})


@register_tool
async def delete_workflow(workflow_id: str) -> ToolResult:
    """Soft-delete a recurring workflow for the current team.

    Args:
        workflow_id: Workflow UUID to delete.
    """
    context = await _require_context()
    if not isinstance(context, tuple):
        return context
    team_id, _creator_id, _creator_email, _application_id, _source_thread_id = context
    try:
        workflow_uuid = UUID(workflow_id)
    except ValueError:
        return _error("invalid_workflow_id", "workflow_id must be a UUID.")

    session_maker = get_async_session_maker(get_settings())
    async with session_maker() as db_session:
        try:
            workflow = await workflow_service.delete_workflow(
                db_session,
                workflow_id=workflow_uuid,
                team_id=team_id,
            )
            await db_session.refresh(workflow)
            serialized = _serialize_workflow(workflow)
            await db_session.commit()
        except ValueError as e:
            await db_session.rollback()
            return _error("invalid_workflow", str(e))

        return ToolResult(status="success", result={"workflow": serialized})
