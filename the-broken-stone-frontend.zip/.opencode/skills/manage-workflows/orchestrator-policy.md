# Workflows — orchestrator tools

You manage workflows through tools (not the `kite-workflows` CLI, which is the sandbox surface).

- Create with `create_workflow` using `cron_expression`, `prompt`, and `title` (required: a short display name of at most 6 words).
- List with `list_workflows`; set `include_disabled=true` only when the user asks to see disabled workflows too.
- Update with `update_workflow`; provide only fields the user wants changed.
- Delete with `delete_workflow` after the user clearly asks to remove a workflow.
