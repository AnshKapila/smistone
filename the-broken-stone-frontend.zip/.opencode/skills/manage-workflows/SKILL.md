---
name: manage-workflows
description: >
  Use this skill when the user wants recurring work, scheduled edits,
  automation, or periodic checks, such as "update my site every Monday",
  "send me a weekly report", "schedule this task", or "show my scheduled
  automations". Skip this skill for one-time edits the user wants done now.
mode: both
agent_policies:
  orchestrator: orchestrator-policy.md
---

# Manage Workflows

Use this skill to create, list, update, or remove recurring workflows for the current team.

## Hard requirements

- These requirements take precedence over the supporting rules below.
- Before creating a workflow, first list existing workflows, then verify every required third-party app is connected. Do not create it until both checks pass.
- Change an existing workflow in place when the user's request refers to its current purpose or cadence. Preserve its id and every field the user did not ask to change.
- Never create a second workflow to override or replace an existing workflow.
- Verify the returned id, prompt, timing, assignee, and enabled state before reporting success.

## Rules

- Ask what should happen and when in the user's own words. You translate the timing into cron yourself; never ask the user for cron syntax or show it to them.
- If timing is ambiguous, ask one plain-language clarifying question ("Which timezone should I use?"). Do not guess time zones or dates.
- The user is a marketer: describe a workflow by what it will do for them and when ("Every Monday morning I'll check your traffic and send you a summary"), not by its prompt, cron, or plumbing.
- Workflows run unattended in a fresh thread, so a missing app connection makes every run fail. List the third-party apps the recurring work needs and verify each connection; when one is missing, follow `tool-discovery-execution`'s connect recipe and wait until the user completes the connection.
- Workflows belong to the team.
- Write the prompt as a self-contained instruction because each workflow run opens a fresh team-level thread — name the apps to use and the delivery the user chose.
- If the list of workflows is empty, tell the user no workflows are currently active and offer to create one.
- When the user asks to change, replace, reschedule, pause, or resume recurring work that already exists, update that workflow in place so its id and run history remain intact.

## Cron grammar

- Five space-separated fields, in order: `minute hour day_of_month month day_of_week`, all UTC.
- Each field is `*`, a number, a list (`1,15`), a range (`1-5`), or a step (`*/15`).
- `day_of_week` is `0`–`6` with `0` = Sunday.
- Examples: `0 9 * * 1` = Mondays 09:00 UTC; `*/30 * * * *` = every 30 minutes; `0 0 1 * *` = first of each month 00:00 UTC.

## Sandbox (CMO) — `kite-workflows` CLI

In the sandbox, manage workflows with the `kite-workflows` CLI. The team is resolved from your thread token; you do not pass it.

- Create: `kite-workflows create "<cron_expression>" "<prompt>" "<title>"` — prints the created workflow as JSON (with its `id`) on success. The title is required: a short display name (at most 6 words, e.g. `Daily Pokemon Poem`) shown in the workflows UI.
- List: `kite-workflows list` — prints all team workflows, including paused ones, as JSON.
- Update: `kite-workflows update "<workflow_id>" [--cron "<cron_expression>"] [--prompt "<prompt>"] [--title "<title>"] [--assignee "<agent-name>"] [--enable|--disable]` — changes only the supplied fields and prints the updated workflow as JSON. Copy the id from `list`; preserve fields the user did not ask to change.
- Delete: `kite-workflows delete "<workflow_id>"` — removes one workflow (exit 0 on success).

Confirm the create or update response contains the expected `id`, prompt, timing, assignee, and enabled state before telling the user it changed. For deletion, confirm the command exits successfully. On failure, follow the shared single-retry rule and never claim the workflow changed without the expected result.
