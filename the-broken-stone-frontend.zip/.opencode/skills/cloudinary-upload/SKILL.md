---
name: cloudinary-upload
description: "Use this skill whenever a local image file needs to become a permanent embeddable URL the website can reference — after generating, downloading, screenshotting, or otherwise producing an image on disk. Triggers any time the next step is to put an on-disk image into the site, even when the user does not explicitly say 'upload'."
mode: sandbox
---

# cloudinary-upload

Cloudinary requires signed uploads — the signature is SHA-1 of the alphabetically-sorted params concatenated with the API secret. Six lines of bash.

## When to reach for this

- Any time a local file needs to become a `https://static.kite.ai/...` URL usable by the site.

## Call it

```bash
PUBLIC_ID="$CLOUDINARY_PREFIX/hero-image"       # pick a descriptive ID
TIMESTAMP=$(date +%s)
SIG_PARAMS="public_id=$PUBLIC_ID&timestamp=$TIMESTAMP"
SIGNATURE=$(printf '%s%s' "$SIG_PARAMS" "$CLOUDINARY_API_SECRET" | sha1sum | awk '{print $1}')
curl -sS -X POST "https://api.cloudinary.com/v1_1/$CLOUDINARY_CLOUD_NAME/image/upload" \
  -F "file=@/path/to/local/image.png" \
  -F "public_id=$PUBLIC_ID" \
  -F "timestamp=$TIMESTAMP" \
  -F "api_key=$CLOUDINARY_API_KEY" \
  -F "signature=$SIGNATURE"
```

Read `secure_url` from the response — that's the CDN URL to embed.

## Signing rules

If you add or remove upload parameters (e.g. `tags`, `context`, `folder`), **every param that gets signed must be included in `SIG_PARAMS` in alphabetical order** before the secret is appended, otherwise Cloudinary rejects the signature. Do not sign `file`, `api_key`, or `signature` itself.

Example with tags:

```bash
SIG_PARAMS="public_id=$PUBLIC_ID&tags=ui,homepage&timestamp=$TIMESTAMP"
```

Note the alphabetical order: `public_id` < `tags` < `timestamp`.

## Env vars

- `$CLOUDINARY_CLOUD_NAME`, `$CLOUDINARY_API_KEY`, `$CLOUDINARY_API_SECRET` (never echo)
- `$CLOUDINARY_PREFIX` — always `app/$APPLICATION_ID`; prepend to your `public_id` so assets stay scoped to this website.
