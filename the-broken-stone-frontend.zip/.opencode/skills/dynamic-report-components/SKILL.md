---
name: dynamic-report-components
description: >
  Use this skill when a task result should include live data that stays
  current every time the report is opened — a chart, table, single metric, or
  list, including derived numbers like gaps, ratios, or computed rankings.
  E.g. "give me a report on GitHub stars for these repos", "chart signups
  from our analytics", "show current open issues in a table", or any report
  where the reader should see today's numbers, not the numbers from when the
  task ran. Works for any data reachable through the team's connected
  integrations. For static or historical numbers, write a normal markdown
  table or list instead.
mode: sandbox
---

# Dynamic Report Components

Embed live data in a task result. You pin the data query at task time; the
platform replays it every time someone opens the report, so the component
always shows current numbers. The result markdown itself stays static — each
component tag carries a static fallback for surfaces that can't render live
data.

## Delegating agents: route it, don't author it

If you are a conversational agent (`THREAD_ID` set), you cannot author these
components — they only work in a **task result**. Delegate instead (per
`work-delegation`): assign the task to `research` or `analyst`,
and say in the task description that the report should use live dynamic
components for the current numbers. This overrides the usual
route-reports-to-`internal-dashboard-engineer` rule when the deliverable is a
task report with live numbers rather than a standalone hosted page. Tell the user
the live report will be on the task's page. The rest of this skill is for
the task agent that writes the result.

Two artifacts make one component work, and both are required:

1. A **query spec** file in `$TASK_ARTIFACTS_DIR` describing the data fetch.
2. A **component tag** in the result markdown you pass to `set-task-result`,
   referencing that spec by name.

## Step 1 — verify the query works

Any tool the team's tool gateway can execute can be pinned — `native:*`
platform tools, `pipedream:*` actions, and `mcp:*` tools for the team's
connected apps and MCP servers (discover and run them per
`tool-discovery-execution`). Before pinning anything, run the exact call
yourself and confirm the fields you need exist.

For GitHub, use the CLI:

```sh
kite-github api GET /repos/vuejs/vue
```

For a connected app (analytics, CRM, sheets, …), run the tool through the
`kite-integrations` CLI (it resolves scope, token, and URL from the env) with the
same `tool_name` and `params` you intend to pin:

```sh
kite-integrations execute pipedream:posthog-get-insight '{"insight_id": "..."}'
```

Save the response — the `result` object in it is exactly what the replay will
hand to your extraction paths or transform later, so shape your paths against
it (see the envelope note in the rules below).

Only pin what you verified. If the provider answers with a redirect (e.g.
GitHub HTTP 301 for a moved repo), pin the canonical path — a redirecting
call will break the live component later even if it seems to work now.

## Step 2 — write the query spec

Write `$TASK_ARTIFACTS_DIR/<name>.query.json`. The `<name>` must match
`[A-Za-z0-9][A-Za-z0-9_-]*` (e.g. `repo-stats`, `latest-releases`).

The spec produces a small table — named **columns**, plus **rows** — that any
component can render. Two modes:

**Row per call** (compare a few things): each call yields one row, named by
its `label` (which becomes an implicit leading `label` column):

```json
{
  "version": 1,
  "calls": [
    { "label": "react", "tool": "native:github-api-request",
      "params": { "method": "GET", "path": "/repos/react/react" } },
    { "label": "vue", "tool": "native:github-api-request",
      "params": { "method": "GET", "path": "/repos/vuejs/vue" } }
  ],
  "extract": {
    "columns": [
      { "name": "stars", "path": "$.body.stargazers_count" },
      { "name": "forks", "path": "$.body.forks_count" }
    ]
  },
  "ttl_seconds": 300
}
```

**Rows from one call** (a list the API returns): exactly one call; `rows`
selects the array, column paths resolve per element:

```json
{
  "version": 1,
  "calls": [
    { "tool": "native:github-api-request",
      "params": { "method": "GET", "path": "/repos/react/react/releases",
                  "query": { "per_page": "5" } } }
  ],
  "extract": {
    "rows": "$.body[*]",
    "columns": [
      { "name": "name", "path": "$.name" },
      { "name": "published", "path": "$.published_at" }
    ]
  },
  "ttl_seconds": 300
}
```

The same two modes work for connected apps — only the tool name and the
response envelope change. A `pipedream:*` tool's value lives under `$.ret.`
(here, one analytics call returning all variants of an experiment):

```json
{
  "version": 1,
  "calls": [
    { "tool": "pipedream:posthog-get-experiment",
      "params": { "experiment_id": "cta-color-test" } }
  ],
  "extract": {
    "rows": "$.ret.results.variants[*]",
    "columns": [
      { "name": "variant", "path": "$.key" },
      { "name": "conversion", "path": "$.conversion_rate" }
    ]
  },
  "ttl_seconds": 900
}
```

(Discover the real tool name and params per `tool-discovery-execution` — do
not copy this one blind.)

Rules:

- Each call names its own `tool` — any `native:*` or `pipedream:*` tool the
  gateway executes. One spec may mix providers (a GitHub number next to an
  analytics number), but any failed call fails the whole component.
- **Pin reads only, never writes.** Opening the report replays the pinned
  calls, so a pinned write (`create`, `send`, `update`, `delete`, …) would
  fire on every view by every viewer. Only pin tools that fetch data (GET
  requests, `get`/`list`/`search`/`query`-style actions).
- Extraction paths use a tiny subset of JSONPath: `$` root, dotted field
  names, and `[*]` to descend into a list (e.g. `$.body.items[*].count`).
  Nothing else — no filters, slices, computation, or expressions. Every
  column path must land on a scalar (string/number/bool/null), never an
  object.
- Need a **computed** value (delta, ratio, sum, sort) the API doesn't return
  directly? Use a transform (next section) instead of `extract`.
- **Paths resolve against each tool's response envelope**, which differs by
  provider: `native:github-api-request` wraps the GitHub payload as
  `{"status": ..., "body": ...}` (paths start `$.body.`); `pipedream:*`
  tools return `{"exports": ..., "ret": ...}` with the provider's value in
  `ret` (paths start `$.ret.`); `mcp:*` tools return whatever shape that MCP
  server defines. Don't guess — shape paths against the `result` object you
  saved in Step 1.
- In row-per-call mode the **same column paths apply to every call**, so
  mixing providers with different envelopes in one `extract` spec won't
  resolve — use a transform for cross-provider components (it sees each raw
  result and can index into each shape).
- `ttl_seconds` (default 900) is how long the platform caches a fetch before
  hitting the provider again. Use 300–900 for counts that move slowly.
- Several components may share one spec (e.g. a chart and a table of the
  same data) — the cache collapses them into one upstream fetch.

## Step 2b — transforms, for values the API doesn't return

When the numbers you want are *derived* (react's lead over vue, stars per
fork, a top-5 sorted by a computed score), declarative `extract` can't help —
pin a **transform script** instead. Replace `extract` with `transform` in the
spec:

```json
{
  "version": 1,
  "calls": [
    { "label": "react", "tool": "native:github-api-request",
      "params": { "method": "GET", "path": "/repos/react/react" } },
    { "label": "vue", "tool": "native:github-api-request",
      "params": { "method": "GET", "path": "/repos/vuejs/vue" } }
  ],
  "transform": "star-gap.transform.js",
  "ttl_seconds": 300
}
```

and write `$TASK_ARTIFACTS_DIR/star-gap.transform.js` — **JavaScript**, a
single pure function:

```js
function transform(results) {
  const react = results[0].body.stargazers_count;
  const vue = results[1].body.stargazers_count;
  return {
    columns: ["metric", "value"],
    rows: [
      { metric: "gap", value: react - vue },
      { metric: "ratio", value: Number((react / vue).toFixed(2)) }
    ]
  };
}
```

Contract and limits:

- `results` is the array of raw gateway responses, one per call, in spec
  order. Return `{columns: [...], rows: [{...}]}` — same shape `extract`
  produces. Cells must be scalars.
- The script runs **sandboxed on the platform**: no network, no filesystem,
  no environment, ~2 seconds of CPU, 64 MB of memory. `fetch`, `require`,
  `process`, and module imports do not exist — pure computation only.
  Anything beyond the limits fails the component (fallback renders).
- `extract` and `transform` are mutually exclusive — exactly one per spec.
- **Prefer `extract` whenever it suffices**: it is auditable data, cheaper,
  and can't fail at runtime. Reach for a transform only when the value
  genuinely must be computed.
- Test the logic before pinning: run your calls as in Step 1, then run the
  function against the saved responses with `node` in the sandbox.

## Step 3 — embed component tags in the result

In the markdown you pass to `set-task-result`. Pick the component that fits
the data:

```markdown
<kite-chart query="repo-stats" type="bar" y="stars" title="GitHub stars">
Star counts at task time: react ~238k, vue ~210k.
</kite-chart>

<kite-table query="repo-stats" title="Repository stats">
At task time: react — 238k stars, 48k forks; vue — 210k stars, 33k forks.
</kite-table>

<kite-metric query="repo-stats" value="stars" title="react stars">
~238k stars at task time.
</kite-metric>

<kite-list query="latest-releases" title="Latest releases" primary="name" secondary="published">
Latest release at task time: 19.1.0.
</kite-list>
```

Attributes:

- `query` — the spec filename without `.query.json` (required, all tags).
- `title` — short caption (all tags).
- `<kite-chart>`: `type` — `bar` (default) or `line`; `x`/`y` — column names
  for the axes (default: first column / first numeric column).
- `<kite-metric>`: `value` — column holding the number (default: first
  numeric column); reads the **first row** only.
- `<kite-list>`: `primary`/`secondary` — item text and trailing value
  columns (default: first and second columns).
- `<kite-table>` renders all columns; no extra attributes.
- The tag's **inner text is the static fallback**: write the actual numbers
  you fetched in Step 1, so the report still informs when live data can't
  load (integration disconnected, surface without live rendering). Never
  leave it empty.

## Gotchas

- **No connection, no live component.** The replay runs on the team's
  connections. If Step 1 fails with `provider_not_connected` (409), skip the
  live component for that data and report plain numbers — it would only ever
  render its fallback. Never pin a call you couldn't run yourself.
- Live components render on the task's detail page. Chat replies and other
  surfaces show the fallback text — that is by design, not a failure.
- Any failed call fails the whole component (fallback renders); there is no
  partial data. Don't mix a flaky query into a spec other components depend
  on.
