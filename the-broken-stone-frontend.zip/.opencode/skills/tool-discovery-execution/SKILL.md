---
name: tool-discovery-execution
description: "Use this skill to discover and invoke the team's connected third-party integrations (Notion, HubSpot, Google Sheets, and 300+ apps via Pipedream), Slack via the native Kite bot, GitHub via the native GitHub App, plus other platform-native tools, through the tool gateway. Triggers on 'send a slack message', 'create a github issue/PR', 'call the github api', 'create a calendar event', 'add a row to the sheet', 'search the team's notion', 'use the connected <app>', 'what tools/integrations are available', on questions only the team's data can answer ('why isn't my website converting'), whenever a task or skill names a `native:` tool or the platform enrichment catalog, and whenever the user shares a link into one of these apps to read, summarize, or import — check connected apps via this skill before declaring such a link private or unreachable. For searching or reading the public web, use web-research; for public website URLs shared as design references, use website-design-content-extraction."
mode: sandbox
notification_title: "Using integrations"
agent_policies:
  orchestrator: orchestrator-policy.md
---

# tool-discovery-execution

Use the `kite-integrations` CLI (via the `bash` tool) to call the tool gateway. The gateway is team-scoped and only exposes apps the team has connected. The CLI resolves the scope (`$TEAM_ID` if set, otherwise `$APPLICATION_ID`), token, and URL from the env — you never handle auth or identifiers yourself. In a sandbox without `kite-integrations` on PATH (e.g. the website orchestrator's), use the raw-endpoint fallback at the end of this section instead — same requests, hand-built. Workflow is always **search → describe → execute**:

1. `search` — find what's available (connected apps, matching tools).
2. `describe` — get a tool's input schema. Do this before the first execution of any tool; do not guess parameter names.
3. `execute` — run it.

Tool names are namespaced: `pipedream:<component_key>` for third-party actions, `native:<slug>` for platform tools. Native tools listed with an `endpoint` (e.g. image generation) are the same tools documented in their own skills — prefer those skills' recipes; this gateway lists them for discovery.

A question only the team's data can answer ("why isn't my website converting?", "how are we ranking?") is a tool request with no app named. Decide what data answers it, then run the same workflow: answer from platform-native tools and connected apps first, and when a needed source lives in an unconnected account (their analytics, ads, CRM), follow **Recipe: connect an unconnected integration** — report what you can already see and what the connection adds, rather than answering from general knowledge alone.

**Slack and GitHub are native, not Pipedream.** To post to Slack use the `kite-slack` CLI; to call GitHub use the `kite-github` CLI (recipes below). Both go through the platform's own connectors — posting/acting as Kite — and are always available without a Pipedream connection. Neither appears in `connected_apps` and there is no `pipedream:slack*` / `pipedream:github*` tool, so don't search for or expect a Pipedream Slack/GitHub app.

## Resolve access first — don't make the user choose the method

Whenever a task needs to reach an external service — log into a site, pull data from it, post to it — **start by resolving how to reach it, then act in the same turn.** Do not ask the user "should I use the integration or the browser?" or wait to be told to check a login; decide from what's already available.

```bash
kite-integrations resolve x.com        # a domain…
kite-integrations resolve notion       # …or an app name
```

It returns `recommendation` plus a `next` field with the exact command to run. Act on it, best path first:

| `recommendation`          | What it means → what you do |
| ------------------------- | --------------------------- |
| `use_integration`         | The app is already connected. Go straight to `search`/`describe`/`execute` — no browser, no connect link. |
| `use_browser_login`       | A saved browser login exists for this service. Use the **browser-session** skill with `--profile <label>` — it's already logged in; do **not** ask the user to log in again unless it has expired. |
| `offer_pipedream_connect` | Not connected and no saved login, but it's a supported Pipedream app. Follow **Recipe: connect an unconnected integration** — mint the link, hand back one `<connect-cta>`. |
| `offer_mcp`               | A custom/platform MCP server can serve it. `kite-integrations connect <slug>` and hand back the `<connect-cta>` (or tell the user they can add a custom MCP server in Integrations). |
| `offer_browser`           | Nothing native and no saved login. Offer a **browser-session** handoff (the browser-session skill), or a custom MCP if the service has one. |

The order is deliberate: a connected integration beats a browser login (more robust), a **saved** browser login beats asking the user to connect a fresh integration (zero friction), and only when nothing is ready do you offer — Pipedream first, then a custom MCP, then the browser. Resolve is read-only: it recommends, you run the follow-up command it names. If `resolve` isn't on PATH (an app/website sandbox with no `TEAM_ID`), fall back to the manual sequence: bare `search` (connected?) → `kite-browser profiles` (saved login?) → `catalog-search`/`connect` or a browser handoff.

## Gotchas

- **Never guess `app` slugs — copy them verbatim from `connected_apps`.** Run a bare search first; its `connected_apps[].name_slug` values come straight from the provider's connected-accounts list and are the *only* valid `app` values. The connected slug often differs from the brand name and is sometimes version-suffixed — e.g. an app connected as `<brand>_v2` rather than `<brand>`. Passing a brand name you assumed when the account uses a different slug returns `409 provider_not_connected` even though the app is connected. Connections are also more granular than brands: `google_sheets`, `google_drive`, and `google_docs` are three separate apps, and a team that "connected Google" usually has one of them (a similar app may cover the request — see the Google-file recipe below). Always take the exact `name_slug` from `connected_apps` and use it unchanged in `app` and as the prefix of the tool name.
- **Quote the params JSON in single quotes.** The params argument is one JSON object string (`'{"title": "…"}'`); double-quoting it invites shell expansion inside the JSON.
- **Search with single keywords.** The vendor search ANDs multi-word queries ("send message" can return nothing where "message" matches). Start broad.
- **Pass default `timeout: 120000` to bash for `execute`.** Third-party actions run provider code and can exceed the default 2-minute timeout. If a specific action is known to be slower, increase the timeout proportionally. If it times out, surface the timeout error to the user rather than retrying blindly.
- **Results are real side effects.** A successful write action (a `kite-slack send`, a `kite-github api POST …`, or a `pipedream:*` create) really posts/changes data. Don't re-run a succeeded write to "verify" it.
- **Reduce large results in the sandbox before they reach you.** Whatever your `bash` command prints to stdout is what enters your context — so a list/search response piped through `python3 -m json.tool` dumps the entire payload and can blow the context window. Instead, parse and project in the sandbox first: pipe the response through `jq` (or `python3`) to keep only the fields you need, push filtering to the provider (date ranges, `state`, query params) so it returns fewer/leaner objects, and bound page size with `per_page` so each fetched page stays under the gateway's response cap (a truncated page is not valid JSON and won't parse). Print the small projected result, not the raw response.

## Search

List connected apps and matching tools. **Always start with a bare request** (no `query`, no `app`) — it returns the connected apps plus native tools and is the source of the valid `app` slugs. If `connected_apps` is empty, the team has not connected any third-party integrations. When the app the user needs is not in `connected_apps`, do **not** stop at "it's not connected" — follow **Recipe: connect an unconnected integration** below to hand the user a connect link.

```bash
kite-integrations search
```

Read the `name_slug` you need from `connected_apps`, then scope a second search to that exact slug (use the slug exactly as it appeared — e.g. `notion`):

```bash
kite-integrations search "page" notion
```

- `query` — optional keyword (1st arg); searches tool names and descriptions.
- `app` — optional connected-app slug (2nd arg). Use **only** a `name_slug` value returned in `connected_apps` by the bare search — never a brand name you assumed. Omitting both skips per-app action search.

Response:

```json
{
  "team_id": "…",
  "connected_apps": [
    {
      "name_slug": "notion",
      "name": "team-workspace",
      "account_id": "apn_…",
      "healthy": true
    }
  ],
  "tools": [
    {
      "name": "pipedream:notion-create-page",
      "provider": "pipedream",
      "app": "notion",
      "description": "Create a page",
      "connected": true,
      "invocation": "gateway",
      "endpoint": null
    },
    {
      "name": "native:slack-send-message",
      "provider": "native",
      "app": null,
      "description": "Post a message to a Slack channel as the Kite bot…",
      "connected": true,
      "invocation": "gateway",
      "endpoint": null
    }
  ]
}
```

## Describe

```bash
kite-integrations describe pipedream:notion-create-page
```

Pass `tool_name` exactly as it appeared in a search result's `tools[].name` (its `pipedream:` prefix already carries the connected slug, e.g. `notion` or a version-suffixed `<brand>_v2`) — do not retype or "correct" the slug. For `pipedream:*` tools, `input_schema.configurable_props` lists the params: `name` is the key to send, `optional: true`/`default` means skippable, everything else is required. Props with `remoteOptions: true` accept raw values (e.g. a channel name like `#general`) — there is no option-picker here. For `native:*` tools it's a standard JSON schema.

## Execute

```bash
kite-integrations execute pipedream:notion-create-page \
  '{"parent_page_id": "…", "title": "Weekly update"}'
```

- `tool_name` — exactly as it appeared in a search result (1st arg).
- `params` — a JSON object string (2nd arg, optional when the tool takes none).

## Raw-endpoint fallback (no `kite-integrations` on PATH)

The CLI wraps three POST endpoints under
`$BACKEND_API_URL/api/v1/internal/tool-gateway/tools/` — `search`, `describe`,
`execute` — authed with `Authorization: Bearer $INTERNAL_API_TOKEN`. Bodies
mirror the CLI args, plus the scope field the CLI fills in for you: exactly one
of `"team_id": "$TEAM_ID"` or `"application_id": "$APPLICATION_ID"` (whichever
is set — both is rejected):

```bash
curl -sS -X POST "$BACKEND_API_URL/api/v1/internal/tool-gateway/tools/execute" \
  -H "Authorization: Bearer $INTERNAL_API_TOKEN" \
  -H "Content-Type: application/json" \
  -d @- << EOF
{
  "team_id": "$TEAM_ID",
  "tool_name": "pipedream:notion-create-page",
  "params": { "parent_page_id": "…", "title": "Weekly update" }
}
EOF
```

`search` takes optional `"query"` and `"app"`; `describe` takes `"tool_name"`.
Use `<<EOF`, never `<<'EOF'` — a quoted terminator suppresses variable
expansion, so the platform receives the literal string `"$TEAM_ID"` and rejects
it with a 422 UUID-parse error.

Response: `{ "tool_name": "…", "status": "success", "result": {…}, "latency_ms": 1843 }`. For `pipedream:*` tools the provider's return value is nested in `result.ret`; `native:*` tools return their own result shape directly in `result`. Slack and GitHub do not go through this hand-written `execute` — use the `kite-slack` / `kite-github` CLIs below.

## Platform-native tools

`native:*` tools run on platform-managed credentials: they are always available, need no team connection, and never get a connect link. When a native tool and a third-party integration can both serve the need (e.g. keyword and competitor data via the DataForSEO catalog), use the native tool — ask the user to connect only for data or actions that live in the team's own account (their analytics, their CRM records, their docs). The bare search lists them all; `describe` → `execute` them like any other tool. Most belong to an owning skill or CLI — when you hold the owner, use its recipes instead of raw `execute`:

- `native:research-*` — web search, page extract and scrape, brand tokens, page imagery (Firecrawl-backed) — owned by `web-research` (`kite-research` CLI).
- `native:images-*` — image generation, editing, background removal — owned by `image-creation`.
- `native:dashboard-*` — publishing reports, dashboards, and viewer sign-in — owned by `dashboard-building` (`kite-dashboards` CLI).
- `native:slack-*`, `native:github-api-request`, `native:integrations-*` — the `kite-slack`, `kite-github`, and `kite-integrations` recipes in this skill.
- `native:email-send` — send email as the team's own address; recipes live in the email skills when you hold them, otherwise `describe` → `execute` it directly.
- `native:crustdata-fetch-linkedin-profile` / `-posts` — a person's or company's public LinkedIn profile / recent original posts, given a LinkedIn URL. No owning skill; call directly.
- `native:clay-*`, `native:dataforseo-*` — provider **catalogs**, below.

**Catalogs.** Two providers host their own evolving tool sets behind a list/call pair: **Clay** (person and company enrichment, contact finding, professional email data) and **DataForSEO** (live SERPs, keyword search volume/difficulty/ideas, domain rankings and competitor research, backlinks, on-page audits, AI-answer visibility). Never guess provider tool names: first execute `native:<provider>-list-tools` (optional `"query"` keyword filters the catalog), pick the tool and read its schema from the response, then execute `native:<provider>-call-tool` with the provider tool's name and arguments **nested** in `params`. When the list has no tool matching the need, or a call still fails after one retry, fall back per your skill's failure handling rather than forcing a mismatched tool.

```bash
kite-integrations execute native:dataforseo-call-tool \
  '{"tool_name": "<name from list-tools>", "params": { … }}'
```

Catalog calls are metered on the platform account — batch inputs into one call when the provider tool accepts a list, and project large responses with `jq` (see the "Reduce large results" gotcha). A `503 gateway_not_configured` on any `native:*` tool means this environment lacks the platform credential: fall back per your skill's failure handling instead of retrying — this overrides the generic 503 row in _Errors_, which is for team integrations.

## Recipe: send a Slack message (`kite-slack`)

Slack posting goes through the platform-native Kite bot, not Pipedream, so it works without any Pipedream connection — but it does require the team to have installed the Kite Slack bot from Team settings. The `kite-slack` CLI calls the tool gateway for you (scope, token, and URL are resolved from the env). Put generated message text in a quoted-heredoc file so newlines, dollar signs, and other shell characters arrive unchanged:

```bash
message_file=$(mktemp)
cat >"$message_file" <<'EOF'
*Weekly update*

Rankings improved for 12 keywords.
EOF
kite-slack send "#general" --text-file "$message_file"
rm -f "$message_file"
```

To reply inside an existing thread, pass the thread timestamp after the text file:

```bash
message_file=$(mktemp)
cat >"$message_file" <<'EOF'
Following up here 👇
EOF
kite-slack send "#general" --text-file "$message_file" "1718900000.123456"
rm -f "$message_file"
```

- `channel` — channel id (`C…`) or name (`#general`); both work for posting.
- `text` — the message. Use `--text-file <path>` for generated text; the positional form remains available for short static text.
- `thread_ts` *(optional)* — reply inside an existing thread instead of posting a new message.
- The message is attributed to **Kite** (the bot), not to a person. The result returns the posted message's `channel` and `ts`.
- `409 provider_not_connected` means the team hasn't installed the Kite Slack bot — tell the user to connect Slack in **Team settings**.
- `502 provider_error` with `Slack rejected the message: not_in_channel` (or `channel_not_found`) and `retryable: false` means the Kite bot isn't in that channel — tell the user to invite **@Kite** to it (`/invite @Kite` in Slack). Don't retry; it won't change until the bot is invited.

### Check channel access first (`kite-slack channel`)

When the user asks whether Kite can post somewhere, or before posting to a channel you're not confident the bot can reach, check it — never send a test message to find out:

```bash
kite-slack channel "#team-marketing"
```

Returns `{ channel_id, name, exists, is_member, is_private }`:

- `exists: true` — the channel is visible to the bot. `is_member: false` on a **public** channel is fine: the bot can post to any public channel without joining. On a private channel (`is_private: true`), `is_member` must be true to post.
- `exists: false` — no channel by that id/name is visible to the bot: either a typo, or a private channel the bot isn't in. If the user says the channel exists, ask them to run `/invite @Kite` in it, then check again.
- **Private channels can't be found by name** (the name lookup covers public channels only), so `exists: false` for a name the user insists on may be a private channel the bot is *already* in. Check it by channel id (`C…`/`G…`) if you have one; otherwise, once the user confirms the bot was invited, send directly — a `not_in_channel` error will still tell you if they were wrong.

### Change a channel's reply mode (`kite-slack reply-mode`)

Run this command whenever someone asks you to stop replying in a channel unless explicitly tagged (`tagged_only`), or to resume auto-replying in threads you're tagged into or started (`auto`). The ask is only fulfilled by running it — an acknowledgment without the command changes nothing:

```bash
kite-slack reply-mode "#team-marketing" tagged_only
```

- `mode` — `tagged_only` (act only on explicit @mentions) or `auto` (the default: follow threads you're tagged into or started and reply when relevant).
- Private channels resolve by id (`C…`/`G…`) only, same as the access check above.
- After it succeeds, confirm in one line what the channel now does (e.g. "Done — I'll only reply here when tagged."). Don't explain the modes or repeat the command.

## Recipe: call the GitHub API (`kite-github`)

Like Slack, GitHub is native — use the `kite-github` CLI (it isn't in `connected_apps`, and there is no `pipedream:github*` tool). The CLI is a generic passthrough to the GitHub REST API, authenticated as the team's connected **GitHub App installation**; it resolves scope, token, and URL from the env, so you pass only the `method`, the server-relative `path`, and optionally a `body`/`query` JSON object:

```bash
kite-github api POST /repos/acme/website/issues \
  '{"title": "Broken link on pricing page", "body": "Found via the CMO."}'
```

- `method` — `GET`/`POST`/`PATCH`/`PUT`/`DELETE` (case-insensitive, 1st arg). Writes are allowed; they are bounded by the permissions the team granted the GitHub App at install.
- `path` — a server-relative GitHub API path starting with `/` (2nd arg; e.g. `/installation/repositories`, `/repos/{owner}/{repo}/issues`, `/repos/{owner}/{repo}/pulls`). Never a full `https://` URL.
- `body` *(optional, 3rd arg)* — a JSON object string for writes, e.g. `'{"title": "…"}'`.
- `query` *(optional, 4th arg)* — a JSON object string of query params, e.g. `'{"per_page": "100", "page": "2"}'`. Paginate explicitly; large responses are capped. To pass a query without a body, send `''` for the body: `kite-github api GET /search/issues '' '{"q": "…"}'`.
- **The result carries GitHub's own outcome**: `result.status` is the GitHub HTTP status and `result.body` is the parsed response. A GitHub `404`/`422` comes back here as `status: 404` — it is *not* a gateway error, so inspect `status` and branch on it (don't retry a 404 blindly).
- `409 provider_not_connected` means the team hasn't connected GitHub — tell the user to connect the **GitHub** connector on the **/integrations** page. Don't mint a Pipedream connect link for GitHub.
- To discover what the installation can reach, `kite-github api GET /installation/repositories`.

**List/search endpoints return large objects — project them before they reach you (see the "Reduce large results" gotcha).** GitHub list objects (PRs, issues, commits) are several KB each; printing a full page blows the context window. `kite-github` prints the raw JSON envelope (it does **not** pretty-print), so filter on GitHub's side and pipe its output through `jq` to keep only the fields needed to answer the user's question — never dump the whole response.

### Recipe: PRs merged in the last N days

Use the Search API (it filters by merge date server-side and returns leaner objects than `/pulls`), then project with `jq`. Compute the cutoff with `date`, build the query string with it, and read the projected rows from `result.body.items`:

```bash
since=$(date -u -d '7 days ago' +%Y-%m-%d 2>/dev/null || date -u -v-7d +%Y-%m-%d)
kite-github api GET /search/issues \
  '' "$(python3 -c 'import json,sys; print(json.dumps({"q": f"repo:OWNER/REPO is:pr is:merged merged:>={sys.argv[1]}", "per_page": "50"}))' "$since")" \
  | jq '[.result.body.items[] | {number, title, merged_or_closed: .closed_at, user: .user.login, url: .html_url}]'
```

Only the projected array reaches your context. If `result.body.total_count` exceeds the page, page through with `"page": "2"`, … rather than raising `per_page` past 100. For a raw list endpoint like `/repos/{owner}/{repo}/pulls`, keep `per_page` small (≈15–30) so the page stays under the cap, and `jq`-project the same way.

## Recipe: read a Google Sheet/Doc through `google_drive`

A Sheets/Docs/Slides URL is also a Drive file, so a connected `google_drive` reads it even when `google_sheets`/`google_docs` are not connected. Execute `pipedream:google_drive-download-file` with:

- `fileId` — the `/d/<id>/` segment of the URL.
- `mimeType` — export format for Workspace files: `text/csv` for Sheets, `text/plain` for Docs.
- `getBufferResponse: true` — required; without it the file lands in the provider's own `/tmp` and only metadata returns.

`result.ret.content` comes back as `{"type": "Buffer", "data": [<bytes>…]}` — decode the byte array to text (e.g. pipe through `jq -r '.result.ret.content.data | implode'`). `pipedream:google_drive-find-spreadsheets` searches sheets by name when the user gives a title instead of a URL.

## Recipe: connect an unconnected integration

When the app the user needs is not connected, give them a connect link instead of stopping — and tell them you will resume their request automatically once they connect. The `kite-integrations` CLI drives this: it calls the tool gateway for you, so you pass only the app — no token, URL, or thread id.

When the user named the job but not the app ("email the list", "log this in our CRM") and no connected app covers it, first ask which tool the team uses for that job — name two or three common options — then connect the tool they actually use, not the one you assumed.

**Multi-step flows: collect every gap before asking.** When the request is a flow spanning several apps ("pull the numbers from PostHog, draft a doc in Notion, log it in HubSpot"), list every app the whole flow needs against `connected_apps` **before starting any step** — do not discover gaps one at a time and make the user authenticate over several turns. Resolve any named-job-but-not-app steps first (ask which tool, as above), then mint a connect link for **each** missing app (steps 1–2 below, once per app) and hand them all back in one message: one line per app saying what the flow needs it for, then a single `<connect-cta>` block whose body is a JSON **array** of `{"app", "url"}` objects. The platform renders one **Connect** button per app on Slack. When the flow resumes after a connect, re-check `connected_apps` and re-offer only the apps still missing.

**App absent from `connected_apps` (e.g. the user asks for PostHog data and no PostHog is connected):**

1. Confirm it's supported and get the exact slug:

```bash
kite-integrations catalog-search "posthog"
```

Prints `{ "apps": [ { "name_slug", "name", "description" }, ... ] }`. If `apps` is empty, the app is **not supported** — tell the user that and stop. Otherwise take the exact `name_slug`. If the command itself fails (non-zero exit or an `error` field — e.g. a network blip), surface that error to the user rather than declaring the app unsupported.

2. Mint the connect link:

```bash
kite-integrations connect posthog
```

Prints `{ "app", "provider", "connect_url" }`. Hand the link to the user by ending your final message with a single `<connect-cta>` block — the platform renders it as a **Connect** button on Slack and a link on the web. The body is one JSON object for a single app, or a JSON array (one entry per app, max 5) when a flow needs several connected. Write plain context first — one line per app saying what it's for — do not paste the raw URLs into your prose, then end the turn:

```
PostHog isn't connected yet. Connect it below and I'll pick your request back up automatically once you're done.

<connect-cta>
{"app": "PostHog", "url": "<connect_url>"}
</connect-cta>
```

For a flow needing several apps:

```
To run this every week I need two connections: PostHog (to pull your traffic numbers) and Notion (to create the report doc). Connect them below and I'll pick your request back up.

<connect-cta>
[{"app": "PostHog", "url": "<connect_url>"}, {"app": "Notion", "url": "<connect_url>"}]
</connect-cta>
```

- `app` — the app's display name (the button reads "Connect <app>"); use the `name` from `catalog-search`, e.g. `PostHog`.
- Run `catalog-search` and `connect` **before** composing your reply, and write that reply **once**. Announcing the link first ("connect it below…"), then minting, then re-writing the message with the block sends the user two near-identical messages — one without the button, one with it. The turn's shape is: mint silently (or with one short status line), then one complete reply ending in the block.
- `url` — the `connect_url` from the CLI, copied verbatim; one `kite-integrations connect` call per app.
- Emit **at most one** `<connect-cta>` block, with a valid JSON body, and make it the **last thing** in the message. The block is only for handing back connect links — never for a working link.
- After emitting it, **end your turn**. The CLI already wired your conversation to the connect, so a new turn fires on its own once the user connects; you do not poll or wait. If the user instead replies again without connecting (so no resume has fired), re-offer the same link with a fresh `<connect-cta>` block — don't assume they connected, and don't mint a second link if the first is still valid.

**MCP server awaiting OAuth.** A configured MCP server appears in `connected_apps`, but `describe`/`execute` returns `409` with `detail.code: "provider_not_connected"` and a `detail.message` saying the server needs OAuth authorization. That specific 409 (an MCP slug that is already in `connected_apps`) is the trigger — distinct from a 409 for an app that simply isn't connected. Run `kite-integrations connect <slug>` with that server's slug to mint its authorization link, and hand it back the same way — one line of context plus a closing `<connect-cta>` block.

**Slack and GitHub are native — never mint a connect link for them.** `catalog-search` may surface `slack`/`github` from Pipedream's registry, but Kite serves them through its own connectors and CLIs (`kite-slack`, `kite-github` — see the recipes above). To *act*, call the CLI directly. Only when the team hasn't connected yet (a `409 provider_not_connected`) do you point the user at the connector: for Slack, install the Kite Slack bot in **Team settings**; for GitHub, the GitHub connector on the **/integrations** page. Do not pass `slack`/`github` to `kite-integrations connect`.

## Errors

Every non-2xx response carries `detail: { code, message, retryable }`:

| HTTP | code                     | What to do                                                                                                                                                                                                                                                                                 |
| ---- | ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 401  | —                        | `INTERNAL_API_TOKEN` missing or wrong. Check the env, stop.                                                                                                                                                                                                                                |
| 404  | `application_not_found`  | Bad `$APPLICATION_ID`. Stop.                                                                                                                                                                                                                                                               |
| 404  | `team_not_found`         | Bad `$TEAM_ID`. Stop.                                                                                                                                                                                                                                                                       |
| 422  | `missing_identifier` (or a schema validation error) | The scope env is broken (neither or both of `$TEAM_ID` / `$APPLICATION_ID` reached the gateway). `kite-integrations` sends exactly one from the env; check the env and stop rather than retrying.                                                                                                    |
| 404  | `tool_not_found`         | Unknown tool name — re-run `search`, don't invent names.                                                                                                                                                                                                                                   |
| 409  | `provider_not_connected` | That exact slug isn't connected. **First run a bare `search` and check `connected_apps[].name_slug`** — the app is often connected under a different or version-suffixed slug (e.g. a `<brand>_v2` rather than `<brand>`); if so, retry with that exact slug. If it's genuinely absent, serve the request through a connected app with the same capability (e.g., `google_drive` reads Sheets/Docs files even when `google_sheets` is not connected); otherwise follow **Recipe: connect an unconnected integration** to hand the user a connect link (for an MCP server, this 409 is the trigger to mint its OAuth link). Don't retry the slug you guessed — retry only with a `name_slug` from `connected_apps`. |
| 422  | `invalid_params`         | Params don't match the schema. Re-run `describe` and fix; don't retry blindly.                                                                                                                                                                                                             |
| 429  | `rate_limited`           | Back off and retry once after a pause.                                                                                                                                                                                                                                                     |
| 502  | `provider_error`         | Upstream failure. Retry once **only when `detail.retryable` is true**; a `retryable: false` 502 (e.g. Slack `not_in_channel`/`channel_not_found`) won't change on retry — act on the message instead (e.g. ask the user to invite **@Kite** to the channel).                                  |
| 503  | `gateway_not_configured` | On a `native:*` tool: the platform credential is absent in this environment — fall back per your skill's failure handling (see _Platform-native tools_). On team-integration work: tell the user "Integrations are not available in this workspace. Contact your administrator." and stop.                                                                                                       |
