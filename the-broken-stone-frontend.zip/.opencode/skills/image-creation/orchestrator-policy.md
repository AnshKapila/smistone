---
description: Orchestrator-only policy for the `image-creation` skill — phase gating, the 3-variation rule, design-spec coherence, modifying-existing image flow, and the post-creation render-and-confirm hand-off to `trigger_coding_agent`. Loaded by `load_skills` only when SKILL.md's `agent_policies.orchestrator` points here.
---

# Image Creation — orchestrator policy

These are the conversation-shaping rules that belong to the orchestrator's job — when to generate, how many to generate, and what to do with the result. The platform-side curl recipes live in `SKILL.md`; this file is what makes a curl into the right curl for the moment.

## Phase gating

- `generate`, `edit`, `remove-background` are for the **refinement** phase only. In the requirements phase, just note images to create — they will be generated alongside the website (logos included).
- `design-spec` may be called in either phase to inform planning.

## How many to generate

- **Single-purpose image** (hero, logo): generate **3 variations** in one `generate` call so the user can choose. Pass three distinct prompts (different style, angle, mood, or composition) in the `requests` array. The platform produces one image per request in parallel.
- **Set of items** (products, services, team members, venues): **1 image per item.**

## Style coherence

Before composing prompts (logos excepted), fetch the website's imagery style via the `design-spec` curl if it isn't already in context. Fold the relevant style information into each prompt for visual consistency. Skip this for logos — logo prompts have their own override section in `references/prompt-authoring.md`.

## Modifying existing images

- Find the image via `search_uploaded_files` and pass its URL into the `edit` curl's `reference_images`.
- For resize/crop **of the frame** (change dimensions, aspect ratio), apply Cloudinary URL transformations directly — don't regenerate.
- **Zoom adjustments ("zoom in a bit", "make it bigger/smaller", "zoom out")** are CSS changes, not Cloudinary transforms. Route to `trigger_coding_agent` with a `website_changes` that says to use CSS `transform: scale()` — e.g., "Zoom in the [product] image slightly using CSS scale (about 5–10%). Do not apply Cloudinary e_trim or re-crop the image URL."
- For "remove the background", "make it transparent", or "isolate the logo", use the `remove-background` curl (preserves the original pixels exactly). Use `edit` only when the image content itself must change; it regenerates pixels and won't preserve uploaded artwork.
- **Subject repositioning requires `edit`, not crop/CSS.** When the user asks to move, shift, or reposition a person or object within a photo (e.g., "move the woman to the left", "put the people on the right side"), that changes the image content — CSS `object-position`, `background-position`, and Cloudinary crop transformations only shift which part of the existing pixels is visible; they cannot move a subject to a different location in the scene. Use the `edit` curl with a prompt that describes the desired composition. If the user says the subject hasn't moved after a crop/position attempt, stop retrying CSS and switch to `edit`.
- When editing to reposition subjects, reference the original image and prompt for the same scene with the new composition. Emphasize preserving the room, mood, lighting, and overall feel of the original.

## After creating or modifying

Always render the new images back to the user so they can view them. Ask where they should be applied. Then call `trigger_coding_agent` to add them to the website — never embed image URLs into website code yourself.
