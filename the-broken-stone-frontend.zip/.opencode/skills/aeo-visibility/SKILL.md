---
name: aeo-visibility
description: "Kite's conversational contract for AI-answer-engine visibility (AEO). Use when an AEO measurement digest lands in the conversation (a delegated measurement task or scheduled sweep finished), when the user asks about their brand's presence in AI answers, wants to re-run a measurement, accepts or rejects a Brand Gap recommendation, confirms brand positioning, asks to track a topic, keyword, or competitor, or asks to stop AEO updates. Covers presenting digests with their report links, the one-time positioning confirmation, routing accepted recommendations, the re-run guard, appending to the tracked lists, and opt-out/opt-in."
mode: both
---

# AEO visibility (Kite's side of the loop)

Background agents measure how the team's brand shows up in AI answer engines (ChatGPT, Perplexity, Gemini) and write their findings to the knowledge folder under `aeo/`. When a measurement task linked to this conversation finishes, its wake message carries a digest with the target site's `application_id`. You have done this right when the user knows where their brand stands, every link and action you reported came from a verified command output, and anything they asked to track or change is confirmed recorded.

Throughout, a failed `kite-aeo` or `kite-tasks` command (non-zero exit, or output missing the expected confirmation such as a task `id` or written file path) gets exactly one retry; if it fails again, report the error plainly and offer to try again later. Never report an action as done without its confirming output.

## Present digests as outcomes

Lead with the standings and what changed ("you now appear in 4 of 12 tracked answers for X, up from 1"), name the top recommendations, and share the report links from the digest verbatim as markdown links: the hosted report page (shareable) and the in-app `report_url` (the app's Growth tab → AI Visibility in this product, with the full report, charts, every search that was run, and the recommendation tracker). If a digest carries no link, say exactly where the report lives — open the app in this product, Growth tab, AI Visibility — and never invent another location. The report is never on the team's own website; never point users there for it.

Read `/efs/knowledge/aeo/<application_id>/current.md` and `.../gap-report.md` when you need more than the digest carries. When the digest and those files disagree, the digest is newer — trust it and say the fuller report is refreshing.

## Confirm positioning once

The first time you present AEO findings for a site, state your understanding of how the team wants the brand positioned and ask whether it is right. Source that understanding from the knowledge folder and this conversation; when they differ, what the user said in conversation wins. Write the confirmed or corrected version to a markdown file and run `kite-aeo positioning "<application_id>" <file>`; a success prints the written file path. It is not re-asked on later runs. If the user revises their positioning later, rewrite it the same way, then dispatch a re-synthesis task: `kite-tasks create "Re-synthesize Brand Gap report" "Positioning was revised for application <application_id>. Follow the aeo-strategy skill to recompute the gap report and recommendations." "analyst"`.

## Route accepted recommendations

A recommendation is accepted when the user explicitly says to proceed with it (names it, or answers yes to your offer to start it) — treat anything less as discussion, not acceptance. For an accepted on-site recommendation, delegate it as a task to the right function agent (builds and technical changes to Web Developer, copy to Content, visuals to Design) and include the recommendation's rationale in the description; the recommendation states the action, the user-confirmed positioning governs how it is executed. For off-site recommendations (pitching publications, creating channel content), give the user concrete guidance instead of delegating.

## Guard re-runs

A new measurement is dispatched as: `kite-tasks create "AEO measurement — <domain>" "Run the AEO measurement workflow for application_id <application_id> (domain: <domain>). Follow the aeo-measurement skill." "analyst"`. Before dispatching, run `kite-tasks list`; when an AEO measurement or Brand Gap task is already `todo`, `in_progress`, or `waiting` (match by title), report its status instead of creating a duplicate. The measurement chain runs itself (the measurement task spawns the strategy subtask); create only the measurement task, never its stages.

## Track topics, keywords, and competitors

The workspace keeps tracked lists the measurement pipeline reads: AEO topics (subjects to measure in AI answers), SEO keywords, and competitors. Append to them with `kite-aeo track "<application_id>" <topic|keyword|competitor> "<value>" "<one-line why>"`:

- When the user names a subject to measure ("track how we show up for website audits"), a keyword, or a competitor — track it in the same turn and confirm what was added from the command's response.
- When the conversation surfaces a durable candidate the user agrees matters (a competitor they mention repeatedly, a topic they care about ranking for), offer to track it; track on their yes.
- Topics are unbranded phrases a buyer types ("website audit tool", "how to improve SEO"), never the team's own brand name. Keywords and competitors require the site to have a tracked domain on the Growth tab; if the command reports that it is missing, tell the user to set it there first.

## Honor opt-out

When the user asks to stop AEO updates, run `kite-aeo opt-out "<application_id>"` and confirm it happened; `kite-aeo opt-in "<application_id>"` reverses it.
