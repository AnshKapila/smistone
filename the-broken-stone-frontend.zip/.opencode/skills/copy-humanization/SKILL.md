---
name: copy-humanization
description: "Use this skill whenever you generate, edit, or review user-facing copy — headlines, section text, blog posts, product descriptions, emails, social posts. Detects and rewrites the telltale patterns of AI-generated writing: em dash overuse, staccato period-chopped rhythm, stock AI vocabulary (testament/landscape/showcasing), rule-of-three phrasing, vague attributions, promotional puffery, negative parallelisms, copula avoidance, and filler phrases."
mode: both
---

> Vendored from [blader/copy-humanization](https://github.com/blader/copy-humanization) (upstream
> version 2.5.1, MIT License, Copyright (c) 2025 Siqi Chen). See `LICENSE` in
> this directory for the full license text.
>
> **Modifications from upstream:** the persona lede, `# Humanizer:` H1,
> `## Your Task`, `## Voice Calibration`, `## PERSONALITY AND SOUL`, and
> `## Process` sections have been removed because we use this as a rule
> bundle interpolated into another system prompt, not as a standalone agent
> prompt. Rule #26 ("Hyphenated Word Pair Overuse") has also been removed
> because its "After" examples produce grammatically non-standard English
> ("cross functional team", "high quality report") when applied to marketing
> copy. As a consequence, the pattern numbering jumps `25 → 27`; the surviving
> numbers match upstream v2.5.1 minus deletions. **Kite-local additions**
> not present in upstream — do not drop these during syncs or renumber them
> to match upstream additions: the `## Write-time rules` section, rule #30
> ("Comparison-Based Positioning"), rule #31 ("Staccato Period-Chains",
> adapted from upstream v2.8.2 §31 with added comma guidance), and the
> strengthened em-dash budget in rule #14. See
> `docs/decisions/2026-05-12-vendor-copy-humanization-skill-for-website-copy.md` for
> full rationale. Future upstream syncs should diff this file against the
> upstream raw URL with the above sections in mind.

Apply the following patterns to every piece of user-facing copy. Success
means the copy reads as if a person wrote it, with the original meaning and
claims intact: no single pattern below survives in clusters, and nothing
true was dropped or blurred in the rewrite.

## Write-time rules

The pattern catalog below is the detect-and-rewrite reference. These six
rules are the same material compressed to write by, so a first draft comes
out human instead of needing rescue. They govern mechanics only: the voice
itself (warm, dry, blunt, playful) comes from the team's voice pages in the
wiki, and both apply at once. When a voice page deliberately calls for
something a rule discourages (a punchy fragment in a headline, say), the
voice page wins for that element.

1. **Rhythm.** Write with commas, not just periods: join related clauses
   into one flowing sentence instead of chopping every idea into its own
   short sentence. One short sentence lands a point; a run of three or more
   is manufactured drama. Vary sentence length so the piece has no cadence
   a reader could tap out. Em dashes are a budget: default to zero, at most
   one per piece, and only where a comma, colon, period, or parentheses
   genuinely cannot do the job.

2. **Diction.** Choose the plain word: use, not leverage; is, not serves
   as; help, not empower. Cut intensity adverbs (really, truly,
   incredibly), hedges (arguably, fairly, worth noting), and the stock AI
   vocabulary in the catalog's word lists. If a sentence sounds impressive
   and you cannot say concretely what it means, delete it.

3. **Formulas.** Build no sentence from a stock template: "not just X,
   it's Y", "less like X, more like Y", "from X to Y" false ranges, lists
   of three for symmetry's sake, dramatic fragments ("The result?
   Burnout."), or coined aphorisms ("Symmetry is the language of trust").
   State the claim directly and let it stand.

4. **Evidence.** Every claim carries a specific you actually have: a
   number, a name, a date, a source. Never attribute to vague authorities
   ("experts say", "research suggests"), and never announce that something
   matters ("this is crucial because"); the specific carries the weight or
   the sentence goes.

5. **Structure.** Shape follows the argument, not a template: open with
   the point rather than a warm-up about today's fast-moving landscape,
   never narrate the writing ("let's dive in", "it's important to note"),
   end sections without recaps, end pieces without restating the intro,
   keep prose as prose instead of reflexive bullets, and use no decorative
   bold or emoji.

6. **Temperature.** Match emotion to stakes: a dashboard filter update is
   useful, not thrilling. No fake candor ("I'll be honest"), no fake
   collaboration ("let's explore"), no silver lining bolted onto every
   setback. Some things are minor and some went badly; say so.

The tell is the cluster, not the instance. A lone em dash or one clipped
sentence is a writer's choice; em dashes plus a rule of three plus "vibrant
landscape" plus a recap conclusion is a confession. Before delivering,
reread the draft asking "what makes this obviously AI-generated?", scan it
against the catalog below for anything the six rules missed, and fix
whatever answers.

## CONTENT PATTERNS

### 1. Undue Emphasis on Significance, Legacy, and Broader Trends

**Words to watch:** stands/serves as, is a testament/reminder, a vital/significant/crucial/pivotal/key role/moment, underscores/highlights its importance/significance, reflects broader, symbolizing its ongoing/enduring/lasting, contributing to the, setting the stage for, marking/shaping the, represents/marks a shift, key turning point, evolving landscape, focal point, indelible mark, deeply rooted

**Problem:** LLM writing puffs up importance by adding statements about how arbitrary aspects represent or contribute to a broader topic.

**Before:**
> The Statistical Institute of Catalonia was officially established in 1989, marking a pivotal moment in the evolution of regional statistics in Spain. This initiative was part of a broader movement across Spain to decentralize administrative functions and enhance regional governance.

**After:**
> The Statistical Institute of Catalonia was established in 1989 to collect and publish regional statistics independently from Spain's national statistics office.


### 2. Undue Emphasis on Notability and Media Coverage

**Words to watch:** independent coverage, local/regional/national media outlets, written by a leading expert, active social media presence

**Problem:** LLMs hit readers over the head with claims of notability, often listing sources without context.

**Before:**
> Her views have been cited in The New York Times, BBC, Financial Times, and The Hindu. She maintains an active social media presence with over 500,000 followers.

**After:**
> In a 2024 New York Times interview, she argued that AI regulation should focus on outcomes rather than methods.


### 3. Superficial Analyses with -ing Endings

**Words to watch:** highlighting/underscoring/emphasizing..., ensuring..., reflecting/symbolizing..., contributing to..., cultivating/fostering..., encompassing..., showcasing...

**Problem:** AI chatbots tack present participle ("-ing") phrases onto sentences to add fake depth.

**Before:**
> The temple's color palette of blue, green, and gold resonates with the region's natural beauty, symbolizing Texas bluebonnets, the Gulf of Mexico, and the diverse Texan landscapes, reflecting the community's deep connection to the land.

**After:**
> The temple uses blue, green, and gold colors. The architect said these were chosen to reference local bluebonnets and the Gulf coast.


### 4. Promotional and Advertisement-like Language

**Words to watch:** boasts a, vibrant, rich (figurative), profound, enhancing its, showcasing, exemplifies, commitment to, natural beauty, nestled, in the heart of, groundbreaking (figurative), renowned, breathtaking, must-visit, stunning

**Problem:** LLMs have serious problems keeping a neutral tone, especially for "cultural heritage" topics.

**Before:**
> Nestled within the breathtaking region of Gonder in Ethiopia, Alamata Raya Kobo stands as a vibrant town with a rich cultural heritage and stunning natural beauty.

**After:**
> Alamata Raya Kobo is a town in the Gonder region of Ethiopia, known for its weekly market and 18th-century church.


### 5. Vague Attributions and Weasel Words

**Words to watch:** Industry reports, Observers have cited, Experts argue, Some critics argue, several sources/publications (when few cited)

**Problem:** AI chatbots attribute opinions to vague authorities without specific sources.

**Before:**
> Due to its unique characteristics, the Haolai River is of interest to researchers and conservationists. Experts believe it plays a crucial role in the regional ecosystem.

**After:**
> The Haolai River supports several endemic fish species, according to a 2019 survey by the Chinese Academy of Sciences.


### 6. Outline-like "Challenges and Future Prospects" Sections

**Words to watch:** Despite its... faces several challenges..., Despite these challenges, Challenges and Legacy, Future Outlook

**Problem:** Many LLM-generated articles include formulaic "Challenges" sections.

**Before:**
> Despite its industrial prosperity, Korattur faces challenges typical of urban areas, including traffic congestion and water scarcity. Despite these challenges, with its strategic location and ongoing initiatives, Korattur continues to thrive as an integral part of Chennai's growth.

**After:**
> Traffic congestion increased after 2015 when three new IT parks opened. The municipal corporation began a stormwater drainage project in 2022 to address recurring floods.


## LANGUAGE AND GRAMMAR PATTERNS

### 7. Overused "AI Vocabulary" Words

**High-frequency AI words:** Actually, additionally, align with, crucial, delve, emphasizing, enduring, enhance, fostering, garner, highlight (verb), interplay, intricate/intricacies, key (adjective), landscape (abstract noun), pivotal, showcase, tapestry (abstract noun), testament, underscore (verb), valuable, vibrant

**Problem:** These words appear far more frequently in post-2023 text. They often co-occur.

**Before:**
> Additionally, a distinctive feature of Somali cuisine is the incorporation of camel meat. An enduring testament to Italian colonial influence is the widespread adoption of pasta in the local culinary landscape, showcasing how these dishes have integrated into the traditional diet.

**After:**
> Somali cuisine also includes camel meat, which is considered a delicacy. Pasta dishes, introduced during Italian colonization, remain common, especially in the south.


### 8. Avoidance of "is"/"are" (Copula Avoidance)

**Words to watch:** serves as/stands as/marks/represents [a], boasts/features/offers [a]

**Problem:** LLMs substitute elaborate constructions for simple copulas.

**Before:**
> Gallery 825 serves as LAAA's exhibition space for contemporary art. The gallery features four separate spaces and boasts over 3,000 square feet.

**After:**
> Gallery 825 is LAAA's exhibition space for contemporary art. The gallery has four rooms totaling 3,000 square feet.


### 9. Negative Parallelisms and Tailing Negations

**Problem:** Constructions like "Not only...but..." or "It's not just about..., it's..." are overused. So are clipped tailing-negation fragments such as "no guessing" or "no wasted motion" tacked onto the end of a sentence instead of written as a real clause.

**Before:**
> It's not just about the beat riding under the vocals; it's part of the aggression and atmosphere. It's not merely a song, it's a statement.

**After:**
> The heavy beat adds to the aggressive tone.

**Before (tailing negation):**
> The options come from the selected item, no guessing.

**After:**
> The options come from the selected item without forcing the user to guess.


### 10. Rule of Three Overuse

**Problem:** LLMs force ideas into groups of three to appear comprehensive.

**Before:**
> The event features keynote sessions, panel discussions, and networking opportunities. Attendees can expect innovation, inspiration, and industry insights.

**After:**
> The event includes talks and panels. There's also time for informal networking between sessions.


### 11. Elegant Variation (Synonym Cycling)

**Problem:** AI has repetition-penalty code causing excessive synonym substitution.

**Before:**
> The protagonist faces many challenges. The main character must overcome obstacles. The central figure eventually triumphs. The hero returns home.

**After:**
> The protagonist faces many challenges but eventually triumphs and returns home.


### 12. False Ranges

**Problem:** LLMs use "from X to Y" constructions where X and Y aren't on a meaningful scale.

**Before:**
> Our journey through the universe has taken us from the singularity of the Big Bang to the grand cosmic web, from the birth and death of stars to the enigmatic dance of dark matter.

**After:**
> The book covers the Big Bang, star formation, and current theories about dark matter.


### 13. Passive Voice and Subjectless Fragments

**Problem:** LLMs often hide the actor or drop the subject entirely with lines like "No configuration file needed" or "The results are preserved automatically." Rewrite these when active voice makes the sentence clearer and more direct.

**Before:**
> No configuration file needed. The results are preserved automatically.

**After:**
> You do not need a configuration file. The system preserves the results automatically.


## STYLE PATTERNS

### 14. Em Dash Overuse

**Problem:** LLMs use em dashes (—) far more than humans, mimicking "punchy" sales writing. Treat them as a budget: default to zero, at most one per piece, and only where a comma, colon, period, or parentheses genuinely cannot do the job. Replace each one, in rough order of preference, with a comma (a tight aside), a period (a new sentence), a colon (introducing an explanation), or parentheses (a true aside). Also catch spaced em dashes (` — `), en dashes (–), and double hyphens (` -- `) used the same way.

**Before:**
> The term is primarily promoted by Dutch institutions—not by the people themselves. You don't say "Netherlands, Europe" as an address—yet this mislabeling continues—even in official documents.

**After:**
> The term is primarily promoted by Dutch institutions, not by the people themselves. You don't say "Netherlands, Europe" as an address, yet this mislabeling continues in official documents.


### 15. Overuse of Boldface

**Problem:** AI chatbots emphasize phrases in boldface mechanically.

**Before:**
> It blends **OKRs (Objectives and Key Results)**, **KPIs (Key Performance Indicators)**, and visual strategy tools such as the **Business Model Canvas (BMC)** and **Balanced Scorecard (BSC)**.

**After:**
> It blends OKRs, KPIs, and visual strategy tools like the Business Model Canvas and Balanced Scorecard.


### 16. Inline-Header Vertical Lists

**Problem:** AI outputs lists where items start with bolded headers followed by colons.

**Before:**
> - **User Experience:** The user experience has been significantly improved with a new interface.
> - **Performance:** Performance has been enhanced through optimized algorithms.
> - **Security:** Security has been strengthened with end-to-end encryption.

**After:**
> The update improves the interface, speeds up load times through optimized algorithms, and adds end-to-end encryption.


### 17. Title Case in Headings

**Problem:** AI chatbots capitalize all main words in headings.

**Before:**
> ## Strategic Negotiations And Global Partnerships

**After:**
> ## Strategic negotiations and global partnerships


### 18. Emojis

**Problem:** AI chatbots often decorate headings or bullet points with emojis.

**Before:**
> 🚀 **Launch Phase:** The product launches in Q3
> 💡 **Key Insight:** Users prefer simplicity
> ✅ **Next Steps:** Schedule follow-up meeting

**After:**
> The product launches in Q3. User research showed a preference for simplicity. Next step: schedule a follow-up meeting.


### 19. Curly Quotation Marks

**Problem:** ChatGPT uses curly quotes (“...”) instead of straight quotes ("...").

**Before:**
> He said “the project is on track” but others disagreed.

**After:**
> He said "the project is on track" but others disagreed.


## COMMUNICATION PATTERNS

### 20. Collaborative Communication Artifacts

**Words to watch:** I hope this helps, Of course!, Certainly!, You're absolutely right!, Would you like..., let me know, here is a...

**Problem:** Text meant as chatbot correspondence gets pasted as content.

**Before:**
> Here is an overview of the French Revolution. I hope this helps! Let me know if you'd like me to expand on any section.

**After:**
> The French Revolution began in 1789 when financial crisis and food shortages led to widespread unrest.


### 21. Knowledge-Cutoff Disclaimers

**Words to watch:** as of [date], Up to my last training update, While specific details are limited/scarce..., based on available information...

**Problem:** AI disclaimers about incomplete information get left in text.

**Before:**
> While specific details about the company's founding are not extensively documented in readily available sources, it appears to have been established sometime in the 1990s.

**After:**
> The company was founded in 1994, according to its registration documents.


### 22. Sycophantic/Servile Tone

**Problem:** Overly positive, people-pleasing language.

**Before:**
> Great question! You're absolutely right that this is a complex topic. That's an excellent point about the economic factors.

**After:**
> The economic factors you mentioned are relevant here.


## FILLER AND HEDGING

### 23. Filler Phrases

**Before → After:**
- "In order to achieve this goal" → "To achieve this"
- "Due to the fact that it was raining" → "Because it was raining"
- "At this point in time" → "Now"
- "In the event that you need help" → "If you need help"
- "The system has the ability to process" → "The system can process"
- "It is important to note that the data shows" → "The data shows"


### 24. Excessive Hedging

**Problem:** Over-qualifying statements.

**Before:**
> It could potentially possibly be argued that the policy might have some effect on outcomes.

**After:**
> The policy may affect outcomes.


### 25. Generic Positive Conclusions

**Problem:** Vague upbeat endings.

**Before:**
> The future looks bright for the company. Exciting times lie ahead as they continue their journey toward excellence. This represents a major step in the right direction.

**After:**
> The company plans to open two more locations next year.


### 27. Persuasive Authority Tropes

**Phrases to watch:** The real question is, at its core, in reality, what really matters, fundamentally, the deeper issue, the heart of the matter

**Problem:** LLMs use these phrases to pretend they are cutting through noise to some deeper truth, when the sentence that follows usually just restates an ordinary point with extra ceremony.

**Before:**
> The real question is whether teams can adapt. At its core, what really matters is organizational readiness.

**After:**
> The question is whether teams can adapt. That mostly depends on whether the organization is ready to change its habits.


### 28. Signposting and Announcements

**Phrases to watch:** Let's dive in, let's explore, let's break this down, here's what you need to know, now let's look at, without further ado

**Problem:** LLMs announce what they are about to do instead of doing it. This meta-commentary slows the writing down and gives it a tutorial-script feel.

**Before:**
> Let's dive into how caching works in Next.js. Here's what you need to know.

**After:**
> Next.js caches data at multiple layers, including request memoization, the data cache, and the router cache.


### 29. Fragmented Headers

**Signs to watch:** A heading followed by a one-line paragraph that simply restates the heading before the real content begins.

**Problem:** LLMs often add a generic sentence after a heading as a rhetorical warm-up. It usually adds nothing and makes the prose feel padded.

**Before:**
> ## Performance
>
> Speed matters.
>
> When users hit a slow page, they leave.

**After:**
> ## Performance
>
> When users hit a slow page, they leave.


### 30. Comparison-Based Positioning

**Phrases to watch:** unlike other [role/category], compared to traditional, while most [professionals], sets [me/us] apart from, what makes [me/us] different from

**Problem:** LLMs position a subject by contrasting them against a generic negative caricature of competitors. The comparison adds no information (the reader doesn't know the competitors) and sounds defensive. Worse, it often persists through rewrite iterations because the model treats it as the structural frame for differentiation.

**Before:**
> Unlike other virtual assistants who rely on surface-level lookup, I bring genuine medical comprehension to every task. While most remote workers treat healthcare admin as data entry, my anatomy background means I understand the clinical rationale behind every code.

**After:**
> I read clinical records and know what they mean — the diagnoses, the procedures, the reason a prior auth will or won't clear. When I apply an ICD-10 code, it comes from understanding the anatomy, not from pattern-matching a keyword table.


### 31. Staccato Period-Chains and Comma-Starved Rhythm

**Problem:** LLMs chop related clauses into short period-terminated sentences to manufacture punch, and under-use the commas a human would use to let a sentence breathe. One short sentence lands a point; a run of them is a cadence, not a choice, and it reads like a movie trailer. When consecutive short sentences share a subject or a cause-effect link, join them with commas or conjunctions and let the sentence run.

**Before:**
> Traffic dropped 40% overnight. Rankings disappeared. The client called. We had to act fast.

**After:**
> Traffic dropped 40% overnight and the rankings went with it, so by the time the client called we were already rebuilding the sitemap.

**Before:**
> The new dashboard is live. It loads faster. It has better filters. Your team will love it.

**After:**
> The new dashboard is live, and it loads in under a second even with the new filters on. Your team gets the same reports with half the clicks.
