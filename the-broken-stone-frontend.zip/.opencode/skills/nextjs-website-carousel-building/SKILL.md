---
name: nextjs-website-carousel-building
description: >
  Use this skill when building or editing any sliding or horizontally-moving
  section in a Next.js website iteration — testimonial sliders, image or
  product carousels, logo strips, marquees/tickers, hero rotators, and
  swipeable card rows. Triggers on requests like "make the testimonials
  slide", "add a logo marquee", or "turn this grid into a carousel", and any
  time a visual spec calls for a slider, carousel, or auto-scrolling strip.
  For static-HTML prototype iterations (single-file SPA), use the carousel
  skill instead — this one only governs Next.js App Router iterations.
mode: both
---

# Carousels & Sliders — Next.js

The codebase ships **no carousel package**. `embla-carousel-react`,
`swiper`, `react-slick`, `keen-slider`, and `framer-motion` are not installed
and must not be added — importing any of them fails typecheck and blocks the
iteration. Build every moving section from React + Tailwind already in the
codebase, using one of the three patterns below.

Slide content is one array you map over — never hardcoded repeated slide JSX.
Source that array the way the current codebase sources content: when the
section is a Payload block receiving props (the codebase has
`payload.config.ts` and generated `@/payload-types`), map the block's prop
array (`props.items` etc.) per the cms-management contract; otherwise define
a local typed constant grounded in the requirements.

## Pattern selector

| Request | Pattern |
| --- | --- |
| Cards / products / gallery: swipeable on mobile, static row or grid on desktop | 1 — scroll-snap row (server component, no JS) |
| Testimonial or image slider with prev/next arrows or dots; hero rotator | 2 — stepped slider (client component) |
| Logo strip, ticker, continuous marquee | 3 — CSS marquee (server component) |

Prefer pattern 1 whenever the design does not require arrows, dots, or
auto-advance — it hydrates nothing and cannot break.

## 1. Scroll-snap row (no JS)

```tsx
<div className="flex snap-x snap-mandatory gap-6 overflow-x-auto px-6 scroll-px-6 md:grid md:grid-cols-3 md:overflow-visible md:px-0">
  {items.map((item, i) => (
    <div key={i} className="w-[85%] shrink-0 snap-start md:w-auto">
      {/* card */}
    </div>
  ))}
</div>
```

Mobile gets native swipe with snap stops; desktop collapses to a grid with no
controls to wire.

## 2. Stepped slider (client component)

`'use client'` is required (state + click handlers). One state value, modulo
wrap, slides translated as a strip inside an `overflow-hidden` viewport:

```tsx
'use client';
import { useState } from 'react';

type Testimonial = { quote: string; name: string; role: string };

export function TestimonialSlider({ items }: { items: Testimonial[] }) {
  const [index, setIndex] = useState(0);
  const step = (delta: number) =>
    setIndex((index + delta + items.length) % items.length);

  return (
    <div>
      <div className="overflow-hidden">
        <div
          className="flex transition-transform duration-500 ease-out"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {items.map((item, i) => (
            <div key={i} className="w-full shrink-0 px-3" aria-hidden={i !== index}>
              {/* slide */}
            </div>
          ))}
        </div>
      </div>
      <div className="mt-6 flex items-center justify-between">
        <div className="flex gap-2">
          {items.map((_, i) => (
            <button
              key={i}
              aria-label={`Go to slide ${i + 1}`}
              onClick={() => setIndex(i)}
              className={`h-2 w-2 rounded-full transition-colors ${i === index ? 'bg-current' : 'bg-current/30'}`}
            />
          ))}
        </div>
        <div className="flex gap-2">
          <button onClick={() => step(-1)} aria-label="Previous slide" className="rounded-full border p-2">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="m15 18-6-6 6-6" /></svg>
          </button>
          <button onClick={() => step(1)} aria-label="Next slide" className="rounded-full border p-2">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2"><path d="m9 18 6-6-6-6" /></svg>
          </button>
        </div>
      </div>
    </div>
  );
}
```

- Multi-card layouts: change the slide width to `w-full md:w-1/2 lg:w-1/3` and
  translate by `index * (100 / visibleSlides)`%.
- When the codebase has generated Payload types (`@/payload-types`), type the
  props with the block's generated type (`import type { TestimonialListBlock }
  from '@/payload-types'`) and read `props.items ?? []` instead of the local
  type above.
- **Hero rotator**: same component shape, but stack slides with
  `absolute inset-0` in a `relative` container and toggle opacity per index
  (`opacity-100` active / `opacity-0 pointer-events-none` idle with
  `transition-opacity`) — fade avoids transform math entirely. Add a
  `useEffect` interval only when the design calls for auto-advance, and clear
  it on unmount.

## 3. CSS marquee (logo strip / ticker)

Duplicate the track **exactly once** and animate to `-50%` — the wrap is
seamless because the second half is identical to the first:

```tsx
export function LogoMarquee({ logos }: { logos: string[] }) {
  const track = [...logos, ...logos];
  return (
    <div className="overflow-hidden">
      <style>{`@keyframes marquee { to { transform: translateX(-50%); } }`}</style>
      <div className="flex w-max items-center gap-16 [animation:marquee_30s_linear_infinite] motion-reduce:[animation:none]">
        {track.map((logo, i) => (
          <span key={i} aria-hidden={i >= logos.length} className="shrink-0">
            {logo}
          </span>
        ))}
      </div>
    </div>
  );
}
```

- `overflow-hidden` lives on the track's **direct parent**; the animated child
  keeps `w-max` so it sizes to its content.
- Mark the duplicated half `aria-hidden` so screen readers hear each entry once.
- Keep the CSS animation (`animation:` / `@keyframes`) on the moving element
  itself — the QA scanner recognizes animated elements as intentional motion;
  a marquee moved by JS-set transforms gets flagged as clipped content.
- Marquees are decorative. Put logos, short taglines, or repeated brand words
  in them — never navigation, headings, or copy the user must read.

## Never do

- Import a carousel, slider, animation, or icon package the codebase does not
  ship — it is not installed and fails typecheck. Check `package.json`; when
  in doubt, inline SVG + the patterns above.
- Run a marquee or slider with `setInterval` + manually mutated transforms —
  use a CSS animation (pattern 3) or state-driven transitions (pattern 2).
- Set a fixed pixel height on a container that animates between slides — let
  it size naturally, or use equal-height slide content.
- Omit `'use client'` on a slider component that uses state or handlers — it
  is a build error.
- Apply `overflow-hidden` to an ancestor that contains a `position: sticky`
  element — use `overflow-clip` there instead.
