---
name: website-content-management
description: "Use this skill whenever you edit website text, copy, metadata, or values that live in content/data files (`src/data/*.ts`, JSON content) — it covers data-layer vs template separation, finding every copy of a value, and matching image URLs that pass through transformation helpers."
mode: sandbox
---

# Content data vs. template code

When the HTML template renders data from a JSON content file (e.g. `data.testimonials.map(…)`), always edit the JSON file to add, change, or remove entries — it is the data layer, and the template loop is the rendering layer. Never add data inline via `.concat()`, `.push()`, or spread, as that bypasses the data layer.

When an image URL in the rendered page comes from a JSON content file passed through an image-transformation helper (e.g. `optimizeImg(item.image, width)`, `resizeImg(item.src, opts)`), the actual source URL is in the JSON file without the image-service transforms (e.g. `w_100,c_limit`). Use the raw URL stored in the JSON file as the match target. The runtime-transformed URL visible in the DOM (e.g. with `w_100,c_limit` transforms) is derived and should not be used for matching.

# Where a value lives

The same value often sits in more than one place: a `src/data/*.ts` entry **and** hardcoded in the consuming page or component, plus `alt`/`title` attributes and `metadata` exports. Changing one copy leaves the others stale — treat every copy as one target.

# Content file conventions

Next.js stores site content in `src/data/*.ts` modules (e.g. `content.ts`, or per-page `home.ts`, `services.ts`). HTML apps use flat JSON files under `src/content/` (e.g. `projects.json`, `services.json`). Use descriptive names, not generic ones like `data`, `main`, or `items`.
