---
name: prompt-writing
description: Use this skill when writing instructions for skills and prompts.
mode: sandbox
---

# Prompt Writing

Use this skill to write or edit prompts for skills. A skill prompt must route correctly, load only when relevant, and give the model clear procedures it can execute and verify.

## Core Rules

1. Be clear and unambiguous. Each instruction must have one valid interpretation.
2. Use short declarative sentences.
3. Pick one term for each concept and use it consistently.
4. Remove filler such as "please make sure to."
5. Prefer positive instructions. Tell the model what to do.
6. When a negative constraint is required, pair it with the positive alternative.
7. State exceptions explicitly.
8. State each rule once.
9. Keep instructions in the narrowest durable owner.
10. Ensure there are no conflicting instructions.

## Skill Scope

A skill owns reusable task procedure for one task family.

A skill may include:

- Routing frontmatter.
- When to use the skill.
- When not to use the skill.
- Inputs the model needs.
- Preconditions.
- Exact workflow.
- Tool or command usage.
- Safety rules.
- Verification steps.
- Failure handling.
- Output format.

A skill must not include:

- Agent persona.
- Workspace-wide operating policy.
- User-specific preferences.
- Secrets or credentials.
- One-off task instructions.
- Long unrelated tutorials.
- Rules already owned by another skill.

If a skill depends on external local facts, reference where to find them instead of copying them into the skill.

## Editing Discipline

Before adding text, cut or merge existing text.

A revision must not grow the skill unless it adds a genuinely new instruction. If it grows, compress another section to offset it.

Do not restate a rule for emphasis.

Do not split one idea into several numbered points.

Use examples only when the instruction is likely to be misapplied without one.

Prefer one canonical example over several near-duplicates.

## Frontmatter Routing

Treat `SKILL.md` frontmatter as the skill's routing contract. The model sees `name` and `description` before it decides whether to load the body. The body cannot fix vague or misleading frontmatter.

When writing or editing frontmatter:

1. Put exactly one YAML frontmatter block at the top of `SKILL.md`.
2. Set `name` to the exact hyphen-case skill slug.
3. Use lowercase letters, digits, and hyphens in `name`.
4. Keep the folder name, configured skill name, and frontmatter `name` aligned unless the resolver intentionally maps them differently.
5. Write `description` as routing metadata.
6. Describe when to use the skill, not what the skill contains.
7. Lead with concrete trigger language.
8. Include key inputs, artifacts, tools, or file types that should trigger the skill.
9. Name the boundary with nearby skills when overlap exists.
10. Keep `description` to one or two dense sentences.
11. Remove embedded or copied frontmatter blocks from the body.

Good description shape:

```yaml
description: "<Primary capability>. Use when <concrete task triggers>, especially when <key inputs/artifacts/tools>. For <nearby-but-different work>, use `<other-skill>`."
```

Use the final sentence only when a real neighboring skill creates ambiguity.

## Body Structure

Use this structure unless the skill needs a different shape:

```markdown
# <Skill Title>

<One short sentence describing the skill's job.>

## Use When

- <Concrete trigger>
- <Concrete trigger>

## Inputs

- <Required input>
- <Optional input>

## Workflow

1. <Action>
2. <Action>
3. <Action>

## Verification

- <Concrete check>
- <Concrete check>

## Failure Handling

- <What to do when a required input, tool, file, or check is missing>
```

Keep sections only when they add value.

## Workflows

Write workflows as executable steps.

Each step must specify the action, target, and expected result.

Use gates when order matters:

```text
Do not call `<next tool>` until `<previous check>` succeeds.
```

Use exact commands when possible:

```bash
python3 -m pytest tests/path
```

Prefer concrete commands over vague instructions such as "test it" or "verify everything."

For tool calls, include the exact tool name and call shape when the skill requires a specific mid-task action.

Example:

```text
Call `tool_name({ "id": "<id>", "action": "send" })`.
```

Do not rely on narration when a tool call is required.

## Anti-Duplication

One rule must have one owner.

When a rule already exists in another skill, replace the copy with a short reference.

Allowed exception: duplicate the few lines needed to execute a required tool call when the model must act immediately and cannot safely rely on a reference.

Keep shared skills generic. Put environment-specific values, account names, local paths, and user preferences in narrower files or inputs.

## Examples

Examples must be concrete and minimal.

Use examples to disambiguate behavior, not to pad the skill.

Prefer this:

```text
Use for standalone HTML landing page prototypes from a written spec. For framework apps, use `frontend`.
```

Avoid this:

```text
This skill helps with web work, pages, designs, apps, websites, marketing, and prototypes.
```

## Verification

Before finishing a skill edit, check:

1. The frontmatter has exactly one YAML block.
2. The `name` is hyphen-case and matches the intended skill slug.
3. The `description` says when to use the skill.
4. The body starts after the frontmatter.
5. The skill has one task family.
6. Rules are stated once.
7. No instruction conflicts with another instruction.
8. Workflow steps are actionable.
9. Required tool calls or commands are exact.
10. Verification steps check the work instead of restating rules.
11. No secrets, credentials, or user-specific preferences are included.
12. Nearby-skill boundaries are named when overlap exists.

Runnable check:

```bash
python3 - <<'PY'
from pathlib import Path
p = Path("SKILL.md")
s = p.read_text()
assert s.startswith("---\n"), "SKILL.md must start with YAML frontmatter"
assert s.count("\n---") >= 1, "Missing closing frontmatter delimiter"
frontmatter_end = s.find("\n---", 4)
body = s[frontmatter_end + 4:].strip()
assert "name:" in s[:frontmatter_end], "Missing name"
assert "description:" in s[:frontmatter_end], "Missing description"
assert "---\nname:" not in body and "\nname:" not in body, "Embedded frontmatter-like block found in body"
print("SKILL.md frontmatter check passed")
PY
```

If the project has a dedicated skill audit command, run that instead.

## Failure Handling

If the skill's task family is unclear, narrow it before editing.

If two skills overlap, update the frontmatter descriptions so each has a clear routing boundary.

If a rule belongs outside the skill, remove it from the skill and reference the owning file or input.
