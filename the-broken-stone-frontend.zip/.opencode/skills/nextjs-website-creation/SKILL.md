---
name: nextjs-website-creation
description: >
  Use this skill when you need to author the full Next.js project for a new
  design iteration from scratch — planning the app-specific files, generating
  every image the pages will embed, and emitting the source files. Triggers at
  the prototype/build phase of a fresh iteration. Not for incremental edits to
  an already-generated site, and not for the static HTML build path — that is
  the `html-generation` skill. After generation completes, return control to
  the caller — the caller's system prompt owns the validation step.
mode: sandbox
---

# nextjs-website-creation

Two scripts, two phases, strictly sequential.

1. **Plan** — `plan_files.py`: copies the baked `nextjs-template/` into `$EFS_APP_PATH/iterations/<iter>/`, fetches the visual spec, then runs a direct LLM call to produce (a) the list of app-specific files to author and (b) the image manifest with full prompts and predetermined CDN URLs. Writes `$EFS_APP_PATH/iterations/<iter>/plan.json` AND `$EFS_APP_PATH/iterations/<iter>/images.json`.
2. **Generate files** — `generate_files.py`: reads `$EFS_APP_PATH/iterations/<iter>/plan.json`, kicks off image generation off `$EFS_APP_PATH/iterations/<iter>/images.json`in a background thread, runs Gemini once to emit the full contents of every planned file, then writes those files under `$EFS_APP_PATH/iterations/<iter>/`, installs deps, waits for background thread for images to finish.

## Plan

```bash
python3 .opencode/skills/nextjs-website-creation/scripts/plan_files.py
```

Invoke via the `bash` tool with `timeout: 900000` (15 min) because the Gemini calls in `plan_files.py` take time. The path is relative to the agent's run dir, where the skill tree is staged — not the app root.


### Plan output

Stdout: one line of JSON.

```json
{
  "status": "success" | "error",
  "plan_path": "/efs/.../iterations/iter1/plan.json",
  "images_path": "/efs/.../iterations/iter1/images.json",
  "file_count": 7,
  "image_count": 4,
  "duration_s": 12.3,
  "iteration_id": "iter1",
  "warnings": []
}
```

example:`$EFS_APP_PATH/iterations/<iter>/plan.json`

```json
{
  "files": [
    {
      "path": "src/app/page.tsx",
      "purpose": "home route: hero, features, CTA, footer",
      "images": ["iter1-hero", "iter1-brand-logo"]
    },
    {
      "path": "src/components/Hero.tsx",
      "purpose": "hero section with title, subtitle, primary CTA",
      "images": ["iter1-hero"]
    }
  ],
  "images": [
    {
      "slug": "iter1-hero",
      "prompt": "<full prompt-authoring-rules-compliant string>",
      "aspect_ratio": "16:9",
      "is_logo": false,
      "url": "https://static.kite.ai/image/upload/app/<application_id>/iter1/iter1-hero.png"
    }
  ]
}
```
`images[*].prompt` is the full image generation prompt (per `images/references/prompt-authoring.md`) will be used to generate the final images and uploaded to the CDN url `images[*].url`. `images[*].slug`is used in `files[*].images` to indicate in which file the image is going to be used.

example: `$EFS_APP_PATH/iterations/<iter>/images.json`
```json
{
  "images": [
    {
      "slug": "iter1-hero",
      "prompt": "<full prompt-authoring-rules-compliant string>",
      "aspect_ratio": "16:9",
      "is_logo": false,
    }
  ]
}
```

## Generate

```bash
python3 .opencode/skills/nextjs-website-creation/scripts/generate_files.py
```

Invoke via the `bash` tool with `timeout: 1800000` (30 min). Same env and inputs as the planning step, plus the on-disk `<iter>/plan.json` and `<iter>/images.json`. Requires `BACKEND_API_URL`, `INTERNAL_API_TOKEN`, and `APPLICATION_ID` in the sandbox env so the script can POST to the platform's `images/generate` route on the agent's behalf.

### Generate output

Stdout: one line of JSON.

```json
{
  "status": "success" | "failed" | "error",
  "files_written": ["src/app/page.tsx", "src/components/Hero.tsx", ...],
  "duration_s": 38.5,
  "iteration_id": "iter1",
  "warnings": [],
  "images": { "total": 4, "succeeded": 4, "failed": 0 }
}
```

On `status: "failed"` exactly one extra key is present: `cms_errors` (elements
`{path, kind, hint}`) or `kite_errors` (elements `{path, line, kind, hint}`) —
the Blocking gates section below maps which gate emits which. Example:

```json
{
  "status": "failed",
  "iteration_id": "iter1",
  "kite_errors": [
    { "path": "src/app/page.tsx", "line": 42, "kind": "dynamic_stamp", "hint": "data-kite-cta-id={id} must be a quoted literal" }
  ]
}
```

### Blocking gates (emission + content fit)

`generate_files.py` runs blocking gates that return `status: "failed"` with an
error array. Repair per each error's `path`+`hint`, then re-run
`generate_files.py <iter> --skip-llm` — do NOT proceed to QA until the run
succeeds, and do NOT re-run without `--skip-llm` (that regenerates the whole site
from scratch; reserve it for a run whose output was unusable, e.g. the LLM call
itself errored). Two distinct keys carry the errors — a failed run has exactly
one: `cms_errors` (gates 1–2: the emission-gap gate runs for BOTH template
kinds, the content-fit gate is Payload-only; elements are `{path, kind, hint}`)
or `kite_errors` (gate 3, classic-template analytics stamps; elements are
`{path, line, kind, hint}`). `kite_errors` is a separate key, not a rename of
`cms_errors` — a Payload run never emits `kite_errors`, and a classic run emits
`cms_errors` only from the emission-gap gate.

1. **Emission-gap gate** (right after files are written, checked against disk):
   every planned file exists (`missing-file`), every block `seed.json` uses has
   a restyled component (`missing-component` — a missing one ships the
   template's unstyled placeholder for that section), and
   `src/payload/collections/generated.ts` re-declares no field that
   `makeCollection` already injects from `collectionMeta.ts` (`duplicate-field`
   — a re-declared field crashes Payload at config load). On a gate failure the
   script first makes ONE scoped repair LLM call that emits only the
   missing/broken files and re-checks; you only see `status: "failed"` when
   that in-run repair did not resolve it.
2. **Content-fit gate** (before seeding): the `cms-management` validator's three
   fit invariants plus the triple checks (`block-triple`, `component-props`).
   The same gate re-runs in the `nextjs-website-change-verification` skill's `validate_files.py` as blocking
   `cms-fit` issues.
3. **Analytics-stamp gate** (classic template only, after install — Payload
   runs skip this gate entirely): the
   `data-kite-*` AST extractor (`scripts/extract-kite-manifest.mjs`, run with
   `node`) parses the emitted `.tsx` and writes `kite-manifest.json`. It blocks
   (returns
   `kite_errors` of `{ path, line, kind, hint }`) only on a real stamp defect —
   `dynamic_stamp` (a `data-kite-*` value written as a `{expression}` instead of
   a quoted literal), `empty_conversion` (`data-kite-conversion=""`),
   `duplicate_identity` (one `data-kite-cta-id`/`-nav`/`-form-type` mapped to two
   different `data-kite-event` names), or `unpaired_conversion_hook`
   (`data-kite-conversion-hook` stamped but no source file calls
   `window.__kite.conversion(...)`, so the conversion could never fire). Fix the
   cited lines and re-run `--skip-llm`. Non-blocking stamp warnings
   (`no_stamps`, `no_conversion`, `multiple_conversions`, `spread_stamp`,
   `unscanned_file_stamp`, `intent_conversion`, `conversion_inside_form`
   (stamp the `<form>` itself, not an inner control), `hero_without_cta`,
   `event_name_not_past_tense`, `out_write_failed`) surface in the output's
   `warnings`. A tooling failure (extractor script or its `typescript` package
   missing, timeout — the extractor runs with plain `node`, no tsx) is
   non-blocking — generation proceeds with no catalog rather than failing.

### `--skip-llm` (re-run after manual repairs)

```bash
python3 .opencode/skills/nextjs-website-creation/scripts/generate_files.py "$ITERATION_ID" --skip-llm
```

Skips the full-generation LLM call and runs the rest of the pipeline (gates →
install → types → validate → seed → images) against the files already on disk.
The gates still apply (the scoped repair call included), and image dispatch
probes the CDN first so already-live images are never regenerated — only real
gaps are re-requested.

### Two template kinds

`<iter>/` is seeded from one of two templates before planning, decided once at app creation. The scripts auto-detect the kind from `<iter>/src/payload.config.ts` — you never pass a mode flag — but the workflow differs:

**Payload-embedded template** (`src/payload.config.ts` present, seeded from `nextjs-template-payload/`): files already present in the template (e.g. `package.json`, `tsconfig.json`, `next.config.mjs`, `src/payload.config.ts`, `src/payload/**`, `src/app/(payload)/**`, `src/app/(frontend)/layout.tsx`, `src/app/(frontend)/[[...slug]]/page.tsx`, `src/components/blocks/RenderBlocks.tsx`, `src/app/sitemap.ts`, `src/app/robots.ts`, `src/app/globals.css`, `public/`) are NOT re-planned and NOT re-emitted — the LLM emits only block/chrome components under `src/components/` and the `seed.json` content manifest. Content lives in Payload: `sitemap.ts`/`robots.ts` are baked and read the Pages collection via the Local API, so the LLM never emits them. After generation an idempotent seed step (`scripts/seed-payload.ts`) loads `seed.json` into the per-iter Payload schema (`payload_<iter>`) so the dev server and QA scan real DB-backed content. The content-fit gate and the seed step run only for this kind.

**Classic template** (no `src/payload.config.ts`, seeded from `nextjs-template/`): the LLM authors routes (`src/app/<route>/page.tsx`), shared components, and content data modules (`src/data/*.ts`) on top of the template invariants (`package.json`, `tsconfig.json`, `next.config.js`, `src/app/layout.tsx`, `src/app/globals.css`, `public/`). There is no `seed.json`, no CMS validation, and no seed step. `src/app/sitemap.ts` is the one invariant exception: the template ships it with the homepage entry only — when the plan adds more routes under `src/app/`, include `src/app/sitemap.ts` in the emission set and append one `staticRoutes` entry per route (`url: ${baseUrl}/<slug>`, `changeFrequency: 'monthly'`, `priority: 0.8`). The `getBaseUrl()` import and homepage entry stay; only the static-routes array grows.

After a `success` run every entry from the plan is written under `<iter>/`. Image generation runs concurrently with the Gemini call: at startup the script reads `<iter>/images.json` and fires the platform's `images/generate` route in a background thread (batched into 10-image chunks, up to 4 batches in parallel), then joins that background work after `pnpm install --ignore-workspace --prefer-offline` so the final `images` summary reflects real upload results. The `images` block is omitted when there are no images or the platform env vars are missing — in which case the agent must dispatch image generation itself via the `image-creation` skill before validate.
