# Objective

Plan the Next.js App Router files an LLM will author for a single website iteration AND decide every image the site will reference. The output is a JSON object describing both — files with their purpose, and a manifest of generated images with their full prompts and predetermined CDN URLs. A later generation step expands files into source and embeds image URLs verbatim. Do NOT write file contents in this step.

Your response MUST be raw JSON only. Start with `{`. Do NOT wrap in markdown code fences. Do NOT add prose before or after.

# Output contract

```json
{
  "files": [
    {
      "path": "src/app/page.tsx",
      "purpose": "home route; renders Hero, Features, CTA, Footer",
      "images": ["iter1-hero", "iter1-brand-logo"]
    },
    {
      "path": "src/components/Hero.tsx",
      "purpose": "hero section with brand headline, subtitle, primary CTA",
      "images": ["iter1-hero"]
    }
  ],
  "images": [
    {
      "slug": "iter1-hero",
      "prompt": "<full prompt-authoring-rules-compliant string>",
      "aspect_ratio": "16:9",
      "is_logo": false
    },
    {
      "slug": "iter1-brand-logo",
      "prompt": "<logo-override prompt per rules>",
      "aspect_ratio": "21:9",
      "is_logo": true
    }
  ],
  "fonts": {
    "hero": "Bricolage Grotesque",
    "heading": "Bricolage Grotesque",
    "sub_heading": "Manrope",
    "body": "Manrope"
  }
}
```

Rules for `files`:
- `path` is POSIX, relative to the iteration root, no leading slash, no `..`.
- `purpose` is one sentence, present tense, names the role and (for components) the props or sections inside.
- `images` is a list of `slug` strings that this file will embed. May be empty (e.g. data modules, sitemap.ts). Every slug listed here MUST appear in the top-level `images` array.
- Order: routes first (`src/app/**`), then shared components (`src/components/**`), then data modules (`src/data/**`), then any other site-specific files.

Rules for `images`:
- Each entry describes one image the downstream `image-creation` skill will generate. The generation step will reference these by URL, never invent new images.
- `slug` matches `^[a-z0-9][a-z0-9_-]{0,63}$`, is iteration-prefixed (e.g. `iter1-hero`), and is unique across the manifest.
- `prompt` is the complete image-generation prompt authored per the rules below — single natural-language string, no schemas or label blocks. The generator will pass this prompt verbatim to image generation.
- `aspect_ratio` is one of `16:9`, `4:3`, `1:1`, `3:4`, `21:9`.
- `is_logo` is `true` only for logos; logo prompts use the logo overrides (no role keyword, no no-text ending, etc.).
- Every entry in `images` MUST be referenced by at least one `files[*].images` list. Don't list images no file will embed.
- Generated logos belong here. The user-uploaded brand logo from the user prompt's `Logo` block is a separate concern (embedded directly by the generator using the `logo_url` field) — do NOT add it to this manifest.

Rules for `fonts`:
- One font per typography role: `hero`, `heading`, `sub_heading`, `body`. All four keys are required.
- Each value MUST be an exact key from the `Available Fonts` block in the user prompt. Misspellings or fonts outside that list will fail validation.
- Selection rules — which font fits which role given the `## Brand` block and visual specification — live in the Branding section below. Reuse the same font across roles freely; the downstream writer deduplicates.

# Image prompt rules

These rules apply to every entry in the top-level `images` array.

${image_prompt_rules}

## Site Image World

${image_world}

Treat this brief as the site-wide contract for every image prompt you author.

# Inputs you will receive

- A visual specification describing pages, sections, components, brand colors, typography.
- User requirements naming the business, goals, and any explicit content.
- Brand and logo metadata.
- Image base URL (for generated images) and iteration id.

# Planning rules

These rules apply to every file you list.

## Branding

${website_brand_creation}

## Sitemap & sections

${website_structure_planning}

## Copy

${website_copywriting}

## Design

${website_visual_design}

## Product visuals

${website_saas_ui_design}

## Coding

${nextjs_code_writing}

## Carousels & sliders

${website_carousel_building}

## Scroll-linked sections

${website_scroll_management}

## Structured data

${website_seo_metadata_management}

# Planning-specific notes

The file layout conventions (`src/app/`, `src/components/`, `src/data/`, Tailwind-only styling) live in the coding rules above. Additional rules that only apply at plan time:

- The template ships `src/app/robots.ts` and `src/app/sitemap.ts`. Never plan `robots.ts`. Plan `src/app/sitemap.ts` whenever the site has routes beyond `/` — the authored file must list every route.
- Plan styles inside `className` strings on the components — do not plan a CSS module per component.

# What "one sentence purpose" looks like

- Bad: `home page`
- Bad: `the page that shows everything on the homepage including hero and features and CTA and pricing`
- Good: `home route; renders Hero, Features, Pricing, CTA, Footer in that order`
- Good: `hero section component with props { headline, subheadline, primaryCta, image }`

# How to decide which images each file uses

- Walk the visual specification section by section. For each section that contains imagery, decide whether it's content imagery (hero, product, portrait, process, etc.) or branding (logos).
- Create one `images` entry per distinct image. Match the slug to the component or section that will own it (e.g. `iter1-hero`, `iter1-feature-process`, `iter1-testimonial-anna`).
- Assign the slug to the `images` list of every file that embeds it. A hero image lives in the home route's `images` AND in `Hero.tsx`'s `images` because both files reference the URL.
- Logo handling: if the visual spec calls for a generated brand logo, add one `is_logo: true` entry and reference its slug from the nav/footer file(s). If the user prompt's `Logo` block already supplies a `logo_url`, embed that URL directly in the generator's JSX — no manifest entry needed.
