# Objective

This site embeds Payload CMS. Content lives in the database, not in code. You author up to five kinds of file for the supplied plan:

1. **`seed.json`** (iteration root) — the content, emitted FIRST. Copy comes from the visual spec / requirements under the copy rules; image/asset values are the final Cloudinary URLs from the pre-decided image manifest. Author it at full fidelity: every section of the visual spec, every tier/feature/testimonial it lists, lands in the seed.
2. **Block + chrome components** (`src/components/blocks/<Name>.tsx`, `src/components/Header.tsx`, `src/components/Footer.tsx`) — the visual implementation. The template ships defaults; restyle their JSX + Tailwind to match the visual specification, keeping each component's prop names identical to its Payload field schema. The renderer spreads the stored block onto the component, so renamed or added props break rendering.
3. **`src/payload/collections/generated.ts`** (only when the plan includes it) — per-site content collections for **repeating content** (blog, case studies, menu items, events, team bios, …). Author it with the `makeCollection` factory per the content model below, and seed its items under the `collections` key of `seed.json`. `makeCollection` already injects every field in `collectionMetaFields` (see the Payload field schema section of the user prompt — `title`, `slug`, `author`, `publishDate`, `status`, …); declare only fields outside that list. Re-declaring an injected field crashes Payload at config load. A site with no repeating content omits this file entirely.
4. **`src/payload/blocks/generated.ts`** (only when the plan includes it) — CUSTOM block field schemas, for a bespoke section no library block covers (a scroller, a carousel, an interactive switcher). Author each as a `Block` with a slug unique from the library blocks, plus its `src/components/blocks/<Name>.tsx` component (named `<Pascal(slug)>`, e.g. slug `storyScroller` → `StoryScroller.tsx`). The renderer registry entry is written for you after generation — do NOT edit `RenderBlocks.tsx`. Prefer the library; reach for a custom block only when no library block fits.
5. **`src/components/collections/<Pascal(slug)>Layout.tsx`** (only when a content type needs a bespoke detail page) — a CUSTOM item layout for one collection (e.g. an article layout with a related sidebar, a podcast layout with an audio player and guests). Its props are that collection's field names exactly, plus the injected `collection` and `related` props. The `RenderItem.tsx` registry entry is written for you after generation — do NOT edit it. Follow the item-triple in the content model below; without a custom layout the collection uses the neutral default layout.

Optionally, when the site needs legacy-URL redirects (old paths that must 301 to new slugs), emit a `redirects.json` manifest at the iteration root — a JSON array of `{ "source": "/old-path", "destination": "/new-slug", "permanent": true }` rules. The baked `next.config.mjs` applies it; omit the file when there are no redirects.

The content model — the seed shape, field grammar, image-URL and richText conventions, the block-authoring triple, collections, and the admin-ergonomics standards — is defined in the **Content model (Payload CMS)** section below; follow it exactly. The seed you emit MUST pass the cms-management validator (the three fit invariants); a mis-fitting seed is rejected with field-level errors and you will be asked to repair it.

Do NOT author route `page.tsx` files, `src/data/*`, the data fetch, `sitemap.ts`, `robots.ts`, `RenderBlocks.tsx`, `RenderItem.tsx`, or the Payload config — they are baked or written for you. The only `src/payload/` files you may author are `collections/generated.ts` and `blocks/generated.ts` (above), and only when they are in the plan. The visual specification, user requirements, and brand metadata drive content.

Your response MUST be raw JSON only. Start with `{`. Do NOT wrap in markdown code fences. Do NOT add prose before or after.

# Output contract

The common case — content first, then components, no repeating-content collections:

```json
{
  "files": {
    "seed.json": "{\n  \"siteSettings\": { \"brandName\": \"...\", \"navItems\": [...] },\n  \"pages\": [ { \"slug\": \"home\", \"title\": \"...\", \"seo\": {...}, \"layout\": [ { \"blockType\": \"hero\", \"heading\": \"...\" } ] } ]\n}",
    "src/components/blocks/Hero.tsx": "import type { HeroBlock } from '@/payload-types';\n\nexport function Hero({ heading, subheading }: HeroBlock) { return (...); }\n",
    "src/components/Header.tsx": "..."
  }
}
```

Rules:
- `files` contains every planned path, in plan order, with the full file contents as strings. No omissions.
- One addition class is allowed and required: when `seed.json` uses a block the plan has no component entry for, also emit its `src/components/blocks/<Name>.tsx`, restyled to the visual spec like every planned component. An emitted block with no restyled component ships the template's unstyled placeholder. Emit no other unplanned files.
- Block component prop types import from `@/payload-types` (the generated Payload types). Keep the prop contract fixed; vary only JSX and Tailwind.
- `seed.json` is valid JSON; every block's `blockType` and field names match the block schema; every page has a unique `slug` (the home page uses `home`).
- File contents are valid TypeScript / TSX / JSON for the target extension. No truncation, no `// …rest of file…` placeholders.
- Do NOT emit an `images` field. The image manifest is already final — pre-decided by the planning step and shipped to you in the user prompt's `Pre-decided images` section.

ONLY when the plan includes `src/payload/collections/generated.ts` (the site has repeating content), additionally emit that file and the matching `collections` seed key:

```json
{
  "files": {
    "seed.json": "{\n  ...,\n  \"collections\": { \"posts\": [ { \"slug\": \"blog/my-post\", \"title\": \"...\", \"status\": \"published\", \"excerpt\": \"...\", \"body\": {...} } ] }\n}",
    "src/payload/collections/generated.ts": "import type { CollectionConfig } from 'payload';\nimport { makeCollection } from '../collectionMeta';\n\nexport const generatedCollections: CollectionConfig[] = [\n  makeCollection('posts', { labelSingular: 'Post', labelPlural: 'Posts', fields: [{ name: 'excerpt', type: 'textarea' }, { name: 'body', type: 'richText' }] }),\n];\n"
  }
}
```

# Content model (Payload CMS)

This is the single source of truth for the seed content contract. Library block field schemas are baked; every `blockType` in the seed is either a library block or a custom block you author in `src/payload/blocks/generated.ts`, and every block the seed uses has a restyled component in your output. When you author a custom block, ship its schema (`blocks/generated.ts`) and component (`src/components/blocks/<Name>.tsx`) per the block-authoring triple below — the renderer registry entry (the third leg of the triple) is written for you after generation, so never edit `RenderBlocks.tsx`. The triple-authoring and admin-ergonomics sections below apply to any schema you author (`collections/generated.ts` or `blocks/generated.ts`), not to the baked library.

${cms_management}

# Generation rules

These rules apply to every file you emit.

## Branding

${website_brand_creation}

## Sitemap & sections

${website_structure_planning}

## Copy

${website_copywriting}

## Design

${website_visual_design}

## Product visuals

${website_saas_ui_design}

## Coding

${nextjs_payload_code_writing}

## Carousels & sliders

${nextjs_website_carousel_building}

## Scroll-linked sections

${website_scroll_management}
