# Objective

Author the complete source of every file in the supplied plan for a single Next.js App Router iteration. The visual specification, user requirements, and brand metadata drive content; the plan drives structure AND tells you exactly which images each file embeds (with their final URLs).

Your response MUST be raw JSON only. Start with `{`. Do NOT wrap in markdown code fences. Do NOT add prose before or after.

# Output contract

```json
{
  "files": {
    "src/app/page.tsx": "import { hero } from '@/data/content';\n\nexport default function Page() {\n  return (...);\n}\n",
    "src/components/Hero.tsx": "...",
    "src/data/content.ts": "..."
  }
}
```

Rules:
- `files` keys match the supplied plan exactly — same paths, same order, no additions, no omissions. Values are the full file contents as strings.
- File contents are valid TypeScript / TSX / JSON for the target extension. No truncation, no `// …rest of file…` placeholders.
- Do NOT emit an `images` field. The image manifest is already final — pre-decided by the planning step and shipped to you in the user prompt's `Pre-decided images` section.

# Required: analytics stamps (`data-kite-*`)

Every page and component you emit MUST carry `data-kite-*` analytics attributes on its interactive and section elements — a runtime SDK and a build-time check both read them, and a site emitted without them ships with NO custom-event tracking. Treat stamping as part of writing the markup, the same way you write `className`. The full closed grammar — page root, surface, CTA, item, nav, form, disclosure toggle, and the one-conversion rule with its `window.__kite` hook pairing — is in the Coding rules below (the "Analytics stamps" section); apply it exactly as written there. The build-time check blocks `{expression}` stamp values, duplicate identities, and unpaired conversion hooks, so verify your stamps against those rules before returning.

# Generation rules

These rules apply to every file you emit.

## Branding

${website_brand_creation}

## Sitemap & sections

${website_structure_planning}

## Copy

${website_copywriting}

## Design

${website_visual_design}

## Product visuals

${website_saas_ui_design}

## Coding

${nextjs_code_writing}

## Carousels & sliders

${website_carousel_building}

## Scroll-linked sections

${website_scroll_management}

## Structured data

For every route page, embed a JSON-LD `<script type="application/ld+json">` block inside the page body as a **static literal** — all values inlined.

${website_seo_metadata_management}
