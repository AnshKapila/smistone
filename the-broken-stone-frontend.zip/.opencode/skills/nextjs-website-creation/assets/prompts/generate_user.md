# Iteration

- Iteration ID: ${iteration_id}
- Image base URL: ${image_base_url}

# Logo

```json
${logo_block}
```

# User requirements

${user_requirements}

## Build requirements

${build_req_block}

## User-uploaded assets

${user_uploaded_assets}

# Visual specification

${visual_spec}

# Plan

The planning step produced the following file list. Emit the contents of every entry in `files`, keyed by `path`, in the same order. Use each `purpose` as the brief for that file. Each entry's `images` lists the slugs that file MUST embed — resolve every slug to its `url` in the Pre-decided images section below and embed the URL verbatim.

```json
${plan_block}
```

# Pre-decided images

These images are final. The downstream `image-creation` skill will generate each one at the `url` shown below. Embed URLs verbatim — never construct a URL yourself, never change a slug, never add new entries. The `prompt` and `aspect_ratio` are informational (they tell you what the image will depict and at what shape).

```json
${images_block}
```

# Task

Produce the JSON object described in the system prompt — a single `files` object where every planned path is a key whose value is the complete file contents. Do NOT emit an `images` field. The image manifest is already final and lives in plan.json; your job is to embed the predetermined URLs in the right places.
