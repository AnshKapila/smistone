# Iteration

- Iteration ID: ${iteration_id}
- Image base URL: ${image_base_url}

# Logo

```json
${logo_block}
```

# User requirements

${user_requirements}

## Build requirements

${build_req_block}

## User-uploaded assets

${user_uploaded_assets}

# Visual specification

${visual_spec}

${brand_section}

# Available Fonts

```json
${google_font_map}
```

# Template invariants (do not plan these)

${template_invariants}

# Task

Produce the JSON object described in the system prompt. List every app-specific file the generator must author on top of the template, in the order routes → components → data → other. End each entry's `purpose` with what props or sections live inside.
