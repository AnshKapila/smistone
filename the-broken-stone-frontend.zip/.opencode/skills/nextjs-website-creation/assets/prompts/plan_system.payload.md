# Objective

This site embeds Payload CMS: content lives in the database, pages are rendered by a baked server component, and the navbar/footer are baked components fed by `SiteSettings`. Plan the files an LLM will author for a single iteration AND decide every image the site will reference. You plan up to three kinds of file: (1) **block + chrome components** under `src/components/blocks/` (plus `src/components/Header.tsx`, `src/components/Footer.tsx`) restyling the template's defaults, (2) a single **`seed.json`** holding all content (`SiteSettings` + one `Pages` doc per route with ordered blocks, plus a `collections` section when the site has repeating content), and (3) **`src/payload/collections/generated.ts`** ONLY when the site needs repeating content (a blog, case studies, menu items, events, team bios, …) — it registers those content collections. Most simple sites (a single landing page, a cafe) need no repeating content, so omit file (3) and the `collections` seed section for them. Do NOT plan route `page.tsx`, `src/data/*`, the data fetch, `sitemap.ts`, `robots.ts`, or the rest of the Payload config — they are baked; `generated.ts` is the only config file you may plan. A later generation step writes the component source and the seed manifest.

Your response MUST be raw JSON only. Start with `{`. Do NOT wrap in markdown code fences. Do NOT add prose before or after.

# Output contract

```json
{
  "files": [
    {
      "path": "seed.json",
      "purpose": "SiteSettings + home page with ordered blocks: hero, featureGrid, cta",
      "images": ["iter1-hero", "iter1-brand-logo"]
    },
    {
      "path": "src/components/blocks/Hero.tsx",
      "purpose": "hero block; renders heading, subheading, primary CTA, hero image",
      "images": []
    }
  ],
  "images": [
    {
      "slug": "iter1-hero",
      "prompt": "<full prompt-authoring-rules-compliant string>",
      "aspect_ratio": "16:9",
      "is_logo": false
    },
    {
      "slug": "iter1-brand-logo",
      "prompt": "<logo-override prompt per rules>",
      "aspect_ratio": "21:9",
      "is_logo": true
    }
  ],
  "fonts": {
    "hero": "Bricolage Grotesque",
    "heading": "Bricolage Grotesque",
    "sub_heading": "Manrope",
    "body": "Manrope"
  }
}
```

Rules for `files`:
- `path` is POSIX, relative to the iteration root, no leading slash, no `..`.
- `purpose` is one sentence, present tense, names the role and (for components) the props or sections inside.
- `images` is a list of `slug` strings embedded by this file. Block components receive image URLs as props, so their `images` is empty `[]`; the image URLs are embedded in `seed.json`, so list every image slug on the `seed.json` entry. Every slug listed here MUST appear in the top-level `images` array.
- Order: the single `seed.json` entry first, then `src/**` source files (block + chrome components, and `src/payload/collections/generated.ts` when planned). The generation step emits files in plan order; content leads so the copy is authored at full quality before the long tail of component code.

Rules for `images`:
- Each entry describes one image the downstream `image-creation` skill will generate. The generation step will reference these by URL, never invent new images.
- `slug` matches `^[a-z0-9][a-z0-9_-]{0,63}$`, is iteration-prefixed (e.g. `iter1-hero`), and is unique across the manifest.
- `prompt` is the complete image-generation prompt authored per the rules below — single natural-language string, no schemas or label blocks. The generator will pass this prompt verbatim to image generation.
- `aspect_ratio` is one of `16:9`, `4:3`, `1:1`, `3:4`, `21:9`.
- `is_logo` is `true` only for logos; logo prompts use the logo overrides (no role keyword, no no-text ending, etc.).
- Every entry in `images` MUST be referenced by at least one `files[*].images` list. Don't list images no file will embed.
- Generated logos belong here. The user-uploaded brand logo from the user prompt's `Logo` block is a separate concern (embedded directly by the generator using the `logo_url` field) — do NOT add it to this manifest.

Rules for `fonts`:
- One font per typography role: `hero`, `heading`, `sub_heading`, `body`. All four keys are required.
- Each value MUST be an exact key from the `Available Fonts` block in the user prompt. Misspellings or fonts outside that list will fail validation.
- Selection rules — which font fits which role given the `## Brand` block and visual specification — live in the Branding section below. Reuse the same font across roles freely; the downstream writer deduplicates.

# Image prompt rules

These rules apply to every entry in the top-level `images` array.

${image_prompt_rules}

## Site Image World

${image_world}

Treat this brief as the site-wide contract for every image prompt you author.

# Inputs you will receive

- A visual specification describing pages, sections, components, brand colors, typography.
- User requirements naming the business, goals, and any explicit content.
- Brand and logo metadata.
- Image base URL (for generated images) and iteration id.

# Planning rules

These rules apply to every file you list.

## Branding

${website_brand_creation}

## Sitemap & sections

${website_structure_planning}

## Copy

${website_copywriting}

## Design

${website_visual_design}

## Product visuals

${website_saas_ui_design}

## Coding

${nextjs_payload_code_writing}

## Carousels & sliders

${nextjs_website_carousel_building}

## Scroll-linked sections

${website_scroll_management}

## Content model

The seed content contract and the block library you plan against:

${cms_management}

# Planning-specific notes

The file layout conventions (Payload content model, `src/components/blocks/`, Tailwind-only styling) live in the coding rules above. Additional rules that only apply at plan time:

- Map each section in the visual spec to a block type from the cms-management block library (see the Content model section above). At plan time the block field schemas and the renderer registry are baked — express every section through library blocks (pick the closest structural fit; `richText` is the last resort), never a new blockType.
- The `seed.json` entry's purpose MUST name every block type any page's layout will use (e.g. `ordered blocks: hero, featureGrid, gallery, contact`) — list them exhaustively, not just the headline sections. Every block type named anywhere in the plan MUST have a matching component entry under `src/components/blocks/` (restyling the template default) — a used block with no restyled component ships the template's unstyled placeholder. Plan `Header.tsx`/`Footer.tsx` too when the chrome needs restyling.
- Plan `src/payload/collections/generated.ts` only when the site has **repeating content** (a blog index, case studies, menu, events, team). For each such content type, plan one collection (per the Content model section) and a `collectionList` block on the page that lists it; the `collections` section of `seed.json` holds its items. A site whose content is fully expressed as singular pages needs no collection — omit this file.
- `sitemap.ts`/`robots.ts` are baked and read from Payload — never plan them.
- Plan styles inside `className` strings on the components — do not plan a CSS module per component.

# What "one sentence purpose" looks like

- Bad: `home page`
- Bad: `the block that shows everything including hero and features and CTA and pricing`
- Good: `hero block; renders heading, subheading, primary CTA, hero image`
- Good: `seed.json; SiteSettings + home page with ordered blocks: hero, featureGrid, testimonialList, cta`

# How to decide which images the site uses

- Walk the visual specification section by section. For each section with imagery, decide whether it's content imagery (hero, product, portrait, process, etc.) or branding (logos).
- Create one `images` entry per distinct image. Name the slug after the block/section that owns it (e.g. `iter1-hero`, `iter1-feature-process`, `iter1-testimonial-anna`).
- List every image slug on the `seed.json` entry's `images` (that is where the URL is embedded, as a block field value). Block component entries keep `images: []`.
- Logo handling: if the visual spec calls for a generated brand logo, add one `is_logo: true` entry and reference its slug from `seed.json` (the `SiteSettings.logoUrl` value). If the user prompt's `Logo` block already supplies a `logo_url`, use that URL as `SiteSettings.logoUrl` directly — no manifest entry needed.
