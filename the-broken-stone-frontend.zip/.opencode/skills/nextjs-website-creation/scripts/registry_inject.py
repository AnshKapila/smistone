#!/usr/bin/env python3
"""Deterministic, re-run-safe injection of generated registry entries into the
baked renderer files between sentinel markers.

The generator authors only *leaf* files — a block's field schema
(`payload/blocks/generated.ts`) and its React component
(`components/blocks/<Name>.tsx`), or a collection's item-layout component
(`components/collections/<Name>Layout.tsx`). The literal registry **maps**
(`RenderBlocks.tsx`'s `blockComponents`, `RenderItem.tsx`'s `itemComponents`)
are written here by a deterministic post-step, never by the LLM — so the maps
stay well-formed (a single mis-emitted brace in an LLM-edited literal map breaks
the whole renderer).

This is the migration model promoted to a shared module: the page-migration
path already authors block schemas and injects RenderBlocks entries between
sentinel markers; the same mechanism now serves new-gen. Pure stdlib so it is
safe to copy into either sandbox.

Each renderer ships two marker pairs — one in the import list, one inside the
map literal:

    // >>> generated block imports
    // <<< generated block imports
    ...
    // >>> generated block registry
    // <<< generated block registry

Injection replaces everything strictly between a pair, preserving the markers,
so re-running with the same entries is a no-op and re-running with a changed set
fully rebuilds the section (never appends duplicates).
"""

from __future__ import annotations

import argparse
import pathlib
import re
import sys


class RegistryInjectError(RuntimeError):
    """A sentinel marker pair was missing or malformed in a renderer file."""


def pascal(slug: str) -> str:
    """`storyScroller` -> `StoryScroller`; `blog-posts`/`case_studies` ->
    `BlogPosts`/`CaseStudies`; leaves an already-cased name alone.

    Splits on ``-``/``_`` and capitalises each segment's first char while
    preserving the rest, so a camelCase segment (``storyScroller``) keeps its
    inner caps instead of being flattened by ``str.title()``.

    Public: this is the slug→component naming contract shared with callers
    (``generate_files`` checks component-file existence against it).
    """
    return "".join(seg[:1].upper() + seg[1:] for seg in re.split(r"[-_]", slug) if seg)


# The one spelling of a block/collection slug declaration (`slug: '<x>'`,
# either quote, kebab/snake allowed). Public: the planners' and gates'
# scanners import it so a slug this injector can write is always a slug they
# can read — three hand-synced copies drifted before (plan_files' single-quote
# alnum-only variant could never plan a kebab block).
BLOCK_SLUG_RE = re.compile(r"""slug:\s*['"]([a-zA-Z0-9_-]+)['"]""")


def _replace_between(
    lines: list[str], start_marker: str, end_marker: str, body: list[str]
) -> list[str]:
    """Return ``lines`` with everything strictly between the line containing
    ``start_marker`` and the line containing ``end_marker`` replaced by ``body``.

    Markers are matched as substrings so the surrounding comment text is free to
    change. Raises ``RegistryInjectError`` when either marker is absent or out of
    order, since a silent skip would ship an unregistered (invisible) block.
    """
    start_idx = end_idx = -1
    for i, line in enumerate(lines):
        if start_marker in line and start_idx == -1:
            start_idx = i
        elif end_marker in line and start_idx != -1:
            end_idx = i
            break
    if start_idx == -1 or end_idx == -1:
        raise RegistryInjectError(
            f"sentinel markers not found or out of order: {start_marker!r} .. {end_marker!r}"
        )
    return lines[: start_idx + 1] + body + lines[end_idx:]


def _inject_pairs(
    path: pathlib.Path,
    imports: list[str],
    entries: list[str],
    *,
    imports_markers: tuple[str, str],
    registry_markers: tuple[str, str],
) -> None:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    lines = _replace_between(lines, imports_markers[0], imports_markers[1], imports)
    lines = _replace_between(lines, registry_markers[0], registry_markers[1], entries)
    path.write_text("\n".join(lines) + ("\n" if text.endswith("\n") else ""), encoding="utf-8")


def inject_block_registry(render_blocks_path: pathlib.Path, blocks: list[dict]) -> list[str]:
    """Write custom block imports + `blockComponents` entries into RenderBlocks.tsx.

    ``blocks`` is ``[{slug, component?, import_path?}]``. ``component`` defaults
    to the PascalCase of ``slug``; ``import_path`` to ``./<Component>``. Returns
    the registered slugs. Idempotent and order-stable (sorted by slug).
    """
    blocks = sorted(blocks, key=lambda b: b["slug"])
    imports: list[str] = []
    entries: list[str] = []
    slugs: list[str] = []
    for b in blocks:
        slug = b["slug"]
        component = b.get("component") or pascal(slug)
        import_path = b.get("import_path") or f"./{component}"
        imports.append(f"import {{ {component} }} from '{import_path}';")
        entries.append(f"  '{slug}': {component},")
        slugs.append(slug)
    _inject_pairs(
        render_blocks_path,
        imports,
        entries,
        imports_markers=(">>> generated block imports", "<<< generated block imports"),
        registry_markers=(">>> generated block registry", "<<< generated block registry"),
    )
    return slugs


def inject_item_registry(render_item_path: pathlib.Path, items: list[dict]) -> list[str]:
    """Write custom item-layout imports + `itemComponents` entries into
    RenderItem.tsx.

    ``items`` is ``[{collection, component?, import_path?}]``. ``component``
    defaults to ``<PascalCollection>Layout``; ``import_path`` to
    ``./<Component>`` (RenderItem and the layouts are siblings in
    ``components/collections/``). The map is keyed by collection slug. Returns
    the registered collection slugs. Idempotent and order-stable.
    """
    items = sorted(items, key=lambda it: it["collection"])
    imports: list[str] = []
    entries: list[str] = []
    collections: list[str] = []
    for it in items:
        collection = it["collection"]
        component = it.get("component") or f"{pascal(collection)}Layout"
        import_path = it.get("import_path") or f"./{component}"
        imports.append(f"import {{ {component} }} from '{import_path}';")
        entries.append(f"  '{collection}': {component},")
        collections.append(collection)
    _inject_pairs(
        render_item_path,
        imports,
        entries,
        imports_markers=(">>> generated item imports", "<<< generated item imports"),
        registry_markers=(">>> generated item registry", "<<< generated item registry"),
    )
    return collections


# A registry entry line between the markers: `  'slug': Component,` (the
# injector always quotes keys; kebab slugs require it).
_ENTRY_KEY_RE = re.compile(r"""^\s*['"]?([A-Za-z0-9_-]+)['"]?\s*:""")


def _existing_registry_keys(path: pathlib.Path, start_marker: str, end_marker: str) -> list[str]:
    """Keys currently registered between a marker pair (empty when unreadable —
    the subsequent inject raises the real error)."""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    keys: list[str] = []
    inside = False
    for line in lines:
        if start_marker in line:
            inside = True
            continue
        if end_marker in line:
            break
        if inside and (m := _ENTRY_KEY_RE.match(line)):
            keys.append(m.group(1))
    return keys


def _main(argv: list[str]) -> int:
    """CLI so a sandbox agent can register slugs without a Python import.

    ``registry_inject.py block <RenderBlocks.tsx> <slug>...`` injects block
    entries; ``registry_inject.py item <RenderItem.tsx> <slug>...`` injects item
    (collection) entries. Prints the registered entries; non-zero on failure.

    UNION semantics: entries already registered between the markers are
    preserved and the given slugs are merged in. Per-page migration agents
    inject only the slugs they authored — replace semantics would silently
    drop every earlier page's registrations, blanking those pages' custom
    sections (the clobbered-RenderBlocks regression class). The Python
    functions keep replace semantics for callers that pass the full set.
    """
    parser = argparse.ArgumentParser(description="Inject generated registry entries.")
    parser.add_argument("kind", choices=("block", "item"))
    parser.add_argument("renderer_path")
    parser.add_argument("slugs", nargs="+")
    args = parser.parse_args(argv)

    path = pathlib.Path(args.renderer_path)
    new = set(args.slugs)

    def _merge(existing: list[str]) -> list[str]:
        # Any two DISTINCT keys that pascal() to the same component are
        # ambiguous — within the new set, or new-vs-existing: keeping both
        # emits two identical `import { X } …` lines (a compile break),
        # silently REPLACING could drop a different, still-seeded block's
        # registration (blank live sections). Two distinct blocks cannot share
        # a <Pascal>.tsx component file anyway, so this is always an error the
        # caller must resolve: reuse one spelling, or rename the new block.
        by_component: dict[str, str] = {}
        for s in sorted(new):
            comp = pascal(s)
            if comp in by_component and by_component[comp] != s:
                raise RegistryInjectError(
                    f"slugs {by_component[comp]!r} and {s!r} both map to component "
                    f"{comp} — pass a single spelling."
                )
            by_component[comp] = s
        for k in existing:
            comp = pascal(k)
            if comp in by_component and by_component[comp] != k:
                raise RegistryInjectError(
                    f"slug {by_component[comp]!r} maps to the same component ({comp}) as "
                    f"the already-registered key {k!r}. Re-run with the existing key "
                    f"{k!r} if this is the same block, or rename the new block."
                )
        return sorted(set(existing) | new)

    try:
        if args.kind == "block":
            merged = _merge(
                _existing_registry_keys(
                    path, ">>> generated block registry", "<<< generated block registry"
                )
            )
            injected = inject_block_registry(path, [{"slug": s} for s in merged])
        else:
            merged = _merge(
                _existing_registry_keys(
                    path, ">>> generated item registry", "<<< generated item registry"
                )
            )
            injected = inject_item_registry(path, [{"collection": s} for s in merged])
    except (RegistryInjectError, OSError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    for entry in injected:
        print(entry)
    return 0


if __name__ == "__main__":
    sys.exit(_main(sys.argv[1:]))
