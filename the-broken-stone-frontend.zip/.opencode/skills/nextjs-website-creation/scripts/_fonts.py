"""Generate ``src/app/fonts.ts`` for a Next.js iter from a role→font map.

The planner LLM picks one Google Font per typography role (``hero``,
``heading``, ``sub_heading``, ``body``) from the ``Available Fonts`` block in
the prompt; ``plan_files.py`` validates the selection against
``website-brand-creation/google-font-map.json`` and calls ``render_fonts_ts`` to
write the file deterministically.

External-system grammar — the URL → ``next/font/google`` options mapping —
lives here rather than in a prompt. The grammar comes from the URLs in
``google-font-map.json``; weights/variable axes are parsed out of the URL so
the LLM never has to author ``next/font/google`` call sites.
"""

from __future__ import annotations

import re
import urllib.parse

# Google Fonts CSS2 URL grammar: ``family=Name:axis1,axis2,...@v1a,v1b,...;v2a,v2b,...``.
# The axis prefix and the value tuples must be parsed position-aware — the
# wght column is determined by its index in the axis list, not by guessing
# from regex tokens. A naive 3-digit regex misclassifies opsz ranges whose
# upper bound is "144" (Fraunces, Pathway Extreme) as a weight.
_AXIS_BLOCK_RE = re.compile(r":([A-Za-z,]+)@([^&]+)")

# Order matters: the generated ``fonts.ts`` exports follow this sequence so
# the file diff is stable across iters with the same selection.
ROLES = ("hero", "heading", "sub_heading", "body")


def to_export_name(font_name: str) -> str:
    """Convert a Google Font display name to the ``next/font/google`` export.

    next/font exports use underscore-separated PascalCase ("Bricolage_Grotesque",
    "Playfair_Display"). Display names use spaces ("Bricolage Grotesque").
    """
    return font_name.replace(" ", "_").replace("-", "_")


def role_to_export(role: str) -> str:
    """Map a brand typography role to its TypeScript export name."""
    parts = role.split("_")
    camel = parts[0] + "".join(p.title() for p in parts[1:])
    return f"{camel}Font"


def parse_weights(font_url: str) -> list[str] | None:
    """Return the weight list to pass to next/font, or ``None`` for variable.

    Position-aware over the Google Fonts CSS2 URL grammar:

    - URL has no axis block (`family=Gloock`) → single-weight font, return
      ``["400"]``.
    - URL has an axis block but no ``wght`` axis and no range-valued axis
      (for example, italic-only ``ital@0;1``) → single-weight font, return
      ``["400"]``. Next.js still requires a weight for these static families.
    - URL has an axis block but no ``wght`` axis and a range-valued axis
      (for example, opsz-only ``opsz@12..24``) → variable, return ``None``.
      Passing ``weight: '400'`` to next/font for a variable-axis font that
      has no static 400 cut breaks the build.
    - URL has ``wght`` axis: read only the wght column of each value tuple.
      If any wght column is an ``N..M`` range → variable, return ``None``.
      Otherwise return the unique discrete values sorted.
    """
    decoded = urllib.parse.unquote(font_url)
    match = _AXIS_BLOCK_RE.search(decoded)
    if not match:
        return ["400"]

    axes = match.group(1).split(",")
    if "wght" not in axes:
        for segment in match.group(2).split(";"):
            if any(".." in col for col in segment.split(",")):
                return None
        return ["400"]

    wght_idx = axes.index("wght")
    weights: set[str] = set()
    for segment in match.group(2).split(";"):
        cols = segment.split(",")
        if len(cols) <= wght_idx:
            continue
        col = cols[wght_idx]
        if ".." in col:
            return None
        if col.isdigit():
            weights.add(col)
    return sorted(weights) or None


def _format_next_font_options(weights: list[str] | None) -> str:
    """Render the options object passed to a ``next/font/google`` function."""
    lines = ["  subsets: ['latin'],", "  display: 'swap',"]
    if weights is not None:
        if len(weights) == 1:
            lines.insert(0, f"  weight: '{weights[0]}',")
        else:
            joined = ", ".join(f"'{w}'" for w in weights)
            lines.insert(0, f"  weight: [{joined}],")
    return "{\n" + "\n".join(lines) + "\n}"


def render_fonts_ts(role_to_font: dict[str, tuple[str, str]]) -> str:
    """Return the contents of ``src/app/fonts.ts`` for the given role map.

    ``role_to_font`` maps each role in ``ROLES`` to a ``(display_name, url)``
    pair. The renderer instantiates one ``next/font/google`` call per unique
    font name (deduped so a brand using the same font for multiple roles
    emits one ``<link rel="preload">``) and exports it under every role that
    chose it.
    """
    missing = [r for r in ROLES if r not in role_to_font]
    if missing:
        raise ValueError(f"role_to_font missing roles: {missing}")

    # Sort by export name so both imports and instantiations have a stable
    # diff: two iters that pick the same fonts in different role orders
    # produce byte-identical fonts.ts files.
    unique: dict[str, tuple[str, str]] = {}  # display_name → (export_name, url)
    for role in ROLES:
        name, url = role_to_font[role]
        if name not in unique:
            unique[name] = (to_export_name(name), url)
    unique_sorted = dict(sorted(unique.items(), key=lambda item: item[1][0]))

    import_names = [export for export, _ in unique_sorted.values()]
    import_line = f"import {{ {', '.join(import_names)} }} from 'next/font/google';"

    instantiations = []
    for name, (export, url) in unique_sorted.items():
        options = _format_next_font_options(parse_weights(url))
        instantiations.append(f"const {_instance_var(export)} = {export}({options});")

    exports = []
    for role in ROLES:
        name, _ = role_to_font[role]
        export_name = role_to_export(role)
        instance = _instance_var(unique_sorted[name][0])
        exports.append(f"export const {export_name} = {instance};")

    return (
        f"{import_line}\n\n"
        "// Brand fonts wired in by nextjs-website-creation/scripts/plan_files.py.\n"
        "// The planner LLM picks one Google Font per typography role from the\n"
        "// Available Fonts map; this file exports each role as a next/font\n"
        "// instance for components to apply via `.className`.\n\n"
        + "\n".join(instantiations)
        + "\n\n"
        + "\n".join(exports)
        + "\n"
    )


def _instance_var(export_name: str) -> str:
    """Internal variable name for the ``next/font/google`` call result."""
    # Drop trailing underscores, lowercase first char: ``Bricolage_Grotesque``
    # → ``_bricolageGrotesque``. The leading underscore signals "module-
    # private — components must import the role exports, not these."
    parts = export_name.split("_")
    camel = parts[0].lower() + "".join(p.title() for p in parts[1:])
    return f"_{camel}"


def validate_fonts_block(fonts: dict, font_map: dict[str, str]) -> dict[str, tuple[str, str]]:
    """Validate a planner ``fonts`` block against the Google Font map.

    Returns ``{role: (name, url)}`` when every required role names a font that
    exists in ``font_map``. Raises ``ValueError`` with the specific failure
    so ``_parse_plan`` can surface it the same way it surfaces other
    contract violations.
    """
    if not isinstance(fonts, dict):
        raise ValueError(f"plan.fonts must be an object, got {type(fonts).__name__}")

    resolved: dict[str, tuple[str, str]] = {}
    for role in ROLES:
        raw = fonts.get(role)
        if raw is None or raw == "":
            raise ValueError(f"plan.fonts missing role {role!r}")
        if not isinstance(raw, str):
            raise ValueError(
                f"plan.fonts[{role!r}] must be a string, got {type(raw).__name__}: {raw!r}"
            )
        name = raw.strip()
        if not name:
            raise ValueError(f"plan.fonts missing role {role!r}")
        url = font_map.get(name)
        if not url:
            raise ValueError(
                f"plan.fonts[{role!r}] = {name!r} is not a key in google-font-map.json"
            )
        resolved[role] = (name, url)
    return resolved
