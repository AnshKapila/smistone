#!/usr/bin/env python3
"""Plan the Next.js files the generator will author in the generation step.

Fetches the visual spec, then runs the planning LLM once to enumerate the
app-specific files (routes, components, data modules) that need to be
authored on top of the template. The iter directory itself is seeded by
the backend ahead of sandbox boot (see ``website_service._seed_nextjs_iter_dirs``),
so this script can assume ``$EFS_APP_PATH/iterations/<iter>/`` already
contains the template scaffold. Writes
``$EFS_APP_PATH/iterations/<iter>/plan.json``.
"""

from __future__ import annotations

import json
import os
import pathlib
import re
import sys
import time
import urllib.error
import urllib.request

SKILL_DIR = pathlib.Path(__file__).resolve().parent.parent
PROMPTS_DIR = SKILL_DIR / "assets" / "prompts"

sys.path.insert(0, str(SKILL_DIR.parent / "lib"))
sys.path.insert(0, str(SKILL_DIR.parent / "image-creation" / "scripts"))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import _fonts  # noqa: E402
import image_world  # noqa: E402
import llm_utils  # noqa: E402
import registry_inject  # noqa: E402

MODEL = "google/gemini-3.1-pro-preview"
TEMPERATURE = 0.4
REASONING_EFFORT = "high"
# No internal urllib timeout — matches generate_files.py. A 300s urllib cap
# previously raced the bash-tool timeout (also 300s in SKILL.md). On slow
# reasoning turns the urllib cap fires first and the agent retries in vain.
# The agent's bash tool wrapper is the only outer bound.
TIMEOUT_SECS: int | None = None

VALID_ASPECT_RATIOS = {"16:9", "4:3", "1:1", "3:4", "21:9"}
_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")

# Two template kinds exist (see website_service._seed_nextjs_iter_dirs): the
# classic `nextjs-template/` and the Payload-CMS `nextjs-template-payload/`.
# Which one seeded this iter is detected from the baked artifact (see
# is_payload_mode); every Payload-specific rule list, invariant, gate, and
# prompt below branches on that, so a classic iter plans exactly as before
# Payload existed.

_CLASSIC_RULE_NAMES = (
    "website-brand-creation",
    "website-structure-planning",
    "website-copywriting",
    "website-visual-design",
    "nextjs-code-writing",
    "website-carousel-building",
    "website-scroll-management",
    "website-seo-metadata-management",
    "website-saas-ui-design",
)

_PAYLOAD_RULE_NAMES = (
    "website-brand-creation",
    "website-structure-planning",
    "website-copywriting",
    "website-visual-design",
    "nextjs-payload-code-writing",
    "cms-management",
    "nextjs-website-carousel-building",
    "website-scroll-management",
    "website-saas-ui-design",
)

# Files already shipped with the template. The planner is told these exist so
# it does not re-plan them and the generator does not re-emit them.
_CLASSIC_TEMPLATE_INVARIANTS = (
    "package.json",
    "pnpm-lock.yaml",
    "tsconfig.json",
    "next.config.js",
    "next-env.d.ts",
    "postcss.config.js",
    "middleware.ts",
    "vercel.ts",
    "redirects.csv",
    ".npmrc",
    ".nvmrc",
    "src/app/layout.tsx",
    "src/app/globals.css",
    "src/app/robots.ts",
    "src/lib/site-url.ts",
    "public/favicon.svg",
)

_PAYLOAD_TEMPLATE_INVARIANTS = (
    "package.json",
    "pnpm-lock.yaml",
    "tsconfig.json",
    "next.config.mjs",
    "next-env.d.ts",
    "postcss.config.mjs",
    "middleware.ts",
    "vercel.ts",
    "redirects.csv",
    ".npmrc",
    ".nvmrc",
    # Payload CMS scaffold + baked render path (content lives in the DB; pages
    # are rendered by the baked server component, not authored route files).
    "src/payload.config.ts",
    "src/payload-types.ts",
    "scripts/seed-payload.ts",
    "src/app/(frontend)/layout.tsx",
    "src/app/(frontend)/[[...slug]]/page.tsx",
    "src/components/blocks/RenderBlocks.tsx",
    # Item registry: dispatches a content item to its per-collection layout. Like
    # RenderBlocks, its literal map is written deterministically (registry_inject)
    # — the generator authors custom <Name>Layout.tsx leaves, never this file.
    "src/components/collections/RenderItem.tsx",
    "src/app/sitemap.ts",
    "src/app/robots.ts",
    "src/app/globals.css",
    "public/favicon.svg",
    "public/robots.txt",
)

# Reserved subtrees. Any plan entry whose path starts with one of these
# prefixes is dropped (and the planner prompt instructs the model to leave
# them alone). Covers the platform-provided route surface and, in Payload
# mode, the Payload CMS scaffold (admin/REST routes + collection/global/block
# field schemas) so generated app files can never collide with them. The
# generator authors block *components* (`src/components/blocks/`), never the
# block *field schemas* (`src/payload/blocks/`).
_CLASSIC_TEMPLATE_INVARIANT_PREFIXES = ("src/app/api/v1/kite-platform/",)

_PAYLOAD_TEMPLATE_INVARIANT_PREFIXES = (
    "src/app/api/v1/kite-platform/",
    "src/app/(payload)/",
    "src/payload/",
)

# Exceptions to the reserved subtrees above: exact paths the generator MAY author
# even though they fall under a reserved prefix. Both are generation-driven
# "generated.ts" leaves whose registries are written deterministically, never the
# baked config/globals:
#   - collections/generated.ts — content collections, when the site needs
#     repeating content (a blog, case studies, …).
#   - blocks/generated.ts — CUSTOM block field schemas, when a design needs a
#     bespoke section no library block covers. Its component
#     (src/components/blocks/<Name>.tsx) is already authorable, and its
#     RenderBlocks registry entry is injected deterministically post-generation
#     (registry_inject), so the LLM never edits the literal map.
# The rest of `src/payload/` (config, baked block field schemas, globals) stays
# baked.
_PAYLOAD_TEMPLATE_INVARIANT_PREFIX_EXCEPTIONS = (
    "src/payload/collections/generated.ts",
    "src/payload/blocks/generated.ts",
)


def is_payload_mode(iter_dir: pathlib.Path) -> bool:
    """Whether this iter was seeded from the Payload template.

    Keyed off the baked artifact, not a flag: the template kind was decided
    once at app creation, so the file on disk is the ground truth for what
    this iter actually runs.
    """
    return (iter_dir / "src" / "payload.config.ts").is_file()


def rule_names(payload_mode: bool) -> tuple[str, ...]:
    return _PAYLOAD_RULE_NAMES if payload_mode else _CLASSIC_RULE_NAMES


def template_invariants(payload_mode: bool) -> tuple[str, ...]:
    return _PAYLOAD_TEMPLATE_INVARIANTS if payload_mode else _CLASSIC_TEMPLATE_INVARIANTS


def template_invariant_prefixes(payload_mode: bool) -> tuple[str, ...]:
    return (
        _PAYLOAD_TEMPLATE_INVARIANT_PREFIXES
        if payload_mode
        else _CLASSIC_TEMPLATE_INVARIANT_PREFIXES
    )


def template_invariant_prefix_exceptions(payload_mode: bool) -> tuple[str, ...]:
    return _PAYLOAD_TEMPLATE_INVARIANT_PREFIX_EXCEPTIONS if payload_mode else ()


def _emit(payload: dict) -> None:
    print(json.dumps(payload))


_VISUAL_SPEC_FETCH_ATTEMPTS = 3
_VISUAL_SPEC_FETCH_BACKOFF_SECS = 1.0


def _fetch_visual_spec(user_requirements: str, iter_dir: pathlib.Path) -> str | None:
    """Fetch a visual spec from the Gallery API and write iter metadata.

    Mirrors html-generation/scripts/generate_html.py:_fetch_visual_spec.
    Retries up to ``_VISUAL_SPEC_FETCH_ATTEMPTS`` times. Returns None after
    exhaustion so the caller's "Missing inputs: visual_spec.md" error fires.
    """
    gallery_url = os.environ.get("GALLERY_API_URL", "").rstrip("/")
    gallery_token = os.environ.get("GALLERY_API_TOKEN", "")
    if not gallery_url or not gallery_token:
        return None
    payload = json.dumps({"data": [user_requirements], "quantity": 1}).encode()

    def _attempt() -> str | None:
        req = urllib.request.Request(
            f"{gallery_url}/api/external/visual-specs",
            data=payload,
            headers={
                "Authorization": f"Bearer {gallery_token}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=30) as resp:  # noqa: S310
            body = json.loads(resp.read())
        category = body.get("category", {})
        specs = body.get("visual_specs", [])
        if not specs or not specs[0].get("visual_spec"):
            return None
        meta = {
            "category_name": category.get("name"),
            "inspiration_website_name": specs[0].get("inspiration_website_name"),
            "inspiration_website_id": specs[0].get("inspiration_website_id"),
        }
        iter_dir.mkdir(parents=True, exist_ok=True)
        (iter_dir / "visual_spec_meta.json").write_text(json.dumps(meta), encoding="utf-8")
        return specs[0]["visual_spec"]

    for attempt in range(1, _VISUAL_SPEC_FETCH_ATTEMPTS + 1):
        try:
            spec = _attempt()
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, ValueError, KeyError):
            spec = None
        if spec:
            return spec
        if attempt < _VISUAL_SPEC_FETCH_ATTEMPTS:
            time.sleep(_VISUAL_SPEC_FETCH_BACKOFF_SECS)
    return None


def _build_system_prompt(skills_dir: pathlib.Path, *, image_world: str, payload_mode: bool) -> str:
    rules = {
        name.replace("-", "_"): llm_utils.read_rule(skills_dir, name)
        for name in rule_names(payload_mode)
    }
    # The planner only enumerates files into plan.json — it does not transcribe
    # component code — so it needs website-scroll-management's DOM contract + data shape (in
    # the lean SKILL.md body) but NOT the ~350 lines of verbatim init JS/TSX.
    # That gets inlined only at the generate step (generate_files.py), keeping
    # this cacheable prefix small and the planner at the right altitude.
    # Image-prompt authoring now happens during planning so the manifest
    # lands in plan.json with full prompts and predetermined URLs. Mirrors
    # how html-generation imports the same block.
    rules["image_prompt_rules"] = llm_utils.read_file(
        skills_dir / "image-creation" / "references" / "prompt-authoring.md"
    )
    rules["image_world"] = image_world
    prompt_name = "plan_system.payload.md" if payload_mode else "plan_system.md"
    return llm_utils.load_prompt(prompt_name, rules, prompts_dir=PROMPTS_DIR)


def _build_user_prompt(
    *,
    visual_spec: str,
    user_requirements: str,
    build_requirements: list[str],
    user_uploaded_assets: str,
    logo_info: dict,
    brand: dict | None,
    google_font_map: dict[str, str],
    iteration_id: str,
    image_base_url: str,
    payload_mode: bool,
) -> str:
    brand_section = f"# Brand\n\n```json\n{json.dumps(brand, indent=2)}\n```" if brand else ""
    return llm_utils.load_prompt(
        "plan_user.md",
        {
            "iteration_id": iteration_id,
            "image_base_url": image_base_url,
            "logo_block": json.dumps(logo_info or {}, indent=2),
            "user_requirements": user_requirements,
            "build_req_block": (
                "\n".join(f"- {r}" for r in build_requirements) if build_requirements else "(none)"
            ),
            "user_uploaded_assets": user_uploaded_assets or "(none)",
            "visual_spec": visual_spec,
            "brand_section": brand_section,
            "google_font_map": json.dumps(google_font_map, indent=2),
            "template_invariants": "\n".join(
                [f"- {p}" for p in template_invariants(payload_mode)]
                + [f"- {p}**" for p in template_invariant_prefixes(payload_mode)]
                + [
                    f"- EXCEPTION (you MAY plan this): {p}"
                    for p in template_invariant_prefix_exceptions(payload_mode)
                ]
            ),
        },
        prompts_dir=PROMPTS_DIR,
    )


def _parse_plan(
    response: str, *, image_base_url: str, font_map: dict[str, str], payload_mode: bool
) -> tuple[list[dict], list[dict], dict[str, tuple[str, str]], list[str]]:
    """Parse the LLM's JSON response into validated files, images, and fonts.

    Returns:
      - files: [{path, purpose, images}]
      - images: [{slug, prompt, aspect_ratio, is_logo, url}]
      - fonts: {role: (display_name, url)} for every role in ``_fonts.ROLES``
      - warnings: non-fatal issues to surface

    URL is computed server-side as ``{image_base_url}/{slug}.png`` so the
    generator can copy-paste verbatim and there's no chance of the model
    inventing a different URL than what the ``image-creation`` skill will create.
    Font selection is validated against ``font_map`` so every name maps to a
    known Google Font; the downstream writer instantiates ``next/font/google``
    deterministically from the resolved URLs.
    """
    stripped = llm_utils.strip_markdown_fences(response).strip()
    payload = json.loads(stripped)
    if not isinstance(payload, dict):
        raise ValueError(f"plan must be a JSON object, got {type(payload).__name__}")

    # --- files ---
    raw_files = payload.get("files")
    if not isinstance(raw_files, list) or not raw_files:
        raise ValueError("plan.files must be a non-empty list")
    invariants = set(template_invariants(payload_mode))
    cleaned_files: list[dict] = []
    for entry in raw_files:
        if not isinstance(entry, dict):
            raise ValueError(f"plan file entry must be an object: {entry!r}")
        path = (entry.get("path") or "").strip()
        purpose = (entry.get("purpose") or "").strip()
        if not path or not purpose:
            raise ValueError(f"plan entry missing path or purpose: {entry!r}")
        if path.startswith("/") or ".." in pathlib.PurePosixPath(path).parts:
            raise ValueError(f"plan entry has unsafe path: {path}")
        if path in invariants:
            continue
        if any(
            path.startswith(prefix) for prefix in template_invariant_prefixes(payload_mode)
        ) and path not in template_invariant_prefix_exceptions(payload_mode):
            continue
        raw_images = entry.get("images") or []
        if not isinstance(raw_images, list):
            raise ValueError(f"plan file {path!r} has non-list images: {raw_images!r}")
        images_per_file: list[str] = []
        for slug in raw_images:
            if not isinstance(slug, str) or not slug:
                raise ValueError(f"plan file {path!r} has invalid image slug: {slug!r}")
            images_per_file.append(slug)
        cleaned_files.append({"path": path, "purpose": purpose, "images": images_per_file})
    if not cleaned_files:
        raise ValueError("plan contained only template invariants")

    # --- images manifest ---
    raw_images = payload.get("images") or []
    if not isinstance(raw_images, list):
        raise ValueError(f"plan.images must be a list, got {type(raw_images).__name__}")
    base = image_base_url.rstrip("/")
    cleaned_images: list[dict] = []
    seen_slugs: set[str] = set()
    for entry in raw_images:
        if not isinstance(entry, dict):
            raise ValueError(f"plan image entry must be an object: {entry!r}")
        slug = (entry.get("slug") or "").strip()
        prompt = (entry.get("prompt") or "").strip()
        aspect_ratio = (entry.get("aspect_ratio") or "").strip()
        is_logo = bool(entry.get("is_logo") or False)
        if not _SLUG_RE.match(slug):
            raise ValueError(f"image slug invalid (must match {_SLUG_RE.pattern}): {slug!r}")
        if slug in seen_slugs:
            raise ValueError(f"image slug duplicated: {slug!r}")
        if not prompt:
            raise ValueError(f"image {slug!r} has empty prompt")
        if aspect_ratio not in VALID_ASPECT_RATIOS:
            raise ValueError(
                f"image {slug!r} has invalid aspect_ratio {aspect_ratio!r}; "
                f"must be one of {sorted(VALID_ASPECT_RATIOS)}"
            )
        seen_slugs.add(slug)
        cleaned_images.append(
            {
                "slug": slug,
                "prompt": prompt,
                "aspect_ratio": aspect_ratio,
                "is_logo": is_logo,
                "url": f"{base}/{slug}.png",
            }
        )

    # --- cross-reference: every file image must exist in the manifest ---
    referenced: set[str] = set()
    for file_entry in cleaned_files:
        for slug in file_entry["images"]:
            if slug not in seen_slugs:
                raise ValueError(
                    f"plan file {file_entry['path']!r} references unknown image slug {slug!r}; "
                    f"declare it in the top-level images array"
                )
            referenced.add(slug)
    warnings: list[str] = []
    orphaned = seen_slugs - referenced
    if orphaned:
        # Soft warning: an image listed in the manifest but no file embeds
        # it is wasted generation work. Don't fail — the user-uploaded
        # logo path could legitimately be a corner case we haven't seen.
        warnings.append(f"manifest images not referenced by any file: {sorted(orphaned)}")

    # --- fonts ---
    raw_fonts = payload.get("fonts")
    if raw_fonts is None:
        raise ValueError("plan.fonts is required (object with hero/heading/sub_heading/body)")
    resolved_fonts = _fonts.validate_fonts_block(raw_fonts, font_map)

    return cleaned_files, cleaned_images, resolved_fonts, warnings


# One slug spelling, one owner (registry_inject): a kebab/snake block slug the
# registry declares must be PLANNABLE, or it can never be planned here yet is
# expected downstream.
_BLOCK_SLUG_RE = registry_inject.BLOCK_SLUG_RE


def _read_block_registry(iter_dir: pathlib.Path) -> set[str]:
    """Block slugs from the iteration's baked block registry.

    Read from the iter's own ``src/payload/blocks/index.ts`` (not a hardcoded
    list) so the expansion below stays in sync with whatever block library the
    template ships. Returns empty on a missing/unreadable registry — expansion
    is then skipped and the generate step's emission gate stays the backstop.
    """
    try:
        text = (iter_dir / "src" / "payload" / "blocks" / "index.ts").read_text(encoding="utf-8")
    except OSError:
        return set()
    return set(_BLOCK_SLUG_RE.findall(text))


def _block_component_path(slug: str) -> str:
    # registry_inject.pascal is the slug→component naming contract — naive
    # capitalization emits the invalid `Story-scroller.tsx` for kebab slugs.
    return f"src/components/blocks/{registry_inject.pascal(slug)}.tsx"


def _expand_block_components(
    files: list[dict], iter_dir: pathlib.Path
) -> tuple[list[dict], list[str]]:
    """Append component entries for library blocks the plan uses but never covers.

    The systematic emission-gate failure shape (3/3 iterations on app 23632299):
    the seed entry's purpose names blocks (`gallery`, `contact`, …) the plan has
    no `src/components/blocks/` entry for, the generator follows the plan
    faithfully, and every iteration burns a full regeneration round to add the
    missing components. Block mentions are checkable deterministically — slugs
    are exact camelCase tokens from a finite baked registry — so close the gap
    here instead of discovering it after a multi-minute LLM call.
    """
    registry = _read_block_registry(iter_dir)
    if not registry:
        return files, [
            "block registry unreadable; skipping deterministic block-component expansion"
        ]
    planned_paths = {entry["path"] for entry in files}
    mentioned = {
        slug
        for slug in registry
        for entry in files
        if re.search(rf"\b{re.escape(slug)}\b", entry["purpose"])
    }
    added: list[str] = []
    for slug in sorted(mentioned):
        path = _block_component_path(slug)
        if path in planned_paths:
            continue
        files.append(
            {
                "path": path,
                "purpose": f"restyle the {slug} block to the visual spec",
                "images": [],
            }
        )
        added.append(path)
    warnings = [f"plan named blocks without component entries; appended: {added}"] if added else []
    return files, warnings


def _write_fonts_ts(iter_dir: pathlib.Path, role_to_font: dict[str, tuple[str, str]]) -> None:
    """Write ``iter_dir/src/app/fonts.ts`` from the planner's resolved fonts.

    The file is always written — never skipped — because the template no
    longer ships a default ``fonts.ts``. Generated components import
    ``{ heroFont, bodyFont, ... }`` from ``@/app/fonts`` and apply
    ``${roleFont.className}``; missing this file is a build failure.
    """
    fonts_target = iter_dir / "src" / "app" / "fonts.ts"
    fonts_target.parent.mkdir(parents=True, exist_ok=True)
    fonts_target.write_text(_fonts.render_fonts_ts(role_to_font), encoding="utf-8")


def _images_manifest(plan_images: list[dict]) -> list[dict]:
    """Strip the ``url`` field for the ``images.json`` consumed by the
    ``image-creation`` skill (its contract is ``[{slug, prompt, aspect_ratio, is_logo}]``).
    URLs live only in plan.json — the generator reads them from there.
    """
    return [
        {
            "slug": img["slug"],
            "prompt": img["prompt"],
            "aspect_ratio": img["aspect_ratio"],
            "is_logo": img["is_logo"],
        }
        for img in plan_images
    ]


def main() -> int:
    # iter slug: positional arg overrides the ITERATION_ID env default.
    iter_name = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("ITERATION_ID")
    if not iter_name:
        _emit({"status": "error", "error": "no iter_name: pass as arg or set ITERATION_ID env"})
        return 2
    warnings: list[str] = []

    efs = os.environ.get("EFS_APP_PATH")
    if not efs:
        _emit({"status": "error", "error": "EFS_APP_PATH env var not set"})
        return 2
    efs_path = pathlib.Path(efs)

    # Per the ecosystem config contract (e2b/generate-ecosystem-config.mjs),
    # iter project trees live at $EFS_APP_PATH/iterations/<iter>/ (V2-4432).
    # The iter dir is seeded by the backend before sandbox boot — see
    # website_service._seed_nextjs_iter_dirs. iter_dir/package.json
    # presence is the signal that seeding completed.
    iter_dir = efs_path / "iterations" / iter_name
    visual_spec_path = iter_dir / "visual_spec.md"
    workpad_path = efs_path / "workpad.json"
    # The create agent is scoped to the iter run dir, so opencode_cli pushes the
    # skill tree to iterations/<iter>/.opencode/skills — not the app root. Read
    # rules from the tree this script lives in (the same one the lib/image-creation
    # imports above resolve from); EFS_APP_PATH/.opencode/skills is empty on a
    # fresh app and yields "Rule file missing".
    skills_dir = SKILL_DIR.parent
    payload_mode = is_payload_mode(iter_dir)

    user_requirements = os.environ.get("USER_REQUIREMENTS", "")
    user_uploaded_assets = os.environ.get("USER_UPLOADED_ASSETS", "")
    image_base_url = os.environ.get("IMAGE_BASE_URL", "")
    api_key = os.environ.get("OPENROUTER_API_KEY", "")

    missing = []
    if not (iter_dir / "package.json").is_file():
        missing.append(f"iter scaffold at {iter_dir} (backend seed did not run)")
    if not workpad_path.is_file():
        missing.append(str(workpad_path))
    if not image_base_url:
        missing.append("IMAGE_BASE_URL env")
    if not api_key:
        missing.append("OPENROUTER_API_KEY env")
    if missing:
        _emit({"status": "error", "error": f"Missing inputs: {missing}"})
        return 2

    # Scrape mode wins absolute: when docs/scraped_visual_spec.md exists, use
    # it as the visual spec for every iteration. Gallery is skipped — the user
    # has explicitly asked Kite to replicate another site's design, and all 3
    # iters must share that one spec. Materialize it into iterations/<iter>/
    # visual_spec.md (not just repoint): generate_files.py is a separate sandbox
    # process that independently requires that per-iter file.
    scraped_global_path = efs_path / "docs" / "scraped_visual_spec.md"
    if scraped_global_path.is_file():
        visual_spec_path.write_text(
            scraped_global_path.read_text(encoding="utf-8"), encoding="utf-8"
        )
    else:
        spec_content = _fetch_visual_spec(user_requirements, iter_dir)
        if spec_content:
            visual_spec_path.write_text(spec_content, encoding="utf-8")
    if not visual_spec_path.is_file():
        _emit({"status": "error", "error": f"Missing inputs: [{visual_spec_path}]"})
        return 2

    try:
        workpad = json.loads(llm_utils.read_file(workpad_path))
    except (OSError, ValueError) as e:
        _emit({"status": "error", "error": f"workpad.json unreadable: {e}"})
        return 2

    image_world_artifacts = image_world.generate_image_world(
        operation="generate",
        user_requirements=user_requirements,
        build_requirements=workpad.get("build_requirements") or [],
        visual_specification=llm_utils.read_file(visual_spec_path),
        user_uploaded_assets=user_uploaded_assets,
        logo_info=workpad.get("logo_info") or {},
        context_html="",
        current_html=None,
        api_key=api_key,
        proxy_url=llm_utils.proxy_url(f"image_world.{iter_name}"),
    )
    iter_dir.mkdir(parents=True, exist_ok=True)
    (iter_dir / "image_world.md").write_text(image_world_artifacts.brief, encoding="utf-8")
    # Debug prompt artifacts live under a dedicated sandbox-owned dir to avoid
    # colliding with ``prompts-used/`` which the backend (uid ``user``) creates
    # ahead of the agent and locks down to 755. The agent (uid ``agent``)
    # can't write into that backend-owned dir.
    image_world_dir = iter_dir / "image-world-prompts"
    image_world_dir.mkdir(parents=True, exist_ok=True)
    (image_world_dir / "system.md").write_text(
        image_world_artifacts.system_prompt, encoding="utf-8"
    )
    (image_world_dir / "user.md").write_text(image_world_artifacts.user_prompt, encoding="utf-8")

    try:
        system_prompt = _build_system_prompt(
            skills_dir, image_world=image_world_artifacts.brief, payload_mode=payload_mode
        )
    except RuntimeError as e:
        _emit({"status": "error", "error": str(e)})
        return 2

    # Load brand (per-iter, may be absent — iter3 always, iter1/2 conditionally)
    # and the canonical Google Font map. Both are passed into the planner's user
    # prompt so the LLM can pick fonts per role; the same font map gates the
    # planner's ``fonts`` output against unknown names.
    brand: dict | None = None
    brand_path = efs_path / "docs" / iter_name / "brand.json"
    if brand_path.is_file():
        try:
            loaded = json.loads(llm_utils.read_file(brand_path))
            brand = loaded if isinstance(loaded, dict) else None
        except (OSError, ValueError) as e:
            warnings.append(f"brand.json unreadable, treating as absent: {e}")

    font_map_path = skills_dir / "website-brand-creation" / "google-font-map.json"
    try:
        google_font_map = json.loads(llm_utils.read_file(font_map_path))
    except (OSError, ValueError) as e:
        _emit({"status": "error", "error": f"google-font-map.json unreadable: {e}"})
        return 2
    if not isinstance(google_font_map, dict) or not google_font_map:
        _emit({"status": "error", "error": "google-font-map.json must be a non-empty object"})
        return 2

    user_prompt = _build_user_prompt(
        visual_spec=llm_utils.read_file(visual_spec_path),
        user_requirements=user_requirements,
        build_requirements=workpad.get("build_requirements") or [],
        user_uploaded_assets=user_uploaded_assets,
        logo_info=workpad.get("logo_info") or {},
        brand=brand,
        google_font_map=google_font_map,
        iteration_id=iter_name,
        image_base_url=image_base_url,
        payload_mode=payload_mode,
    )

    t0 = time.time()
    try:
        files, images, fonts, parse_warnings = llm_utils.call_llm_parsed(
            parse=lambda response: _parse_plan(
                response,
                image_base_url=image_base_url,
                font_map=google_font_map,
                payload_mode=payload_mode,
            ),
            warnings=warnings,
            url=llm_utils.proxy_url(f"nextjs_plan.{iter_name}"),
            model=MODEL,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            api_key=api_key,
            temperature=TEMPERATURE,
            reasoning_effort=REASONING_EFFORT,
            timeout=TIMEOUT_SECS,
        )
    except (urllib.error.URLError, TimeoutError, RuntimeError) as e:
        dur = round(time.time() - t0, 2)
        _emit(
            {
                "status": "error",
                "error": f"{type(e).__name__}: {e}",
                "duration_s": dur,
                "warnings": warnings,
            }
        )
        return 1
    except (ValueError, json.JSONDecodeError) as e:
        dur = round(time.time() - t0, 2)
        _emit(
            {
                "status": "error",
                "error": f"plan parse failed: {e}",
                "duration_s": dur,
                "warnings": warnings,
            }
        )
        return 1
    warnings.extend(parse_warnings)

    # Payload-only: block components are derived from the Payload block
    # registry, which classic iters don't have.
    if payload_mode:
        files, expand_warnings = _expand_block_components(files, iter_dir)
        warnings.extend(expand_warnings)

    plan_path = iter_dir / "plan.json"
    images_path = iter_dir / "images.json"
    try:
        plan_path.write_text(
            json.dumps(
                {
                    "files": files,
                    "images": images,
                    "fonts": {role: name for role, (name, _url) in fonts.items()},
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        # The image-creation skill's manifest is written now so image generation can
        # start in parallel with file generation. Its contract is
        # ``[{slug, prompt, aspect_ratio, is_logo}]`` — URLs stay in plan.json
        # for the generator to read.
        images_path.write_text(
            json.dumps(_images_manifest(images), indent=2),
            encoding="utf-8",
        )
        # Materialize the brand-chosen Google Fonts into ``src/app/fonts.ts``
        # so generated components can ``import { heroFont, bodyFont } from
        # '@/app/fonts'`` and apply ``${roleFont.className}``. The template
        # ships no default fonts.ts — this write is the only authoring path,
        # and the planner's validated ``fonts`` block guarantees every role
        # resolves to a known Google Font URL before we get here.
        _write_fonts_ts(iter_dir, fonts)
    except OSError as e:
        dur = round(time.time() - t0, 2)
        _emit(
            {
                "status": "error",
                "error": f"EFS write failed: {type(e).__name__}: {e}",
                "duration_s": dur,
            }
        )
        return 1

    _emit(
        {
            "status": "success",
            "plan_path": str(plan_path),
            "images_path": str(images_path),
            "file_count": len(files),
            "image_count": len(images),
            "duration_s": round(time.time() - t0, 2),
            "iteration_id": iter_name,
            "warnings": warnings,
        }
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
