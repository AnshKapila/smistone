#!/usr/bin/env python3
"""Generate file contents for the planned Next.js app via the generation LLM.

Reads `iterations/<iter>/plan.json` (produced by `plan_files.py`) and runs the
generation LLM once to emit the full contents of every planned file. Writes
each file under `iterations/<iter>/`. Also fires off image generation (off
`iterations/<iter>/images.json`) in a background thread at the start so it
overlaps with the LLM call — the agent driving this skill no longer
dispatches images itself; already-live CDN images are skipped.

A blocking-gate failure (missing file/component, duplicate injected field)
triggers ONE scoped repair LLM call for just the gap before the run is
declared failed. `--skip-llm` re-runs the post-generation pipeline against
the files already on disk — the path for after manual repairs, so a hand
fix never costs a full regeneration.
"""

from __future__ import annotations

import concurrent.futures
import json
import os
import pathlib
import re
import subprocess  # noqa: S404 - intentional invocation of pnpm CLI
import sys
import time
import urllib.error
import urllib.request

SKILL_DIR = pathlib.Path(__file__).resolve().parent.parent
PROMPTS_DIR = SKILL_DIR / "assets" / "prompts"

sys.path.insert(0, str(SKILL_DIR.parent / "lib"))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import llm_utils  # noqa: E402
import registry_inject  # noqa: E402

MODEL = "google/gemini-3.1-pro-preview"
TEMPERATURE = 0.7
REASONING_EFFORT = "high"
# No internal urllib timeout — generation at reasoning_effort=high on a large
# plan can take 5–10+ minutes. A previous 300s cap was firing in the middle
# of legitimate long calls and Sonnet was retrying the whole run
# (tool_result: ``TimeoutError: timed out`` at duration_s=300.11). The
# agent's bash tool wrapper (1800000ms = 30 min, matching E2B's run_command
# cap) is the real budget;
# this script just lets the urllib request run as long as it needs to.
TIMEOUT_SECS: int | None = None
PNPM_INSTALL_TIMEOUT_SECS = 180
GENERATE_TYPES_TIMEOUT_SECS = 120
SEED_TIMEOUT_SECS = 120
# The CMS validator boots Payload (schema push + a rolled-back Local-API write)
# when a DB is reachable, so it gets the same headroom as the seed step.
VALIDATE_TIMEOUT_SECS = 180

# Image generation runs concurrently with the generation LLM call. The shared-tools
# Image Creation route caps each request at 10 entries, so larger manifests are
# split across parallel batches. Each batch is bounded by the route's own
# generation budget — give urllib the same headroom the agent's curl had.
IMAGE_API_PATH = "/api/v1/internal/shared-tools/images/generate"
IMAGE_BATCH_SIZE = 10
IMAGE_REQUEST_TIMEOUT_SECS = 300
IMAGE_MAX_PARALLEL_BATCHES = 4
IMAGE_PROBE_TIMEOUT_SECS = 15

# Two template kinds exist (see website_service._seed_nextjs_iter_dirs): the
# classic `nextjs-template/` and the Payload-CMS `nextjs-template-payload/`.
# Which one seeded this iter is detected from the baked artifact (see
# _is_payload_mode); the Payload-specific rules, prompts, gates, CMS
# validation, and seeding below all branch on that, so a classic iter
# generates exactly as before Payload existed.

_CLASSIC_RULE_NAMES = (
    "website-brand-creation",
    "website-structure-planning",
    "website-copywriting",
    "website-visual-design",
    "nextjs-code-writing",
    "website-carousel-building",
    "website-scroll-management",
    "website-seo-metadata-management",
    "website-saas-ui-design",
)

_PAYLOAD_RULE_NAMES = (
    "website-brand-creation",
    "website-structure-planning",
    "website-copywriting",
    "website-visual-design",
    "nextjs-payload-code-writing",
    "cms-management",
    "nextjs-website-carousel-building",
    "website-scroll-management",
    "website-saas-ui-design",
)


def _is_payload_mode(iter_dir: pathlib.Path) -> bool:
    """Whether this iter was seeded from the Payload template.

    Keyed off the baked artifact, not a flag: the template kind was decided
    once at app creation, so the file on disk is the ground truth for what
    this iter actually runs.
    """
    return (iter_dir / "src" / "payload.config.ts").is_file()


def _emit(payload: dict) -> None:
    print(json.dumps(payload))


def _build_system_prompt(skills_dir: pathlib.Path, payload_mode: bool) -> str:
    names = _PAYLOAD_RULE_NAMES if payload_mode else _CLASSIC_RULE_NAMES
    rules = {name.replace("-", "_"): llm_utils.read_rule(skills_dir, name) for name in names}
    # website-scroll-management keeps its init code in references/ to stay under the line
    # cap; inline it (plus the Next.js component) for this one-shot generator.
    llm_utils.inline_scroll_link_refs(skills_dir, rules, include_nextjs=True)
    # Image prompt-authoring rules moved into plan_files.py — the plan is
    # the source of truth for the image manifest, so this script no longer
    # needs the heavyweight rules.
    prompt_name = "generate_system.payload.md" if payload_mode else "generate_system.md"
    return llm_utils.load_prompt(prompt_name, rules, prompts_dir=PROMPTS_DIR)


# Baked Payload field schemas the generator must conform to but never authors
# (reserved in plan_files.py). Component prop names and every seed.json field
# name must match these exactly. Without them in context the model guesses
# conventional Payload field names (e.g. a `link` group with `url`) that the
# cms-management validator then rejects, forcing a repair loop.
_SCHEMA_FILES = (
    "src/payload/blocks/index.ts",
    "src/payload/globals/SiteSettings.ts",
    "src/payload/collections/Pages.ts",
    # makeCollection injects every collectionMetaFields entry into generated
    # collections. Without this file in context the model re-declares one
    # (e.g. `author`) in generated.ts and Payload crashes at config sanitize.
    "src/payload/collectionMeta.ts",
)


def _read_schema_block(iter_dir: pathlib.Path) -> tuple[str, list[str]]:
    """Concatenate the iteration's baked Payload schema files so the LLM copies
    field names verbatim instead of recalling Payload conventions.

    Returns (block, missing). Missing files are skipped rather than fatal
    (sandbox-image drift); the caller surfaces ``missing`` as a warning so a
    dropped schema can't silently reintroduce the field-name-guessing loop.
    """
    sections: list[str] = []
    missing: list[str] = []
    for rel in _SCHEMA_FILES:
        try:
            text = (iter_dir / rel).read_text(encoding="utf-8")
        except OSError:
            missing.append(rel)
            continue
        sections.append(f"### {rel}\n```ts\n{text.strip()}\n```")
    block = "\n\n".join(sections) if sections else "(no Payload schema files found)"
    return block, missing


def _build_user_prompt(
    *,
    plan: dict,
    visual_spec: str,
    schema_block: str,
    user_requirements: str,
    build_requirements: list[str],
    user_uploaded_assets: str,
    logo_info: dict,
    iteration_id: str,
    image_base_url: str,
    payload_mode: bool,
) -> str:
    images_block = json.dumps(plan.get("images") or [], indent=2)
    plan_files_block = json.dumps({"files": plan.get("files") or []}, indent=2)
    return llm_utils.load_prompt(
        "generate_user.payload.md" if payload_mode else "generate_user.md",
        {
            "iteration_id": iteration_id,
            "image_base_url": image_base_url,
            "logo_block": json.dumps(logo_info or {}, indent=2),
            "user_requirements": user_requirements,
            "build_req_block": (
                "\n".join(f"- {r}" for r in build_requirements) if build_requirements else "(none)"
            ),
            "user_uploaded_assets": user_uploaded_assets or "(none)",
            "visual_spec": visual_spec,
            "schema_block": schema_block,
            "plan_block": plan_files_block,
            "images_block": images_block,
        },
        prompts_dir=PROMPTS_DIR,
    )


def _parse_response(response: str) -> dict[str, str]:
    """Parse the LLM's JSON response. Returns the files dict."""
    stripped = llm_utils.strip_markdown_fences(response).strip()
    payload = json.loads(stripped)
    files = payload.get("files")
    if not isinstance(files, dict) or not files:
        raise ValueError("response.files must be a non-empty object")
    for path, contents in files.items():
        if not isinstance(path, str) or not path:
            raise ValueError(f"file path must be a non-empty string: {path!r}")
        if path.startswith("/") or ".." in pathlib.PurePosixPath(path).parts:
            raise ValueError(f"unsafe file path: {path}")
        if not isinstance(contents, str):
            raise ValueError(f"file contents must be a string: {path}")
    return files


def _collect_block_types(node: object) -> set[str]:
    """Every `blockType` value anywhere in a parsed seed (layouts, nested blocks)."""
    found: set[str] = set()
    if isinstance(node, dict):
        block_type = node.get("blockType")
        if isinstance(block_type, str) and block_type:
            found.add(block_type)
        for value in node.values():
            found |= _collect_block_types(value)
    elif isinstance(node, list):
        for value in node:
            found |= _collect_block_types(value)
    return found


def _check_emission_gaps(plan: dict, iter_dir: pathlib.Path) -> list[dict]:
    """Blocking gaps between what the run promised and what is on disk.

    Two failure classes the fit validator cannot see, both of which ship a
    silently degraded site instead of an error:
    - a planned file missing (the model dropped it — most often a tail file
      in a long completion);
    - a block used in seed.json with no restyled component on disk (the plan
      never covered it and the generator didn't add it), so the template's
      unstyled placeholder renders for that section.

    Checks the iter dir, not the LLM response, so the gate holds across the
    scoped-repair pass and ``--skip-llm`` re-runs after manual repairs.

    Returns ``{path, kind, hint}`` errors in the cms_errors shape.
    """
    errors: list[dict] = []
    planned = {
        entry["path"]
        for entry in plan.get("files") or []
        if isinstance(entry, dict) and isinstance(entry.get("path"), str)
    }
    for path in sorted(planned):
        if not (iter_dir / path).is_file():
            errors.append(
                {
                    "path": path,
                    "kind": "missing-file",
                    "hint": f'planned file "{path}" was not emitted; '
                    "emit it in full per its plan purpose.",
                }
            )
    seed_path = iter_dir / "seed.json"
    if not seed_path.is_file():
        return errors  # absent seed is reported above (planned) or by the seed step
    try:
        seed = json.loads(seed_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        # Leave JSON diagnostics to the cms validator's seed-read error.
        return errors
    already_reported = {e["path"] for e in errors}
    for slug in sorted(_collect_block_types(seed)):
        component = f"src/components/blocks/{registry_inject.pascal(slug)}.tsx"
        if (iter_dir / component).is_file() or component in already_reported:
            continue
        errors.append(
            {
                "path": component,
                "kind": "missing-component",
                "hint": (
                    f'seed.json uses block "{slug}" but no restyled component exists, '
                    "so the template's unstyled placeholder would render for that "
                    f'section. Emit "{component}" restyled to the visual spec.'
                ),
            }
        )
    return errors


# Field declarations in collectionMeta.ts / generated.ts. `name: '<x>'` covers
# explicit field objects; `imageUrlField('<x>'` covers the field-factory form.
# Either quote style — a double-quoted `name: "author"` must not slip the gate.
_FIELD_NAME_RE = re.compile(r"""name:\s*['"](\w+)['"]""")
_IMAGE_URL_FIELD_RE = re.compile(r"""imageUrlField\(\s*['"](\w+)['"]""")

# Block slugs declared anywhere in a Payload blocks file (`slug: 'hero'`).
# Charclass matches _COLLECTION_SLUG_RES — the prompt asks for camelCase but a
# kebab/snake slug must still be seen (and injected via pascal) rather than
# silently skipped into an unrepairable block-triple failure.
_BLOCK_SLUG_RE = registry_inject.BLOCK_SLUG_RE  # one slug spelling, one owner


def _strip_comment_lines(text: str) -> str:
    """Drop `//` comments — full-line AND trailing — before scanning for
    slugs/fields. The template ships authoring examples inside comments (e.g.
    `slug: 'storyScroller'`), and the prompt's "do not redeclare meta fields"
    rule makes trailing comments that NAME those fields the natural thing for
    the model to write (`name: 'summary', // not name: 'author'`) — either
    must never scan as a real declaration and false-block a valid generation.

    One pass over the WHOLE text with quote state carried across newlines: a
    per-line scan treats a `//`-leading line INSIDE a multi-line template
    literal (a backtick defaultValue) as a comment, deleting it — possibly
    with the literal's closing backtick, desyncing every downstream scan."""
    out: list[str] = []
    i = 0
    quote: str | None = None
    while i < len(text):
        c = text[i]
        if quote:
            if c == "\\":
                out.append(text[i : i + 2])
                i += 2
                continue
            if c == quote:
                quote = None
            out.append(c)
        elif c in ("'", '"', "`"):
            quote = c
            out.append(c)
        elif c == "/" and text.startswith("//", i):
            nl = text.find("\n", i)
            i = len(text) if nl == -1 else nl
            continue
        elif c == "/" and text.startswith("/*", i):
            # Block comments too: `/* name: 'author' */` must not scan as a
            # declaration, and an apostrophe inside one must not open the
            # quote-state machine mid-comment.
            close = text.find("*/", i + 2)
            i = len(text) if close == -1 else close + 2
            continue
        else:
            out.append(c)
        i += 1
    return "".join(out)


def _read_block_slugs(path: pathlib.Path) -> set[str]:
    try:
        text = _strip_comment_lines(path.read_text(encoding="utf-8"))
    except OSError:
        return set()
    return set(_BLOCK_SLUG_RE.findall(text))


def _check_block_slug_collisions(iter_dir: pathlib.Path) -> list[dict]:
    """Blocking check: a custom block in generated.ts must not reuse a library
    block's slug.

    `layoutBlocks` spreads `generatedBlocks` after the library, so a colliding
    slug would shadow/duplicate a baked block — both render the same `blockType`
    but the seed and the renderer disagree on which fields/component apply. Slugs
    are exact tokens in a constrained baked shape, so a regex scan is reliable
    here (mirrors `_check_collection_field_collisions`).

    Returns ``{path, kind, hint}`` errors in the cms_errors shape.
    """
    generated_path = iter_dir / "src" / "payload" / "blocks" / "generated.ts"
    if not generated_path.is_file():
        return []
    library = _read_block_slugs(iter_dir / "src" / "payload" / "blocks" / "index.ts")
    custom = _read_block_slugs(generated_path)
    # Compare on pascal(slug), not the raw string: the component file and the
    # registry injection both key on pascal(), so 'feature-grid' collides with
    # library 'featureGrid' — a string-exact check passes it here only for the
    # injector to emit a duplicate `import { FeatureGrid } …` and break tsc
    # with a redeclare error instead of this gate's clear "rename" hint.
    library_components = {registry_inject.pascal(s): s for s in library}
    collisions: list[str] = []
    seen_custom: dict[str, str] = {}
    for slug in sorted(custom):
        component = registry_inject.pascal(slug)
        owner = library_components.get(component)
        if owner is not None:
            collisions.append(
                slug if slug == owner else f"{slug} (component-collides with {owner!r})"
            )
        elif component in seen_custom:
            # Two custom slugs in ONE generation pascal()ing to the same
            # component would emit duplicate identical imports (tsc TS2300 a
            # QA round later) — same guard the registry CLI already has.
            collisions.append(f"{slug} (component-collides with {seen_custom[component]!r})")
        else:
            seen_custom[component] = slug
    if not collisions:
        return []
    return [
        {
            "path": "src/payload/blocks/generated.ts",
            "kind": "duplicate-block-slug",
            "hint": (
                f"custom block slugs {collisions} collide with library blocks "
                "(src/payload/blocks/index.ts) — same slug or same PascalCase "
                "component name. Rename each custom block to a unique slug — a "
                "library block already owns that blockType/component."
            ),
        }
    ]


def _inject_generated_block_registry(iter_dir: pathlib.Path) -> tuple[list[str], list[str]]:
    """Write the custom blocks' RenderBlocks entries between the sentinel markers.

    The LLM authors the schema (blocks/generated.ts) and component
    (components/blocks/<Pascal>.tsx); this writes the literal `blockComponents`
    map entries deterministically so the renderer can render them. Idempotent —
    safe across the scoped-repair pass and `--skip-llm` re-runs. Component name
    and import path follow the `<Pascal(slug)>` convention the prompt requires.

    Returns ``(injected_slugs, warnings)``. A missing/empty generated.ts is a
    no-op; an injection failure is a warning (the block-triple gate then surfaces
    the unregistered block).
    """
    generated_path = iter_dir / "src" / "payload" / "blocks" / "generated.ts"
    slugs = sorted(_read_block_slugs(generated_path))
    if not slugs:
        return [], []
    blocks_dir = iter_dir / "src" / "components" / "blocks"
    render_blocks = blocks_dir / "RenderBlocks.tsx"
    if not render_blocks.is_file():
        return [], ["RenderBlocks.tsx missing; cannot inject custom block registry"]
    # Register only slugs whose component file exists (same guard as the item
    # side): injecting an import for a missing <Pascal(slug)>.tsx would break
    # typecheck with an unresolved import instead of the block-triple gate's
    # repairable "emit the component" error.
    warnings: list[str] = []
    entries: list[dict] = []
    for slug in slugs:
        if (blocks_dir / f"{registry_inject.pascal(slug)}.tsx").is_file():
            entries.append({"slug": slug})
        else:
            warnings.append(
                f"custom block '{slug}' declared in blocks/generated.ts has no "
                f"components/blocks/{registry_inject.pascal(slug)}.tsx — not registered; "
                "the block-triple gate will require the component"
            )
    if not entries:
        return [], warnings
    try:
        injected = registry_inject.inject_block_registry(render_blocks, entries)
    except (OSError, registry_inject.RegistryInjectError) as e:
        return [], warnings + [f"custom block registry injection failed: {type(e).__name__}: {e}"]
    return injected, warnings


# Collection slugs in generated.ts: `makeCollection('<slug>'` (factory form) or a
# bare `slug: '<slug>'`.
_COLLECTION_SLUG_RES = (
    re.compile(r"""makeCollection\(\s*['"]([a-zA-Z0-9_-]+)['"]"""),
    registry_inject.BLOCK_SLUG_RE,
)


def _read_collection_slugs(path: pathlib.Path) -> set[str]:
    try:
        text = _strip_comment_lines(path.read_text(encoding="utf-8"))
    except OSError:
        return set()
    slugs: set[str] = set()
    for regex in _COLLECTION_SLUG_RES:
        slugs.update(regex.findall(text))
    return slugs


def _inject_generated_item_registry(iter_dir: pathlib.Path) -> tuple[list[str], list[str]]:
    """Write per-collection item-layout entries into RenderItem.tsx.

    A collection gets a custom item layout when the generator authored
    ``src/components/collections/<Pascal(slug)>Layout.tsx``; the existence of that
    file (named by the required convention) is the trigger. This writes the
    literal `itemComponents` map entries deterministically so the catch-all route
    dispatches to the layout. Collections without a layout fall back to
    DefaultItemLayout and are not registered. Idempotent.

    Returns ``(injected_collections, warnings)``.
    """
    generated_path = iter_dir / "src" / "payload" / "collections" / "generated.ts"
    slugs = sorted(_read_collection_slugs(generated_path))
    if not slugs:
        return [], []
    collections_dir = iter_dir / "src" / "components" / "collections"
    render_item = collections_dir / "RenderItem.tsx"
    if not render_item.is_file():
        return [], []  # template without the item registry (older sandbox image)
    entries: list[dict] = []
    for slug in slugs:
        component = f"{registry_inject.pascal(slug)}Layout"
        if (collections_dir / f"{component}.tsx").is_file():
            entries.append({"collection": slug, "component": component})
    if not entries:
        return [], []
    try:
        injected = registry_inject.inject_item_registry(render_item, entries)
    except (OSError, registry_inject.RegistryInjectError) as e:
        return [], [f"custom item registry injection failed: {type(e).__name__}: {e}"]
    return injected, []


# Arrays whose elements flatten into the enclosing namespace when the wrapper
# is unnamed: `fields:` (row/collapsible/unnamed group) and `tabs:` (unnamed
# tabs — each tab object is itself an unnamed wrapper around its fields).
_FIELDS_ARRAY_RE = re.compile(r"\b(?:fields|tabs)\s*:\s*\[")


def _matching(src: str, i: int) -> int:
    """Index just past the close of the bracket/brace span opening at ``src[i]``,
    honouring string/template literals (a bracket inside an author-controlled
    string must not desync the scan feeding this blocking gate)."""
    open_ch = src[i]
    close_ch = "]" if open_ch == "[" else "}"
    depth = 0
    quote: str | None = None
    while i < len(src):
        c = src[i]
        if quote:
            if c == "\\":
                i += 1
            elif c == quote:
                quote = None
        elif c in ("'", '"', "`"):
            quote = c
        elif c == open_ch:
            depth += 1
        elif c == close_ch:
            depth -= 1
            if depth == 0:
                return i + 1
        i += 1
    return len(src)


def _object_data_names(obj_src: str) -> set[str]:
    """Data-level names one field OBJECT contributes to its parent namespace.

    A NAMED object (plain field, ``array``, named ``group``, ``blocks``) owns
    its own namespace — it contributes exactly its name, and its subfields can
    legally reuse meta names. An UNNAMED object (``row``/``collapsible``/
    unnamed ``group``) is presentational: Payload flattens its ``fields`` into
    the parent data namespace (``seed-payload.ts`` encodes the same rule), so
    its nested names ARE parent-level and must recurse up."""
    name: str | None = None
    nested: list[str] = []
    i = 0
    quote: str | None = None
    while i < len(obj_src):
        c = obj_src[i]
        if quote:
            if c == "\\":
                i += 1
            elif c == quote:
                quote = None
        elif c in ("'", '"', "`"):
            quote = c
        elif obj_src.startswith("name", i) and (
            nm := re.match(r"""name\s*:\s*['"](\w+)['"]""", obj_src[i:])
        ):
            name = nm.group(1)
            i += nm.end() - 1
        elif fm := _FIELDS_ARRAY_RE.match(obj_src, i):
            end = _matching(obj_src, fm.end() - 1)
            nested.append(obj_src[fm.end() : end - 1])
            i = end - 1
        elif c in "[{":
            i = _matching(obj_src, i) - 1  # skip admin:{...}, defaultValue arrays, …
        i += 1
    if name is not None:
        return {name}
    out: set[str] = set()
    for seg in nested:
        out |= _field_array_data_names(seg)
    return out


def _field_array_data_names(array_src: str) -> set[str]:
    """Data-level names contributed by one fields-array BODY: each object's
    contribution (see ``_object_data_names``) plus bare ``imageUrlField('x')``
    factory calls sitting directly in the array."""
    names: set[str] = set()
    i = 0
    quote: str | None = None
    while i < len(array_src):
        c = array_src[i]
        if quote:
            if c == "\\":
                i += 1
            elif c == quote:
                quote = None
        elif c in ("'", '"', "`"):
            quote = c
        elif array_src.startswith("imageUrlField", i):
            fm = re.match(r"""imageUrlField\(\s*['"](\w+)['"]""", array_src[i:])
            if fm:
                names.add(fm.group(1))
                i += fm.end() - 1
        elif c == "{":
            end = _matching(array_src, i)
            names |= _object_data_names(array_src[i + 1 : end - 1])
            i = end - 1
        i += 1
    return names


def _top_level_field_names(src: str) -> set[str]:
    """Field names declared at each collection's DATA level.

    ``makeCollection`` prepends the meta fields at the collection's top level,
    so a collision is a re-declaration in the same DATA namespace: a top-level
    field, OR a field inside a presentational wrapper (``row``/``collapsible``/
    unnamed ``group``/unnamed ``tabs`` — Payload flattens those into the
    parent). A NAMED object's subfields (``array`` items, named ``group``) are
    their own namespace and never collide (a nested ``title`` on feature cards
    is fine).

    Walks the file's TOP-LEVEL object literals (helper consts, each
    ``makeCollection`` config object) through ``_object_data_names`` so every
    object is judged WITH its named/unnamed context — entering at a bare
    ``fields: [`` would strip a helper const's enclosing named object and read
    its subfields as collection-level names (a false block on the documented
    helper-const authoring style). A helper ARRAY const's elements are named
    field objects contributing their own names, which also covers fields
    reaching collections via ``...spread``.
    """
    names: set[str] = set()
    i = 0
    quote: str | None = None
    while i < len(src):
        c = src[i]
        if quote:
            if c == "\\":
                i += 1
            elif c == quote:
                quote = None
        elif c in ("'", '"', "`"):
            quote = c
        elif c == "{":
            end = _matching(src, i)
            names |= _object_data_names(src[i + 1 : end - 1])
            i = end - 1
        elif src.startswith("imageUrlField", i):
            # A bare factory call OUTSIDE any object — a top-level helper
            # ARRAY const (`const mediaFields = [imageUrlField('x'), …]`)
            # spread into a collection contributes its field at the data
            # level just like the in-array spelling.
            fm = re.match(r"""imageUrlField\(\s*['"](\w+)['"]""", src[i:])
            if fm:
                names.add(fm.group(1))
                i += fm.end() - 1
        i += 1
    return names


def _check_collection_field_collisions(iter_dir: pathlib.Path) -> list[dict]:
    """Blocking check: generated.ts must not re-declare an injected meta field.

    ``makeCollection`` prepends every ``collectionMetaFields`` entry to a
    generated collection's fields. A re-declared field (e.g. ``author``)
    passes typecheck and the parse step, then crashes Payload's config
    sanitize at boot — the most expensive possible failure point (caught at
    the seed step or, worse, the dev server). Both files have a constrained
    baked shape, so a depth-scoped field-name scan is reliable here.

    Returns ``{path, kind, hint}`` errors in the cms_errors shape.
    """
    generated_path = iter_dir / "src" / "payload" / "collections" / "generated.ts"
    if not generated_path.is_file():
        return []
    meta_path = iter_dir / "src" / "payload" / "collectionMeta.ts"
    try:
        generated_text = generated_path.read_text(encoding="utf-8")
        meta_text = meta_path.read_text(encoding="utf-8")
    except OSError:
        return []
    injected = set(_FIELD_NAME_RE.findall(meta_text)) | set(_IMAGE_URL_FIELD_RE.findall(meta_text))
    declared = _top_level_field_names(_strip_comment_lines(generated_text))
    collisions = sorted(declared & injected)
    if not collisions:
        return []
    return [
        {
            "path": "src/payload/collections/generated.ts",
            "kind": "duplicate-field",
            "hint": (
                f"fields {collisions} are already injected by makeCollection "
                "(collectionMeta.ts) and re-declaring them crashes Payload at config "
                "load. Remove them from the fields arrays — seed items can still set "
                "these fields."
            ),
        }
    ]


# Module specifiers in emitted source: `import … from '…'`, side-effect
# `import '…'`, `export … from '…'`, and dynamic `import('…')`/`require('…')`.
_IMPORT_SPEC_RES = (
    re.compile(r"""(?:^|\n)\s*(?:import|export)\s[^'"]*?from\s+['"]([^'"]+)['"]"""),
    re.compile(r"""(?:^|\n)\s*import\s+['"]([^'"]+)['"]"""),
    re.compile(r"""(?:import|require)\(\s*['"]([^'"]+)['"]\s*\)"""),
)


# Node builtins importable WITHOUT the `node:` prefix — tsc resolves these via
# @types/node, so blocking them here would make this gate stricter than the
# typecheck it fronts (`import fs from 'fs'` is valid).
_NODE_BUILTINS = frozenset(
    {
        "assert", "async_hooks", "buffer", "child_process", "cluster", "console",
        "constants", "crypto", "dgram", "dns", "domain", "events", "fs", "http",
        "http2", "https", "inspector", "module", "net", "os", "path", "perf_hooks",
        "process", "punycode", "querystring", "readline", "repl", "stream",
        "string_decoder", "timers", "tls", "tty", "url", "util", "v8", "vm",
        "worker_threads", "zlib",
    }
)  # fmt: skip


def _bare_package(spec: str) -> str | None:
    """Package name for a bare module spec; None for relative/alias/builtin specs.

    `@/*` and `@payload-config` are the template's tsconfig path aliases.
    """
    if spec.startswith((".", "/", "node:", "@/")) or spec == "@payload-config":
        return None
    parts = spec.split("/")
    if spec.startswith("@"):
        return "/".join(parts[:2]) if len(parts) >= 2 else spec
    if parts[0] in _NODE_BUILTINS:
        return None  # `fs`, `fs/promises`, `path`, … — builtins, not packages
    return parts[0]


def _check_unresolvable_imports(iter_dir: pathlib.Path) -> list[dict]:
    """Blocking check: every bare package import must be an installed dependency.

    The generator cannot install packages (`package.json` is a template
    invariant), so a hallucinated dependency import passes the emission and
    fit gates, then fails `pnpm typecheck` a full QA round later — the
    cheapest-to-prevent, most-expensive-to-recover failure in the dp11966
    timing analysis (`embla-carousel-react` in every iteration's slider).
    A module-spec scan against package.json catches it here, pre-install,
    with a file-scoped repair hint.

    Returns ``{path, kind, hint}`` errors in the cms_errors shape.
    """
    try:
        manifest = json.loads((iter_dir / "package.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        # No manifest to check against (template drift) — typecheck still covers it.
        return []
    installed = set(manifest.get("dependencies") or {}) | set(manifest.get("devDependencies") or {})
    src_dir = iter_dir / "src"
    if not src_dir.is_dir():
        return []
    errors: list[dict] = []
    for path in sorted(src_dir.rglob("*.ts*")):
        if path.suffix not in (".ts", ".tsx"):
            continue
        try:
            text = _strip_comment_lines(path.read_text(encoding="utf-8"))
        except OSError:
            continue
        specs: set[str] = set()
        for regex in _IMPORT_SPEC_RES:
            specs.update(regex.findall(text))
        missing = sorted(
            {pkg for spec in specs if (pkg := _bare_package(spec)) and pkg not in installed}
        )
        if missing:
            errors.append(
                {
                    "path": str(path.relative_to(iter_dir)),
                    "kind": "unresolvable-import",
                    "hint": (
                        f"imports {missing}, which are not installed dependencies — "
                        "package.json is read-only and nothing can be installed, so "
                        "typecheck fails. Re-emit the file implementing the same UI "
                        "with installed dependencies only (React + Tailwind + inline "
                        "SVG; see the carousel & slider rules)."
                    ),
                }
            )
    return errors


def _blocking_gate_errors(plan: dict, iter_dir: pathlib.Path) -> list[dict]:
    """All pre-install blocking errors, in the cms_errors shape."""
    return (
        _check_emission_gaps(plan, iter_dir)
        + _check_collection_field_collisions(iter_dir)
        + _check_block_slug_collisions(iter_dir)
        + _check_unresolvable_imports(iter_dir)
    )


def _repair_gate_errors(
    *,
    gate_errors: list[dict],
    iter_dir: pathlib.Path,
    system_prompt: str,
    user_prompt: str,
    api_key: str,
    iter_name: str,
    warnings: list[str],
) -> list[str]:
    """One scoped LLM call emitting only the gate's missing/broken files.

    A gate failure used to bounce back to the driving agent as "re-run
    generate_files.py" — a full multi-minute regeneration (plus a fresh image
    dispatch) to recover a handful of files, with the regenerated set free to
    fail the gate a different way. Everything already on disk is valid state,
    so ask for just the gap: same system prompt and user-prompt prefix
    (provider prefix caching holds), with a repair section appended.

    Writes the repaired files and returns their paths; the caller re-checks
    the gate. A failed call returns [] — the caller's gate re-check then
    fails the run exactly as before.
    """
    requested = {e["path"] for e in gate_errors}
    seed_section = ""
    seed_path = iter_dir / "seed.json"
    if "seed.json" not in requested and seed_path.is_file():
        try:
            seed_text = seed_path.read_text(encoding="utf-8")
        except OSError:
            seed_text = ""
        if seed_text:
            seed_section = (
                "\n\nThe emitted `seed.json` (final — each component's prop names must "
                "match the fields its block uses here):\n```json\n" + seed_text + "\n```"
            )
    repair_prompt = (
        user_prompt
        + "\n\n# Repair\n\nA previous response emitted every other planned file; those are "
        "written and final. Emit ONLY the files listed below — same output contract (a JSON "
        "object with a `files` key mapping each path to its complete contents), no other "
        "paths. Each entry's `hint` says what was wrong.\n\n```json\n"
        + json.dumps(gate_errors, indent=2)
        + "\n```"
        + seed_section
    )
    try:
        files = llm_utils.call_llm_parsed(
            parse=_parse_response,
            warnings=warnings,
            url=llm_utils.proxy_url(f"nextjs_generate_repair.{iter_name}"),
            model=MODEL,
            system_prompt=system_prompt,
            user_prompt=repair_prompt,
            api_key=api_key,
            temperature=TEMPERATURE,
            reasoning_effort=REASONING_EFFORT,
            timeout=TIMEOUT_SECS,
        )
    except (
        urllib.error.URLError,
        TimeoutError,
        RuntimeError,
        ValueError,
        json.JSONDecodeError,
    ) as e:
        warnings.append(f"scoped repair call failed: {type(e).__name__}: {e}")
        return []
    extras = sorted(set(files) - requested)
    if extras:
        warnings.append(f"scoped repair emitted unrequested files (dropped): {extras}")
    files = {path: contents for path, contents in files.items() if path in requested}
    if not files:
        warnings.append("scoped repair emitted none of the requested files")
        return []
    return _write_files(iter_dir, files)


def _write_files(iter_dir: pathlib.Path, files: dict[str, str]) -> list[str]:
    written: list[str] = []
    for rel_path, contents in files.items():
        target = iter_dir / rel_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(contents, encoding="utf-8")
        written.append(rel_path)
    return written


def _read_images_manifest(iter_dir: pathlib.Path) -> list[dict]:
    path = iter_dir / "images.json"
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return data if isinstance(data, list) else []


def _post_image_batch(
    *,
    backend_url: str,
    token: str,
    application_id: str,
    folder: str,
    batch: list[dict],
) -> dict:
    body = json.dumps(
        {"application_id": application_id, "folder": folder, "requests": batch}
    ).encode("utf-8")
    req = urllib.request.Request(
        f"{backend_url.rstrip('/')}{IMAGE_API_PATH}",
        data=body,
        method="POST",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=IMAGE_REQUEST_TIMEOUT_SECS) as resp:  # noqa: S310
        return json.loads(resp.read().decode("utf-8"))


def _image_exists(url: str) -> bool:
    """True when the image URL is live on the CDN."""
    req = urllib.request.Request(url, method="HEAD")  # noqa: S310
    try:
        with urllib.request.urlopen(req, timeout=IMAGE_PROBE_TIMEOUT_SECS) as resp:  # noqa: S310
            return 200 <= resp.status < 300
    except (urllib.error.URLError, TimeoutError):
        return False


def _reconcile_failed_images(
    *, plan_images: list[dict], iter_name: str, summary: dict
) -> tuple[dict, list[str]]:
    """Re-derive the image outcome from CDN ground truth, retrying only real misses.

    A batch-level transport failure makes every image in the batch *look*
    failed even when the backend kept generating and uploading after the
    client lost the response — e.g. one slow image holding the batch open
    past a gateway timeout turns into a single 504 and a "10/10 failed"
    verdict, which forces a pointless full regeneration run. Each planned
    image has a deterministic URL (``plan.json``'s ``images[].url``), so
    probe those instead of trusting the transport, then re-request only the
    images that are genuinely absent and probe once more.

    Returns ``(corrected_summary, notes)``; ``notes`` are warning breadcrumbs.
    """
    probeable = [img for img in plan_images if img.get("slug") and img.get("url")]
    if not probeable:
        return summary, []
    notes: list[str] = []
    errors = [str(e) for e in summary.get("errors") or []]
    missing = [img for img in probeable if not _image_exists(img["url"])]
    verified = len(probeable) - len(missing)
    if verified > summary["succeeded"]:
        notes.append(
            f"image batch reported {summary['failed']}/{summary['total']} failed, but "
            f"{verified}/{len(probeable)} image URLs are live on the CDN — treating the "
            "batch error as transport-level, not generation failure"
        )
    if missing:
        backend_url = os.environ.get("BACKEND_API_URL")
        token = os.environ.get("INTERNAL_API_TOKEN")
        application_id = os.environ.get("APPLICATION_ID")
        if not (backend_url and token and application_id):
            notes.append("platform credentials missing — cannot retry missing images")
        else:
            notes.append(
                f"retrying {len(missing)} missing image(s): {[img['slug'] for img in missing]}"
            )
            for i in range(0, len(missing), IMAGE_BATCH_SIZE):
                batch = [
                    {
                        "prompt": img["prompt"],
                        "aspect_ratio": img.get("aspect_ratio", "16:9"),
                        "is_logo": img.get("is_logo", False),
                        "name": img["slug"],
                    }
                    for img in missing[i : i + IMAGE_BATCH_SIZE]
                ]
                try:
                    _post_image_batch(
                        backend_url=backend_url,
                        token=token,
                        application_id=application_id,
                        folder=iter_name,
                        batch=batch,
                    )
                except (urllib.error.URLError, TimeoutError, ValueError) as e:
                    errors.append(f"image retry batch: {type(e).__name__}: {e}")
            missing = [img for img in missing if not _image_exists(img["url"])]
    if missing:
        errors.append(f"images still missing after retry: {[img['slug'] for img in missing]}")
    corrected = {
        "total": len(probeable),
        "succeeded": len(probeable) - len(missing),
        "failed": len(missing),
        "errors": errors,
    }
    return corrected, notes


def _dispatch_image_generation(
    *, iter_dir: pathlib.Path, iter_name: str, plan_images: list[dict]
) -> concurrent.futures.Future[dict] | None:
    """Fire image generation off `<iter>/images.json` in the background.

    Every planned image has a deterministic CDN URL (``plan.json``'s
    ``images[].url``), so the background thread probes those first and only
    requests images that are genuinely absent. On the first run nothing is
    live and everything is requested; on re-runs (scoped repair, ``--skip-llm``
    after manual fixes) this stops the whole image set from being regenerated
    — pure spend that also churns already-referenced art.

    Returns a Future yielding an aggregate ``{total, succeeded, failed, errors}``
    dict, or ``None`` when there are no images to generate or the sandbox env
    is missing the required platform credentials (in which case image dispatch
    is the agent's responsibility — same as the old Phase 2 contract).
    """
    backend_url = os.environ.get("BACKEND_API_URL")
    token = os.environ.get("INTERNAL_API_TOKEN")
    application_id = os.environ.get("APPLICATION_ID")
    if not (backend_url and token and application_id):
        return None
    manifest = _read_images_manifest(iter_dir)
    if not manifest:
        return None
    url_by_slug = {
        img["slug"]: img["url"] for img in plan_images if img.get("slug") and img.get("url")
    }

    def _run_all() -> dict:
        slugs = [img["slug"] for img in manifest if img["slug"] in url_by_slug]
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=min(max(len(slugs), 1), IMAGE_MAX_PARALLEL_BATCHES * 2)
        ) as probe_pool:
            live = {
                slug
                for slug, exists in zip(
                    slugs, probe_pool.map(lambda s: _image_exists(url_by_slug[s]), slugs)
                )
                if exists
            }
        pending = [img for img in manifest if img["slug"] not in live]
        agg = {"total": len(manifest), "succeeded": len(live), "failed": 0, "errors": []}
        if not pending:
            return agg
        batches = [
            [
                {
                    "prompt": img["prompt"],
                    "aspect_ratio": img.get("aspect_ratio", "16:9"),
                    "is_logo": img.get("is_logo", False),
                    "name": img["slug"],
                }
                for img in pending[i : i + IMAGE_BATCH_SIZE]
            ]
            for i in range(0, len(pending), IMAGE_BATCH_SIZE)
        ]
        with concurrent.futures.ThreadPoolExecutor(
            max_workers=min(len(batches), IMAGE_MAX_PARALLEL_BATCHES)
        ) as pool:
            futures = {
                pool.submit(
                    _post_image_batch,
                    backend_url=backend_url,
                    token=token,
                    application_id=application_id,
                    folder=iter_name,
                    batch=batch,
                ): len(batch)
                for batch in batches
            }
            for fut in concurrent.futures.as_completed(futures):
                batch_size = futures[fut]
                try:
                    result = fut.result()
                except (urllib.error.URLError, TimeoutError, ValueError) as e:
                    agg["failed"] += batch_size
                    agg["errors"].append(f"{type(e).__name__}: {e}")
                    continue
                agg["succeeded"] += int(result.get("total_succeeded") or 0)
                agg["failed"] += int(result.get("total_failed") or 0)
                for err in result.get("errors") or []:
                    agg["errors"].append(str(err))
        return agg

    runner = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    fut = runner.submit(_run_all)
    runner.shutdown(wait=False)
    return fut


def _install_iter_deps(iter_dir: pathlib.Path) -> tuple[bool, str]:
    """Run `pnpm install` inside the iter dir so `validate_files.py`'s
    typecheck has node_modules to resolve.

    --ignore-workspace because $EFS_APP_PATH ships a pnpm-workspace.yaml at
    the root; without this flag pnpm hoists the iter's node_modules up to
    the workspace root and the iter dir ends up with nothing. Discovered
    the hard way when validate_files.py kept failing with "Cannot find
    module 'next'" and Sonnet had to recover with the same flag.

    --prefer-offline reuses pnpm's content-addressable store (already
    populated for the template's deps), so this is seconds even on a cold
    iter dir.

    Returns (success, tail_of_combined_output).
    """
    try:
        proc = subprocess.run(  # noqa: S603 - args are static
            ["pnpm", "install", "--ignore-workspace", "--prefer-offline"],
            cwd=str(iter_dir),
            capture_output=True,
            text=True,
            check=False,
            timeout=PNPM_INSTALL_TIMEOUT_SECS,
        )
    except subprocess.TimeoutExpired as e:
        return False, f"pnpm install timed out after {PNPM_INSTALL_TIMEOUT_SECS}s: {e}"
    if proc.returncode == 0:
        return True, ""
    tail = "\n".join(((proc.stdout or "") + (proc.stderr or "")).strip().splitlines()[-20:])
    return False, tail


def _generate_types(iter_dir: pathlib.Path) -> tuple[bool, str]:
    """Regenerate Payload TS types from the iter's config so any content
    collections the generator authored into `payload/collections/generated.ts`
    are typed before `validate_files.py` runs `pnpm typecheck`.

    Config-only, no DB: `payload generate:types` loads the config, whose runtime
    env vars all have `|| ''` fallbacks, so no Postgres pool is opened. Runs
    unconditionally after install — a near-no-op when no collections were
    authored. Non-blocking: a failure is surfaced as a warning and the
    downstream typecheck/QA catches any real breakage.

    Returns (success, tail_of_combined_output).
    """
    try:
        proc = subprocess.run(  # noqa: S603 - args are static
            ["pnpm", "generate:types"],
            cwd=str(iter_dir),
            capture_output=True,
            text=True,
            check=False,
            timeout=GENERATE_TYPES_TIMEOUT_SECS,
        )
    except subprocess.TimeoutExpired as e:
        return False, f"generate:types timed out after {GENERATE_TYPES_TIMEOUT_SECS}s: {e}"
    if proc.returncode == 0:
        return True, ""
    tail = "\n".join(((proc.stdout or "") + (proc.stderr or "")).strip().splitlines()[-20:])
    return False, tail


def _read_backend_env(efs_path: pathlib.Path) -> dict[str, str]:
    """Parse $EFS_APP_PATH/backend/.env (the synced source of truth) for the
    Payload runtime vars. Returns {} if absent."""
    out: dict[str, str] = {}
    env_file = efs_path / "backend" / ".env"
    try:
        text = env_file.read_text(encoding="utf-8")
    except OSError:
        return out
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        out[key.strip()] = value.strip()
    return out


def _iter_schema_name(iter_name: str, validate: bool = False) -> str:
    """Postgres schema for one iter's Payload content (`payload_<iter>`).

    ``validate=True`` returns the isolated scratch schema the semantic
    validator targets instead of the live one. Keep the live-name grammar in
    sync with ``iter_schema_name`` in ``backend/app/utils/payload_secrets.py``
    — this script runs standalone in the sandbox and cannot import it.
    """
    return f"payload_{iter_name}_validate" if validate else f"payload_{iter_name}"


def _seed_iter(iter_dir: pathlib.Path, iter_name: str, efs_path: pathlib.Path) -> tuple[bool, str]:
    """Seed the iter's per-iter Payload schema from its generated seed.json.

    Runs the baked `scripts/seed-payload.ts` (idempotent upsert-by-slug via the
    Payload Local API) so the dev server renders DB-backed content and QA scans
    the real site. Runs after deps install, before QA. A failure here is
    blocking — JSX would render against an empty database.

    Returns (success, tail_of_output).
    """
    seed_file = iter_dir / "seed.json"
    if not seed_file.is_file():
        return False, (
            "seed.json missing — the generation step must emit "
            f"iterations/{iter_name}/seed.json (SiteSettings + one Pages doc per route)."
        )
    backend_env = _read_backend_env(efs_path)
    db_url = backend_env.get("APP_DATABASE_URL")
    if not db_url:
        return False, (
            "APP_DATABASE_URL missing from backend/.env — the per-app Neon DB is not "
            "provisioned/synced yet, so Payload cannot be seeded."
        )
    env = dict(os.environ)
    env["APP_DATABASE_URL"] = db_url
    env["PAYLOAD_SECRET"] = backend_env.get("PAYLOAD_SECRET", "")
    env["PAYLOAD_SCHEMA"] = _iter_schema_name(iter_name)
    env["SEED_FILE"] = "seed.json"
    try:
        proc = subprocess.run(  # noqa: S603 - args are static
            ["pnpm", "seed"],
            cwd=str(iter_dir),
            capture_output=True,
            text=True,
            check=False,
            timeout=SEED_TIMEOUT_SECS,
            env=env,
        )
    except subprocess.TimeoutExpired as e:
        return False, f"seed timed out after {SEED_TIMEOUT_SECS}s: {e}"
    if proc.returncode == 0:
        return True, ""
    tail = "\n".join(((proc.stdout or "") + (proc.stderr or "")).strip().splitlines()[-20:])
    return False, tail


def _run_json_line_tool(
    cmd: list[str],
    cwd: pathlib.Path,
    *,
    tool_label: str,
    env: dict[str, str] | None = None,
) -> tuple[dict | None, str]:
    """Run a generation-time gate CLI that prints ONE line of JSON on stdout.

    The shared transport for :func:`_validate_cms` and
    :func:`_extract_kite_manifest`: run ``cmd`` under ``VALIDATE_TIMEOUT_SECS``,
    take the last non-empty stdout line, and ``json.loads`` it. Returns
    ``(result, "")`` on a clean parse, or ``(None, skip_detail)`` when the tool
    did not run or emitted unparseable output — both non-blocking tooling skips
    the caller surfaces as detail. ``tool_label`` names the tool in those skip
    messages (e.g. ``"cms validator"``). The caller owns the domain logic:
    which ``kind`` values are tooling-skips vs real gate errors, and any
    warning assembly.
    """
    try:
        proc = subprocess.run(  # noqa: S603 - args are static, built by callers
            cmd,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            check=False,
            timeout=VALIDATE_TIMEOUT_SECS,
            env=env,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        return None, f"{tool_label} did not run ({type(e).__name__}: {e}); skipped"
    line = next((ln for ln in reversed((proc.stdout or "").splitlines()) if ln.strip()), "")
    try:
        result = json.loads(line)
    except (ValueError, json.JSONDecodeError):
        result = None
    # A last line that parses to null/a list/a scalar is just as unusable as
    # unparseable output — without this check a literal "null" line would return
    # (None, "") and the caller would skip the BLOCKING gate silently, with an
    # empty detail leaving no trace in warnings.
    if not isinstance(result, dict):
        tail = "\n".join(((proc.stdout or "") + (proc.stderr or "")).strip().splitlines()[-15:])
        return None, f"{tool_label} output unparseable; skipped. Tail:\n{tail}"
    return result, ""


def _validate_cms(
    iter_dir: pathlib.Path, iter_name: str, efs_path: pathlib.Path, skills_dir: pathlib.Path
) -> tuple[bool, list[dict], str]:
    """Prove the generated seed.json fits the Payload admin before seeding.

    Runs the `cms-management` skill's validator (the three fit invariants) with the
    per-app DB env so the semantic Local-API layer runs too. A fit error is
    blocking with field-level repair hints — turning "the seed ran" into "the
    seed provably fits". A tooling failure (validator missing/crashed) is a
    non-blocking warning, since the structural gate is the contract, not the CLI.

    The semantic layer validates each doc via a rolled-back Local-API write. To
    keep that safe to re-run, it targets an isolated scratch schema
    (`payload_<iter>_validate`), never the live `payload_<iter>` the seed commits
    to — otherwise a re-run would hit a unique-slug conflict against the already
    seeded `home` doc and false-block a valid generation. The validator drops
    the scratch schema when it finishes, so re-runs leave no residue.

    Returns (ok, errors, detail). `errors` is the validator's field-level list.
    """
    validator = skills_dir / "cms-management" / "scripts" / "validate_cms.mjs"
    if not validator.is_file():
        return True, [], f"cms-management validator not found at {validator}; skipped"
    backend_env = _read_backend_env(efs_path)
    env = dict(os.environ)
    db_url = backend_env.get("APP_DATABASE_URL")
    if db_url:
        env["APP_DATABASE_URL"] = db_url
        env["PAYLOAD_SECRET"] = backend_env.get("PAYLOAD_SECRET", "")
        env["PAYLOAD_SCHEMA"] = _iter_schema_name(iter_name, validate=True)
    result, skip_detail = _run_json_line_tool(
        ["pnpm", "exec", "tsx", str(validator), "seed.json"],
        iter_dir,
        tool_label="cms validator",
        env=env,
    )
    if result is None:
        return True, [], skip_detail
    errors = result.get("errors") or []
    # The validator's top-level catch reports its own unexpected failures as
    # `kind: "crash"` in well-formed JSON. That is a tooling failure, not a
    # seed-fit error — skip rather than false-block the generation. A
    # `config-load` error stays blocking: the config import evaluates the
    # generated `generated.ts`, so a load failure means broken generated code.
    if not result.get("ok") and errors and all(e.get("kind") == "crash" for e in errors):
        hints = "; ".join(str(e.get("hint") or "") for e in errors)
        return True, [], f"cms validator crashed ({hints}); skipped"
    return bool(result.get("ok")), errors, ""


def _extract_kite_manifest(iter_dir: pathlib.Path) -> tuple[bool, list[dict], str]:
    """Derive the analytics manifest from the authored ``data-kite-*`` stamps.

    Runs the template's real-AST extractor (``scripts/extract-kite-manifest.mjs``)
    over ``src/`` and writes ``kite-manifest.json`` into the iter dir for the
    deploy seam to read — replacing the old deploy-time regex over JSX. A stamp
    defect (dynamic-expression value, empty ``data-kite-conversion``, duplicate
    event identity) is blocking with field-level repair hints, so a silent
    omission — the regex's worst failure — becomes a loud, fixable error. A
    tooling failure (script missing, crash, timeout, unparseable) is a
    non-blocking warning: the analytics catalog is best-effort and must never
    block a ship. Mirrors :func:`_validate_cms` (same one-JSON-line contract).

    Run with plain ``node`` (not ``tsx``): the script is ESM JavaScript whose only
    runtime dependency is the ``typescript`` compiler package — a pinned
    devDependency of the classic template — so it works from a frozen install
    without tsx (which the classic template does not lock).

    Returns (ok, errors, detail). ``errors`` is the script's field-level list;
    ``detail`` carries either the tooling-skip reason or the script's
    non-blocking stamp warnings (no_conversion, multiple_conversions, ...) so
    they surface in generation output.
    """
    # Relative on purpose: the tool runs with cwd=iter_dir (and resolves its
    # `typescript` dependency from there).
    script_relpath = "scripts/extract-kite-manifest.mjs"
    script = iter_dir / script_relpath
    if not script.is_file():
        return True, [], f"kite extractor not found at {script}; skipped"
    result, skip_detail = _run_json_line_tool(
        ["node", script_relpath, "src", "--out", "kite-manifest.json"],
        iter_dir,
        tool_label="kite extractor",
    )
    if result is None:
        return True, [], skip_detail
    errors = result.get("errors") or []
    # A `usage` error means we invoked the script wrong — a tooling failure, not a
    # stamp defect; skip rather than false-block the generation.
    if not result.get("ok") and errors and all(e.get("kind") == "usage" for e in errors):
        return True, [], "kite extractor usage error; skipped"
    # Surface the script's NON-BLOCKING warnings (no_conversion,
    # multiple_conversions, spread_stamp, unscanned_file_stamp) as detail so they
    # land in generation output instead of being dropped on the floor.
    detail = "\n".join(
        f"kite stamp warning [{w.get('kind', '?')}]"
        + (f" {w.get('path')}:{w.get('line')}" if w.get("path") else "")
        + f": {w.get('hint', '')}"
        for w in result.get("warnings") or []
        if isinstance(w, dict)
    )
    return bool(result.get("ok")), errors, detail


def main() -> int:
    # --skip-llm: skip the full-generation LLM call and run the rest of the
    # pipeline (gates → install → types → validate → seed → images) against
    # the files already on disk. The re-run path after the agent repairs files
    # by hand — a manual fix must not cost a fresh multi-minute regeneration.
    skip_llm = "--skip-llm" in sys.argv[1:]
    positional = [a for a in sys.argv[1:] if not a.startswith("--")]
    # iter slug: positional arg overrides the ITERATION_ID env default.
    iter_name = positional[0] if positional else os.environ.get("ITERATION_ID")
    if not iter_name:
        _emit({"status": "error", "error": "no iter_name: pass as arg or set ITERATION_ID env"})
        return 2
    warnings: list[str] = []

    efs = os.environ.get("EFS_APP_PATH")
    if not efs:
        _emit({"status": "error", "error": "EFS_APP_PATH env var not set"})
        return 2
    efs_path = pathlib.Path(efs)

    # Iter project tree lives at $EFS_APP_PATH/iterations/<iter>/ per the ecosystem
    # config contract (e2b/generate-ecosystem-config.mjs).
    iter_dir = efs_path / "iterations" / iter_name
    visual_spec_path = iter_dir / "visual_spec.md"
    plan_path = iter_dir / "plan.json"
    workpad_path = efs_path / "workpad.json"
    # The create agent is scoped to the iter run dir, so opencode_cli pushes the
    # skill tree to iterations/<iter>/.opencode/skills — not the app root. Read
    # rules from the tree this script lives in (the same one the lib import above
    # resolves from); EFS_APP_PATH/.opencode/skills is empty on a fresh app and
    # yields "Rule file missing".
    skills_dir = SKILL_DIR.parent
    payload_mode = _is_payload_mode(iter_dir)

    user_requirements = os.environ.get("USER_REQUIREMENTS", "")
    user_uploaded_assets = os.environ.get("USER_UPLOADED_ASSETS", "")
    image_base_url = os.environ.get("IMAGE_BASE_URL", "")
    api_key = os.environ.get("OPENROUTER_API_KEY", "")

    missing = []
    if not plan_path.is_file():
        missing.append(str(plan_path))
    if not visual_spec_path.is_file():
        missing.append(str(visual_spec_path))
    if not workpad_path.is_file():
        missing.append(str(workpad_path))
    if not image_base_url:
        missing.append("IMAGE_BASE_URL env")
    if not api_key:
        missing.append("OPENROUTER_API_KEY env")
    if missing:
        _emit({"status": "error", "error": f"Missing inputs: {missing}"})
        return 2

    try:
        plan = json.loads(llm_utils.read_file(plan_path))
        workpad = json.loads(llm_utils.read_file(workpad_path))
    except (OSError, ValueError) as e:
        _emit({"status": "error", "error": f"input unreadable: {e}"})
        return 2

    try:
        system_prompt = _build_system_prompt(skills_dir, payload_mode)
    except RuntimeError as e:
        _emit({"status": "error", "error": str(e)})
        return 2

    schema_block = ""
    if payload_mode:
        schema_block, missing_schema = _read_schema_block(iter_dir)
        if missing_schema:
            warnings.append(
                "Payload schema files absent; generator running without them "
                f"(field-name drift risk): {missing_schema}"
            )

    user_prompt = _build_user_prompt(
        plan=plan,
        visual_spec=llm_utils.read_file(visual_spec_path),
        schema_block=schema_block,
        user_requirements=user_requirements,
        build_requirements=workpad.get("build_requirements") or [],
        user_uploaded_assets=user_uploaded_assets,
        logo_info=workpad.get("logo_info") or {},
        iteration_id=iter_name,
        image_base_url=image_base_url,
        payload_mode=payload_mode,
    )

    # Dispatch image generation BEFORE the LLM call so it overlaps with
    # the (5–10+ min) file-generation latency. The agent driving this skill
    # no longer issues the `image-creation` curl itself. Already-live CDN images are
    # skipped inside the dispatch, so re-runs only fill real gaps.
    image_future = _dispatch_image_generation(
        iter_dir=iter_dir, iter_name=iter_name, plan_images=plan.get("images") or []
    )

    t0 = time.time()
    written: list[str] = []

    def _emit_gate_failure(error: str, **error_fields) -> int:
        """One shape for every blocking-gate failure (cms / seed / kite): the
        agent repairs per the field-level errors and re-runs with --skip-llm.
        Closure over written/t0/iter_name/warnings — reads their CURRENT state
        at emit time, so warnings appended after definition are included."""
        _emit(
            {
                "status": "failed",
                "error": error,
                **error_fields,
                "files_written": written,
                "duration_s": round(time.time() - t0, 2),
                "iteration_id": iter_name,
                "warnings": warnings,
            }
        )
        return 1

    if not skip_llm:
        try:
            files = llm_utils.call_llm_parsed(
                parse=_parse_response,
                warnings=warnings,
                url=llm_utils.proxy_url(f"nextjs_generate.{iter_name}"),
                model=MODEL,
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                api_key=api_key,
                temperature=TEMPERATURE,
                reasoning_effort=REASONING_EFFORT,
                timeout=TIMEOUT_SECS,
            )
        except (urllib.error.URLError, TimeoutError, RuntimeError) as e:
            dur = round(time.time() - t0, 2)
            _emit(
                {
                    "status": "error",
                    "error": f"{type(e).__name__}: {e}",
                    "duration_s": dur,
                    "warnings": warnings,
                }
            )
            return 1
        except (ValueError, json.JSONDecodeError) as e:
            dur = round(time.time() - t0, 2)
            _emit(
                {
                    "status": "error",
                    "error": f"response parse failed: {e}",
                    "duration_s": dur,
                    "warnings": warnings,
                }
            )
            return 1

        written = _write_files(iter_dir, files)
    # Image Creation.json is owned by plan_files.py now — written at plan time so
    # image generation can start in parallel. This script no longer writes
    # or transforms an image manifest.

    # Blocking gates (before the install/validate spend): every planned file
    # is on disk, every block the seed uses has a restyled component, and
    # generated.ts re-declares no injected meta field. On a failure, one
    # scoped LLM call repairs just the gap in-run — a full regeneration to
    # recover a handful of files is the expensive path this replaces.
    gate_errors = _blocking_gate_errors(plan, iter_dir)
    if gate_errors:
        warnings.append(
            f"blocking gate hit {len(gate_errors)} error(s); attempting scoped in-run repair: "
            f"{[e['path'] for e in gate_errors]}"
        )
        written += _repair_gate_errors(
            gate_errors=gate_errors,
            iter_dir=iter_dir,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            api_key=api_key,
            iter_name=iter_name,
            warnings=warnings,
        )
        gate_errors = _blocking_gate_errors(plan, iter_dir)
    if gate_errors:
        return _emit_gate_failure(
            "Generation left an incomplete or broken file set (scoped repair "
            "did not resolve it). Repair per the errors below (path + hint), "
            "then re-run generate_files.py with --skip-llm.",
            cms_errors=gate_errors,
        )

    # Custom block triples: the LLM authored the schema
    # (blocks/generated.ts) + component; write the literal RenderBlocks registry
    # entries deterministically here so the renderer can render them and the
    # block-triple gate passes. Idempotent — safe on scoped-repair / --skip-llm
    # re-runs. Runs only for Payload iters and only when custom blocks exist.
    if payload_mode:
        injected, inject_warnings = _inject_generated_block_registry(iter_dir)
        warnings.extend(inject_warnings)
        if injected:
            warnings.append(f"injected custom block registry entries: {injected}")
        # Per-collection item layouts: register any authored
        # <Pascal(slug)>Layout component so the route dispatches to it.
        injected_items, item_inject_warnings = _inject_generated_item_registry(iter_dir)
        warnings.extend(item_inject_warnings)
        if injected_items:
            warnings.append(f"injected custom item registry entries: {injected_items}")

    # Install deps now so the next script (`validate_files.py`) can run
    # `pnpm typecheck` against a populated node_modules. Without this step
    # validate fails on the first call and the agent has to recover —
    # which is what the post-generate thrash on iter3 (run 94a699ca) was
    # spending ~80s and 13 LLM turns on.
    install_ok, install_tail = _install_iter_deps(iter_dir)
    if not install_ok:
        warnings.append(f"pnpm install failed; validate may fail. Tail:\n{install_tail}")

    # The next three steps exist only for the Payload template (classic iters
    # have no `generate:types`/`seed` scripts, no seed.json, and no CMS).
    if payload_mode:
        # Regenerate Payload types so any content collections the generator
        # authored into payload/collections/generated.ts are typed before
        # validate_files.py's `pnpm typecheck`. Config-only (no DB);
        # non-blocking.
        types_ok, types_tail = _generate_types(iter_dir)
        if not types_ok:
            warnings.append(
                f"pnpm generate:types failed; typecheck may surface type errors. "
                f"Tail:\n{types_tail}"
            )

        # Prove the seed fits the Payload admin BEFORE writing it to the DB. A fit
        # error (wrong field name, missing required, orphan key, unknown block) is
        # blocking with field-level repair hints, so a mis-fitting generation fails
        # loudly here instead of silently shipping uneditable/dropped content.
        cms_ok, cms_errors, cms_detail = _validate_cms(iter_dir, iter_name, efs_path, skills_dir)
        if cms_detail:
            warnings.append(cms_detail)
        if not cms_ok:
            return _emit_gate_failure(
                "Generated seed.json does not fit the Payload schema. Repair the "
                "field-level errors below (path + hint), then re-run "
                "generate_files.py with --skip-llm.",
                cms_errors=cms_errors,
            )

        # Seed the per-iter Payload schema from the generated seed.json so the dev
        # server renders DB-backed content and QA scans the real site. After
        # install (needs node_modules), before QA. Blocking on failure: an unseeded
        # schema makes every page 404, which QA would misreport as a dead server.
        seed_ok, seed_detail = _seed_iter(iter_dir, iter_name, efs_path)
        if not seed_ok:
            return _emit_gate_failure(f"Payload seed failed: {seed_detail}")

    # Classic template: derive the analytics manifest from the authored
    # data-kite-* stamps with a real TSX AST (not the old deploy-time regex) and
    # write kite-manifest.json for the deploy seam to read. Runs after install so
    # the script can resolve `typescript` from node_modules. A genuine stamp
    # defect (dynamic value, empty conversion, duplicate identity) is blocking
    # and repairable via --skip-llm (like the CMS gate above); a tooling failure
    # is a non-blocking warning. Payload sites have no authored stamps (baked
    # block components), so this is classic-only.
    if not payload_mode:
        kite_ok, kite_errors, kite_detail = _extract_kite_manifest(iter_dir)
        if kite_detail:
            warnings.append(kite_detail)
        if not kite_ok:
            return _emit_gate_failure(
                "Authored data-kite-* analytics stamps have defects the catalog "
                "cannot encode. Repair the field-level errors below (path + line "
                "+ hint), then re-run generate_files.py with --skip-llm.",
                kite_errors=kite_errors,
            )

    # Join the image dispatch. By the time we get here, the LLM call and
    # pnpm install have run; image generation has had that whole window to
    # complete. We still wait so the next phase (validate) and the user view
    # see real images, not 404s.
    images_summary: dict | None = None
    if image_future is not None:
        try:
            summary = image_future.result()
        except Exception as e:  # noqa: BLE001 - surface any background failure
            warnings.append(f"image dispatch crashed: {type(e).__name__}: {e}")
        else:
            images_summary = summary
            if summary["failed"]:
                # A failed count can be transport-level noise (whole batch
                # 504'd while the backend finished uploading) — verify
                # against the CDN and retry only true misses before letting
                # the failure influence the verdict.
                images_summary, reconcile_notes = _reconcile_failed_images(
                    plan_images=plan.get("images") or [],
                    iter_name=iter_name,
                    summary=summary,
                )
                warnings.extend(reconcile_notes)
            if images_summary["failed"]:
                warnings.append(
                    f"image generation: {images_summary['failed']}/{images_summary['total']} failed"
                )
                for err in images_summary["errors"][:5]:
                    warnings.append(f"image error: {err}")

    # If every planned image failed, return `failed` so the agent's
    # verdict-handling kicks in. A partial failure is still `success` (the
    # warnings carry the per-batch detail); only a total wipe is fatal,
    # because that means JSX is pointing at URLs the platform never
    # created and validate's typecheck won't catch broken `<img src>`.
    all_images_failed = (
        images_summary is not None
        and images_summary["total"] > 0
        and images_summary["succeeded"] == 0
    )
    status = "failed" if all_images_failed else "success"
    payload: dict = {
        "status": status,
        "files_written": written,
        "duration_s": round(time.time() - t0, 2),
        "iteration_id": iter_name,
        "warnings": warnings,
    }
    if images_summary is not None:
        payload["images"] = {
            "total": images_summary["total"],
            "succeeded": images_summary["succeeded"],
            "failed": images_summary["failed"],
        }
    if all_images_failed:
        payload["error"] = (
            "All planned images failed to generate — JSX would reference URLs that do not exist. "
            "Inspect warnings, then re-run generate_files.py with --skip-llm (already-live "
            "images are skipped; only the missing ones are re-requested)."
        )
    _emit(payload)
    return 1 if all_images_failed else 0


if __name__ == "__main__":
    sys.exit(main())
