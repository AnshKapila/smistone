---
name: company-deep-dive
description: Use this skill when the task is a comprehensive research report on one company — "research this company", "give me a deep dive on X", "prepare the onboarding research for our business", "what should we know about this prospect before the call". Produces a sourced report covering positioning, brand presence, website evolution over time, firmographics, competitive landscape, community sentiment, and a short list of ranked opportunities. For only a competitor list use `competitor-discovery`; for capturing brand identity to the team's shared knowledge use `brand-research`; for a single fact about a company just search directly.
mode: sandbox
---

# Company Deep Dive

One company, one report: what they do, how they got here, who they're up against, how the world sees them, and what to do about it — every claim sourced. This is the report that convinces a new user the team already understands their business.

## Inputs

- The company's website URL (from the task or wiki `company/identity.md`). If only a name is given, resolve the URL with `kite-research search` first and confirm it's the right company before spending anything on deep runs.
- The report's purpose — onboarding a new business, sizing up a prospect, studying a competitor — which decides how much weight the opportunities section carries.

## Sections and how to build each

Work through the sections in order; skip a section only when its evidence source is unavailable — meaning the provider still errors after one retry, or returns empty for the company — and say so in the report rather than leaving silent gaps. All commands are `web-research`; delegate-level protocols are named where they apply.

1. **Identity and positioning.** `extract` the homepage, about, and pricing pages. Then one `kite-research deep` run (processor `base`; `core` only when the task itself says thorough, or the purpose is a prospect call or similarly high-stakes decision) with a brief like: `"What does <company> sell, to whom, at what price, and how does it position itself in <category>? Include recent product or strategy changes."` Keep the citations.
2. **Brand snapshot.** `brand` for tokens (palette, fonts, tone), `assets` for the imagery they actually ship. Note the gap between how they describe themselves and how the site reads.
3. **Website evolution.** `history <url> <founding-yyyyMMdd>` (founding year from step 4 or a quick search — bounding by founding date avoids a previous domain owner's history). Pick 4–6 snapshots roughly evenly spaced across the company's life — always the earliest usable one and the current site — and `screenshot` their archive URLs. Two sentences on what changed: repositioning, redesigns, pivots. This section photographs well — keep the screenshot URLs in the report.
4. **Firmographics.** `native:crustdata-company-search` (execute pattern in `tool-discovery-execution`) filtered on the company's domain — e.g. `{"field": "basic_info.primary_domain", "type": "=", "value": "<domain>"}` — for founding year, headcount and its growth trend, funding, and categories. Headcount growth direction is often the single most telling number in the report.
5. **Competitive landscape.** Run the `competitor-discovery` protocol (its own skill). For an onboarding report, Tier 1 plus the dominant substitute is enough depth.
6. **Search and AI-answer standing** (when the purpose is onboarding or growth). Via `tool-discovery-execution`, use the DataForSEO catalog for the keywords the company ranks for versus its Tier-1 competitors, and the platform's AI-visibility data where available. One paragraph: where they're visible, where competitors outrank them.
7. **Community voice.** `mentions "<company>"` for Hacker News; `search` for Reddit and review-site threads. Quote 2–3 sentiments with links, drawn from the highest-engagement threads (points, comments) — at least one positive and one critical when both exist. No mentions is itself a finding (nobody is talking about them).
8. **Ranked opportunities.** Close with 3–5 moves, ranked by expected impact on the company's actual goals, each traceable to evidence above ("competitors A and B own the comparison-page SERP you're absent from"). Label confidence per your evidence standards. Evidence outranks impact: a lower-impact move you can evidence beats a bigger claim you cannot — leave the unevidenced one out. A short justified list beats a long list of observations.

## Output

- One markdown report with this skeleton (sections in this order, citations inline, screenshot URLs embedded where visual):

  ```markdown
  # Deep dive: [Company]
  ## Identity and positioning
  ## Brand snapshot
  ## Website evolution        <!-- timeline with screenshot URLs -->
  ## Firmographics
  ## Competitive landscape    <!-- Tier 1 + dominant substitute -->
  ## Search and AI-answer standing
  ## Community voice
  ## Ranked opportunities     <!-- 3-5, each: move, evidence, confidence -->
  ```

- File durable findings to the wiki (per `wiki-management`): identity/positioning evidence, the competitor list, and keyword/visibility findings each go to their own pages so other agents can use them without redoing the work.
- Task result: one-paragraph summary plus the report.

## Before returning

- Every factual claim traces to a citation; anything you couldn't source is labeled as inference.
- Every section is present or explicitly marked unavailable with the reason — no silent gaps.
- The wiki filings above actually happened; link them in the task result.

## Cost and time discipline

- One `deep` run at `base` is the default; reach for `core`/`pro` only when the task says thorough and the extra minutes are justified. Never run two deep runs where one well-briefed run answers both questions.
- The whole report should be buildable in under ~15 minutes at default settings; if a section's provider is erroring, note it and move on rather than stalling the report.
